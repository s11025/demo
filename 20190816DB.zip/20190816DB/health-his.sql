/*
Navicat MySQL Data Transfer

Source Server         : testtest
Source Server Version : 50616
Source Host           : rm-2ze9w425lsmc2bf34o.mysql.rds.aliyuncs.com:3306
Source Database       : health-his

Target Server Type    : MYSQL
Target Server Version : 50616
File Encoding         : 65001

Date: 2019-08-16 18:04:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dic_activity_type
-- ----------------------------
DROP TABLE IF EXISTS `dic_activity_type`;
CREATE TABLE `dic_activity_type` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `ACTIVITY_TYPE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_activity_type
-- ----------------------------
INSERT INTO `dic_activity_type` VALUES ('1', '节日外出游玩');
INSERT INTO `dic_activity_type` VALUES ('2', '室外体质锻炼');
INSERT INTO `dic_activity_type` VALUES ('41', '茶话会');
INSERT INTO `dic_activity_type` VALUES ('42', '慰问演出');
INSERT INTO `dic_activity_type` VALUES ('43', '象棋比赛');
INSERT INTO `dic_activity_type` VALUES ('44', '针织比赛');

-- ----------------------------
-- Table structure for dic_bed_region
-- ----------------------------
DROP TABLE IF EXISTS `dic_bed_region`;
CREATE TABLE `dic_bed_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PARENT_ID` int(11) DEFAULT NULL,
  `REGION_NAME` varchar(255) DEFAULT NULL COMMENT '区域名',
  `FULLNAME` varchar(100) DEFAULT NULL COMMENT '区域全称',
  `FLAG` tinyint(3) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`id`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_bed_region_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_bed_region
-- ----------------------------
INSERT INTO `dic_bed_region` VALUES ('0', null, '床位区域', null, '1', '71');
INSERT INTO `dic_bed_region` VALUES ('3', '2', '1101', '一号楼/一层/1101', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('6', '5', '地下室', '二号楼/地下室', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('8', '6', '－2101', '二号楼/地下室/－2101', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('10', '6', '－2102', '二号楼/地下室/－2102', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('11', '6', '－2103', '二号楼/地下室/－2103', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('13', '12', '一层', '三号楼/一层', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('14', '13', '3101', '三号楼/一层/3101', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('17', '12', '二层', '三号楼/二层', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('18', '17', '3201', '三号楼/二层/3201', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('33', '1', '二层', '一号楼/二层', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('34', '33', '1201', '一号楼/二层/1201', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('35', '33', '1202', '一号楼/二层/1202', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('36', '13', '3102', '三号楼/一层/3102', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('37', '17', '3202', '三号楼/二层/3202', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('38', '1', '三层', '一号楼/三层', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('39', '12', '三层', '三号楼/三层', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('40', '38', '1301', '一号楼/三层/1301', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('41', '38', '1302', '一号楼/三层/1302', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('42', '39', '3301', '三号楼/三层/3301', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('43', '39', '3302', '三号楼/三层/3302', '1', '71');
INSERT INTO `dic_bed_region` VALUES ('144', '0', '一号楼', '床位区域/一号楼', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('145', '0', '二号楼', '床位区域/二号楼', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('146', '0', '三号楼', '床位区域/三号楼', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('147', '144', '一层', '一号楼/一层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('148', '145', '一层', '二号楼/一层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('149', '146', '一层', '三号楼/一层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('150', '144', '二层', '一号楼/二层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('151', '145', '二层', '二号楼/二层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('152', '146', '二层', '三号楼/二层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('153', '148', '21011', '二号楼/一层/21011', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('154', '152', '31021', '三号楼/二层/31021', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('155', '152', '31022', '三号楼/二层/31022', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('156', '148', '21012', '二号楼/一层/21012', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('157', '151', '21021', '二号楼/二层/21021', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('158', '149', '31011', '三号楼/一层/31011', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('159', '151', '21022', '二号楼/二层/21022', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('160', '149', '31012', '三号楼/一层/31012', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('161', '147', '11011', '一号楼/一层/11011', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('162', '147', '11012', '一号楼/一层/11012', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('163', '150', '11022', '一号楼/二层/11022', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('164', '150', '11021', '一号楼/二层/11021', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('166', '0', '四号楼', '床位区域/四号楼', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('167', '166', '一层', '四号楼/一层', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('168', '167', '41012', '四号楼/一层/41012', '1', '1');
INSERT INTO `dic_bed_region` VALUES ('169', '167', '41011', '四号楼/一层/41011', '1', '1');

-- ----------------------------
-- Table structure for dic_certificate_class
-- ----------------------------
DROP TABLE IF EXISTS `dic_certificate_class`;
CREATE TABLE `dic_certificate_class` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `CERTIFICATE_TYPE` tinyint(4) DEFAULT NULL,
  `CERTIFICATE_NAME` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_certificate_class
-- ----------------------------
INSERT INTO `dic_certificate_class` VALUES ('1', '1', '身份证');
INSERT INTO `dic_certificate_class` VALUES ('2', '1', '驾驶证');
INSERT INTO `dic_certificate_class` VALUES ('3', '1', '居住证');
INSERT INTO `dic_certificate_class` VALUES ('4', '2', '健康证');

-- ----------------------------
-- Table structure for dic_consult_category
-- ----------------------------
DROP TABLE IF EXISTS `dic_consult_category`;
CREATE TABLE `dic_consult_category` (
  `ID` tinyint(225) NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='质询类别的字典表';

-- ----------------------------
-- Records of dic_consult_category
-- ----------------------------
INSERT INTO `dic_consult_category` VALUES ('1', '健康咨询');
INSERT INTO `dic_consult_category` VALUES ('2', '入住咨询');
INSERT INTO `dic_consult_category` VALUES ('3', '养老咨询');
INSERT INTO `dic_consult_category` VALUES ('19', '费用咨询');

-- ----------------------------
-- Table structure for dic_cost
-- ----------------------------
DROP TABLE IF EXISTS `dic_cost`;
CREATE TABLE `dic_cost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `COST_CATEGORY` int(11) DEFAULT NULL COMMENT '外键',
  `COST_NAME` varchar(15) DEFAULT NULL,
  `PRICE` decimal(6,1) DEFAULT NULL,
  `UNIT` tinyint(3) DEFAULT NULL,
  `FLAG` tinyint(3) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`id`),
  KEY `COST_CATEGORY` (`COST_CATEGORY`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_cost_ibfk_1` FOREIGN KEY (`COST_CATEGORY`) REFERENCES `dic_cost_category` (`id`),
  CONSTRAINT `dic_cost_ibfk_2` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_cost
-- ----------------------------
INSERT INTO `dic_cost` VALUES ('3', '1', '单人间床位', '1600.0', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('4', '1', '双人间床位', '800.5', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('8', '2', '晚餐', '20.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('9', '2', '午餐', '33.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('10', '5', '试入住押金', '1000.0', '1', '1', '71');
INSERT INTO `dic_cost` VALUES ('11', '5', '入住押金', '2000.0', '1', '1', '71');
INSERT INTO `dic_cost` VALUES ('14', '2', '早餐', '10.5', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('21', '1', '三人间床位', '500.0', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('22', '2', '宵夜', '8.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('23', '11', '床上四件套', '100.0', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('24', '11', '棉被', '45.5', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('26', '13', '洗漱用品', '5.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('27', '9', '整理床褥', '10.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('28', '10', '空调使用费', '300.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('29', '12', '取暖费', '800.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('31', '11', '被褥费', '100.0', '5', '1', '71');
INSERT INTO `dic_cost` VALUES ('35', '12', '31', '31.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('40', '12', '新建取暖费', '1000.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('41', '9', '新建服务费', '30.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('58', '9', '打扫卫生', '100.0', '3', '1', '71');
INSERT INTO `dic_cost` VALUES ('69', '1', '高级床位费', '1000.0', '4', '1', '71');
INSERT INTO `dic_cost` VALUES ('79', '1', '单人间床位', '1600.0', '4', '1', '125');
INSERT INTO `dic_cost` VALUES ('80', '41', '床位押金', '1000.0', '5', '1', '125');
INSERT INTO `dic_cost` VALUES ('81', '1', '6人间床位', '300.0', '4', '1', '125');
INSERT INTO `dic_cost` VALUES ('82', '45', '取暖费', '3000.0', '5', '1', '125');
INSERT INTO `dic_cost` VALUES ('83', '42', '早餐', '15.0', '3', '1', '125');
INSERT INTO `dic_cost` VALUES ('84', '43', '午餐', '30.0', '3', '1', '125');
INSERT INTO `dic_cost` VALUES ('85', '47', '电费', '100.0', '4', '1', '125');
INSERT INTO `dic_cost` VALUES ('86', '46', '水费', '200.0', '5', '1', '125');
INSERT INTO `dic_cost` VALUES ('91', '42', 'S早餐', '10.0', '3', '1', '2');
INSERT INTO `dic_cost` VALUES ('93', '1', 'S单人间', '1500.0', '4', '1', '2');
INSERT INTO `dic_cost` VALUES ('94', '41', 'S单人间押金', '2000.0', '5', '1', '2');
INSERT INTO `dic_cost` VALUES ('95', '41', 'S双人间押金', '1000.0', '5', '1', '2');
INSERT INTO `dic_cost` VALUES ('96', '2', 'S午餐', '20.0', '3', '1', '2');
INSERT INTO `dic_cost` VALUES ('97', '12', 'S取暖', '1000.0', '5', '1', '2');

-- ----------------------------
-- Table structure for dic_cost_category
-- ----------------------------
DROP TABLE IF EXISTS `dic_cost_category`;
CREATE TABLE `dic_cost_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CATEGORY_TYPE` tinyint(3) DEFAULT NULL COMMENT '基本费用-1，押金费用-2，其他费用-3',
  `CATEGORY_NAME` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_cost_category
-- ----------------------------
INSERT INTO `dic_cost_category` VALUES ('1', '1', '床位费');
INSERT INTO `dic_cost_category` VALUES ('2', '1', '餐费');
INSERT INTO `dic_cost_category` VALUES ('5', '2', '押金费用');
INSERT INTO `dic_cost_category` VALUES ('9', '1', '服务费');
INSERT INTO `dic_cost_category` VALUES ('10', '1', '空调费');
INSERT INTO `dic_cost_category` VALUES ('11', '1', '一次性购置费');
INSERT INTO `dic_cost_category` VALUES ('12', '1', '取暖费');
INSERT INTO `dic_cost_category` VALUES ('13', '1', '生活用品');
INSERT INTO `dic_cost_category` VALUES ('41', '2', '押金费');
INSERT INTO `dic_cost_category` VALUES ('42', '1', '早餐费');
INSERT INTO `dic_cost_category` VALUES ('43', '1', '午餐费');
INSERT INTO `dic_cost_category` VALUES ('44', '1', '晚餐费');
INSERT INTO `dic_cost_category` VALUES ('45', '1', '取暖费');
INSERT INTO `dic_cost_category` VALUES ('46', '1', '水费');
INSERT INTO `dic_cost_category` VALUES ('47', '1', '电费');
INSERT INTO `dic_cost_category` VALUES ('48', '1', '卫生费');

-- ----------------------------
-- Table structure for dic_district
-- ----------------------------
DROP TABLE IF EXISTS `dic_district`;
CREATE TABLE `dic_district` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PARENT_ID` int(11) DEFAULT NULL,
  `DISTRICT_CODE` varchar(9) DEFAULT NULL,
  `DISTRICT_NAME` varchar(15) DEFAULT NULL COMMENT '省、市、区（县）、街道（乡镇）',
  `FLAG` tinyint(4) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COMMENT='行政区划数据';

-- ----------------------------
-- Records of dic_district
-- ----------------------------
INSERT INTO `dic_district` VALUES ('1', '0', '000000000', '行政区划', '1');
INSERT INTO `dic_district` VALUES ('2', '1', '110000000', '北京', '1');
INSERT INTO `dic_district` VALUES ('3', '2', '111100000', '北京市', '1');
INSERT INTO `dic_district` VALUES ('4', '3', '111111000', '东城区', '1');
INSERT INTO `dic_district` VALUES ('5', '3', '111112000', '西城区', '1');
INSERT INTO `dic_district` VALUES ('6', '3', '111113000', '崇文区', '1');
INSERT INTO `dic_district` VALUES ('7', '3', '111113000', '宣武区', '1');
INSERT INTO `dic_district` VALUES ('8', '3', '111113000', '丰台区', '1');
INSERT INTO `dic_district` VALUES ('9', '3', '111113000', '朝阳区', '1');
INSERT INTO `dic_district` VALUES ('10', '3', '111113000', '石景山区', '1');
INSERT INTO `dic_district` VALUES ('11', '3', '111113000', '海淀区', '1');
INSERT INTO `dic_district` VALUES ('12', '3', '111113000', '门头沟区', '1');
INSERT INTO `dic_district` VALUES ('13', '3', '111113000', '房山区', '1');
INSERT INTO `dic_district` VALUES ('14', '3', '111113000', '通州区', '1');
INSERT INTO `dic_district` VALUES ('15', '3', '111113000', '顺义区', '1');
INSERT INTO `dic_district` VALUES ('16', '3', '111113000', '昌平区', '1');
INSERT INTO `dic_district` VALUES ('17', '3', '111113000', '大兴区', '1');
INSERT INTO `dic_district` VALUES ('18', '3', '111113000', '怀柔区', '1');
INSERT INTO `dic_district` VALUES ('19', '3', '111113000', '平谷区', '1');
INSERT INTO `dic_district` VALUES ('20', '3', '111113000', '密云县', '1');
INSERT INTO `dic_district` VALUES ('21', '3', '111113000', '延庆县', '1');
INSERT INTO `dic_district` VALUES ('22', '3', '111113000', '其它区', '1');
INSERT INTO `dic_district` VALUES ('23', '1', '120000000', '吉林', '1');
INSERT INTO `dic_district` VALUES ('24', '23', '121100000', '长春市', '1');
INSERT INTO `dic_district` VALUES ('25', '24', '121111000', '南关区', '1');
INSERT INTO `dic_district` VALUES ('26', '24', '121112000', '宽城区', '1');
INSERT INTO `dic_district` VALUES ('27', '24', '121112000', '朝阳区', '1');
INSERT INTO `dic_district` VALUES ('28', '24', '121112000', '二道区', '1');
INSERT INTO `dic_district` VALUES ('29', '24', '121112000', '绿园区', '1');
INSERT INTO `dic_district` VALUES ('30', '24', '121112000', '双阳区', '1');
INSERT INTO `dic_district` VALUES ('31', '24', '121112000', '农安县', '1');
INSERT INTO `dic_district` VALUES ('32', '24', '121112000', '九台市', '1');
INSERT INTO `dic_district` VALUES ('33', '24', '121112000', '榆树市', '1');
INSERT INTO `dic_district` VALUES ('34', '24', '121112000', '德惠市', '1');
INSERT INTO `dic_district` VALUES ('35', '24', '121112000', '高新技术产业开发区', '1');
INSERT INTO `dic_district` VALUES ('36', '24', '121112000', '汽车产业开发区', '1');
INSERT INTO `dic_district` VALUES ('37', '24', '121112000', '经济技术开发区', '1');
INSERT INTO `dic_district` VALUES ('38', '24', '121112000', '净月旅游开发区', '1');
INSERT INTO `dic_district` VALUES ('39', '24', '121112000', '其它区', '1');
INSERT INTO `dic_district` VALUES ('40', '23', '121200000', '吉林市', '1');
INSERT INTO `dic_district` VALUES ('41', '40', '121112000', '昌邑区1', '1');
INSERT INTO `dic_district` VALUES ('42', '40', '121112000', '龙潭区', '1');
INSERT INTO `dic_district` VALUES ('43', '40', '121112000', '船营区', '1');
INSERT INTO `dic_district` VALUES ('44', '40', '121112000', '丰满区', '1');
INSERT INTO `dic_district` VALUES ('45', '40', '121112000', '永吉县', '1');
INSERT INTO `dic_district` VALUES ('46', '40', '121112000', '桦甸市', '1');
INSERT INTO `dic_district` VALUES ('47', '40', '121112000', '蛟河市', '1');
INSERT INTO `dic_district` VALUES ('48', '40', '121112000', '磐石市', '1');
INSERT INTO `dic_district` VALUES ('49', '40', '121112000', '其它区', '1');
INSERT INTO `dic_district` VALUES ('50', '40', '121112000', '舒兰市', '1');

-- ----------------------------
-- Table structure for dic_duty_area
-- ----------------------------
DROP TABLE IF EXISTS `dic_duty_area`;
CREATE TABLE `dic_duty_area` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AREA_NAME` varchar(15) DEFAULT NULL,
  `REGIONS` varchar(100) DEFAULT NULL,
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_duty_area_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_duty_area
-- ----------------------------
INSERT INTO `dic_duty_area` VALUES ('1', '二号楼', '8,10,11', '71');
INSERT INTO `dic_duty_area` VALUES ('7', '一号楼', '3,9,34,35,40,41', '71');
INSERT INTO `dic_duty_area` VALUES ('9', '三号楼', '14,36,18,37,42,43', '71');
INSERT INTO `dic_duty_area` VALUES ('59', '全部', '3,9,34,35,40,41,8,10,11,14,36,18,37,42,43', '71');
INSERT INTO `dic_duty_area` VALUES ('69', '四区', '168,169', '1');
INSERT INTO `dic_duty_area` VALUES ('73', '三号楼', '158,160,154,155', '0');
INSERT INTO `dic_duty_area` VALUES ('75', '一区', '164,163,161,162', '126');
INSERT INTO `dic_duty_area` VALUES ('77', 'S责任区域一', '180', '2');

-- ----------------------------
-- Table structure for dic_job_category
-- ----------------------------
DROP TABLE IF EXISTS `dic_job_category`;
CREATE TABLE `dic_job_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `JOB_NAME` varchar(15) DEFAULT NULL,
  `FLAG` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_job_category
-- ----------------------------
INSERT INTO `dic_job_category` VALUES ('1', '护理员', '1');
INSERT INTO `dic_job_category` VALUES ('2', '护士', '1');

-- ----------------------------
-- Table structure for dic_leave_type
-- ----------------------------
DROP TABLE IF EXISTS `dic_leave_type`;
CREATE TABLE `dic_leave_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LEAVE_TYPE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_leave_type
-- ----------------------------
INSERT INTO `dic_leave_type` VALUES ('1', '外出访友');
INSERT INTO `dic_leave_type` VALUES ('2', '回家探亲');

-- ----------------------------
-- Table structure for dic_log_type
-- ----------------------------
DROP TABLE IF EXISTS `dic_log_type`;
CREATE TABLE `dic_log_type` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `LOG_TYPE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_log_type
-- ----------------------------
INSERT INTO `dic_log_type` VALUES ('11', '新增机构');
INSERT INTO `dic_log_type` VALUES ('12', '删除机构');
INSERT INTO `dic_log_type` VALUES ('21', '新增用户');
INSERT INTO `dic_log_type` VALUES ('22', '删除用户');
INSERT INTO `dic_log_type` VALUES ('23', '更新用户');

-- ----------------------------
-- Table structure for dic_material_category
-- ----------------------------
DROP TABLE IF EXISTS `dic_material_category`;
CREATE TABLE `dic_material_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PARENT_ID` int(11) DEFAULT NULL,
  `MATERIAL_NAME` varchar(15) DEFAULT NULL,
  `PRICE` decimal(6,1) DEFAULT NULL,
  `FLAG` tinyint(3) DEFAULT NULL COMMENT '1-可用，0-不可用，默认1',
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_material_category_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_material_category
-- ----------------------------
INSERT INTO `dic_material_category` VALUES ('0', null, '物资类别', '1.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('1', '0', '护理物品', null, '1', '71');
INSERT INTO `dic_material_category` VALUES ('2', '1', '拔火罐', '50.2', '1', '71');
INSERT INTO `dic_material_category` VALUES ('4', '1', '针灸', '30.5', '1', '71');
INSERT INTO `dic_material_category` VALUES ('6', '0', '生活用品', null, '1', '71');
INSERT INTO `dic_material_category` VALUES ('8', '6', '镜子', '3.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('14', '0', '卫生用品', null, '1', '71');
INSERT INTO `dic_material_category` VALUES ('16', '14', '拖把', '20.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('27', '6', '纸巾', '10.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('46', '14', '扫帚与簸箕', '20.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('73', '14', 'ASDF', '12345.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('90', '14', '23', '23.0', '1', '71');
INSERT INTO `dic_material_category` VALUES ('102', '0', '洗漱用品', '20.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('103', '0', '护理用品', '12.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('104', '0', '卫生用品', '50.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('105', '102', '牙刷', '10.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('106', '102', '刷牙杯', '10.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('107', '102', '毛巾', '15.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('108', '102', '洗面奶', '20.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('109', '103', '针灸', '100.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('110', '104', '扫地用品', '20.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('111', '104', '拖布', '30.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('112', '0', '其他收费', '12.0', '1', '1');
INSERT INTO `dic_material_category` VALUES ('117', '0', 'S生活用品', '1.0', '1', '2');
INSERT INTO `dic_material_category` VALUES ('118', '117', 'S拖布', '25.0', '1', '2');
INSERT INTO `dic_material_category` VALUES ('119', '117', 'S毛巾', '10.0', '1', '2');

-- ----------------------------
-- Table structure for dic_nurse_grade
-- ----------------------------
DROP TABLE IF EXISTS `dic_nurse_grade`;
CREATE TABLE `dic_nurse_grade` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GRADE_NAME` varchar(15) DEFAULT NULL,
  `MIN_SCORE` int(11) DEFAULT NULL,
  `MAX_SCORE` int(11) DEFAULT NULL,
  `TRICARE` varchar(50) DEFAULT NULL,
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_nurse_grade_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_nurse_grade
-- ----------------------------
INSERT INTO `dic_nurse_grade` VALUES ('1', '无需护理', '0', '25', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('2', '要支援1', '25', '32', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('3', '要支援2', '32', '36', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('4', '要介护1', '36', '50', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('5', '要介护2', '50', '70', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('6', '要介护3', '70', '90', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('7', '要介护4', '90', '110', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('8', '要介护5', '110', '1000', '', '71');
INSERT INTO `dic_nurse_grade` VALUES ('16', '自理', '1', '30', '1', '1');
INSERT INTO `dic_nurse_grade` VALUES ('17', '半自理啊', '31', '60', '2', '1');
INSERT INTO `dic_nurse_grade` VALUES ('18', '不能自理', '61', '100', '3', '1');
INSERT INTO `dic_nurse_grade` VALUES ('22', '1级', '0', '50', '1', '2');
INSERT INTO `dic_nurse_grade` VALUES ('23', '2级', '51', '100', '', '2');

-- ----------------------------
-- Table structure for dic_nurse_record_template
-- ----------------------------
DROP TABLE IF EXISTS `dic_nurse_record_template`;
CREATE TABLE `dic_nurse_record_template` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ITEM_NAME` varchar(100) DEFAULT NULL,
  `ORG_ID` int(11) DEFAULT NULL COMMENT '单位ID',
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  CONSTRAINT `dic_nurse_record_template_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_nurse_record_template
-- ----------------------------
INSERT INTO `dic_nurse_record_template` VALUES ('1', '1.查房，老人于床上休息，无明显异常。', '1');
INSERT INTO `dic_nurse_record_template` VALUES ('2', '2.查房，老人于椅子上休息，无明显异常。', '1');
INSERT INTO `dic_nurse_record_template` VALUES ('3', '3.查房，老人于轮椅上休息，无明显异常。', '1');
INSERT INTO `dic_nurse_record_template` VALUES ('4', '4.查房，老人睡眠中，呼吸平稳，无明显异常。', '1');
INSERT INTO `dic_nurse_record_template` VALUES ('5', '5.查房，老人于三层花园休息，无明显异常。', '126');
INSERT INTO `dic_nurse_record_template` VALUES ('11', 'asdfasdf', '0');
INSERT INTO `dic_nurse_record_template` VALUES ('12', 'asdf', '0');
INSERT INTO `dic_nurse_record_template` VALUES ('16', 'S护理内容一', '2');

-- ----------------------------
-- Table structure for dic_rate_category
-- ----------------------------
DROP TABLE IF EXISTS `dic_rate_category`;
CREATE TABLE `dic_rate_category` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_rate_category
-- ----------------------------
INSERT INTO `dic_rate_category` VALUES ('1', '身体机能');
INSERT INTO `dic_rate_category` VALUES ('2', '生活机能\r\n');
INSERT INTO `dic_rate_category` VALUES ('3', '认知机能\r\n');
INSERT INTO `dic_rate_category` VALUES ('4', '精神行动障碍');
INSERT INTO `dic_rate_category` VALUES ('5', '社会生活适应情况\r\n');
INSERT INTO `dic_rate_category` VALUES ('6', '14日内接受过的医疗处置');
INSERT INTO `dic_rate_category` VALUES ('7', '日常生活自理程度\r\n');
INSERT INTO `dic_rate_category` VALUES ('8', '主治医生意见书\r\n');

-- ----------------------------
-- Table structure for dic_region
-- ----------------------------
DROP TABLE IF EXISTS `dic_region`;
CREATE TABLE `dic_region` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISTRICT_ID` int(11) DEFAULT NULL,
  `REGION_NAME` varchar(15) DEFAULT NULL COMMENT '商圈、地名、地标',
  `PINYIN` varchar(15) DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  PRIMARY KEY (`ID`),
  KEY `FK_REGION_DISTRICT` (`DISTRICT_ID`),
  CONSTRAINT `FK_REGION_DISTRICT` FOREIGN KEY (`DISTRICT_ID`) REFERENCES `dic_district` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='区域数据';

-- ----------------------------
-- Records of dic_region
-- ----------------------------
INSERT INTO `dic_region` VALUES ('1', '4', '北京大学', 'BJDX', '1');
INSERT INTO `dic_region` VALUES ('2', '4', '牡丹园', 'MDY', '1');
INSERT INTO `dic_region` VALUES ('3', '4', '西三旗', 'XSQ', '1');
INSERT INTO `dic_region` VALUES ('4', '4', '西二旗1', 'XEQ1', '1');
INSERT INTO `dic_region` VALUES ('10', '9', '奔a', 'BA', '1');
INSERT INTO `dic_region` VALUES ('11', '4', '1', '1', '1');

-- ----------------------------
-- Table structure for dic_tag
-- ----------------------------
DROP TABLE IF EXISTS `dic_tag`;
CREATE TABLE `dic_tag` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TAG_NAME` varchar(15) DEFAULT NULL,
  `TAG_TYPE` tinyint(3) DEFAULT NULL COMMENT '1-用户标签',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='可拓展';

-- ----------------------------
-- Records of dic_tag
-- ----------------------------
INSERT INTO `dic_tag` VALUES ('1', '爱吃辣', '1');
INSERT INTO `dic_tag` VALUES ('2', '脾气暴躁', '1');
INSERT INTO `dic_tag` VALUES ('3', '不喜言谈', '1');

-- ----------------------------
-- Table structure for his_activity
-- ----------------------------
DROP TABLE IF EXISTS `his_activity`;
CREATE TABLE `his_activity` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVITY_TYPE` tinyint(4) DEFAULT NULL COMMENT '日常活动-1，大型活动-2',
  `TITLE` varchar(100) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `MATERIAL` varchar(200) DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '待发布-0，已发布-1，-1-删除，默认0',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `ACTIVITY_TYPE` (`ACTIVITY_TYPE`),
  CONSTRAINT `his_activity_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_activity_ibfk_2` FOREIGN KEY (`ACTIVITY_TYPE`) REFERENCES `dic_activity_type` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_activity
-- ----------------------------
INSERT INTO `his_activity` VALUES ('45', '41', '中秋茶话会', '昌平区回龙观养老院', '茶，水，苹果，橘子，瓜子，香蕉。', '1', '1022', '2018-03-13 16:05:28', null);
INSERT INTO `his_activity` VALUES ('46', '42', '北京影视学院慰问演出', '昌平区回龙观', '舞台，灯光，音响', '1', '1022', '2018-03-13 16:43:01', null);
INSERT INTO `his_activity` VALUES ('47', '43', '象棋比赛', '昌平区回龙观', '象棋30副，桌椅40套，', '1', '1022', '2018-03-13 16:44:27', null);
INSERT INTO `his_activity` VALUES ('48', '44', '针织比赛', '昌平区回龙观', '毛线，织针，桌椅，奖品', '1', '1022', '2018-03-13 16:45:23', null);

-- ----------------------------
-- Table structure for his_activity_calendar
-- ----------------------------
DROP TABLE IF EXISTS `his_activity_calendar`;
CREATE TABLE `his_activity_calendar` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVITY_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_ACTIVITY，外键字段：ID',
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL COMMENT '活动结束时间必须和活动开始时间在同一天',
  `PRICIAL` varchar(100) DEFAULT NULL COMMENT '姓名，多个人员之间用逗号分隔',
  `REMARK` varchar(200) DEFAULT NULL,
  `SIGNED_FLAG` tinyint(4) DEFAULT NULL COMMENT '待签到-0，已签到-1，默认0',
  `SIGN_IN_NUMBER` int(11) DEFAULT NULL COMMENT '签到人数',
  `SUMMARIZE_FLAG` tinyint(4) DEFAULT NULL COMMENT '未总结-0，已总结-1，默认0',
  `SUMMARY` varchar(200) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ACTIVITY_ID` (`ACTIVITY_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_activity_calendar_ibfk_1` FOREIGN KEY (`ACTIVITY_ID`) REFERENCES `his_activity` (`ID`),
  CONSTRAINT `his_activity_calendar_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_activity_calendar
-- ----------------------------
INSERT INTO `his_activity_calendar` VALUES ('67', '45', '2018-09-24 18:20:00', '2018-09-24 21:20:00', '邢世莹,马睿,师兴文', '', '0', '0', '0', null, '1022', '2018-03-13 16:20:53', null);

-- ----------------------------
-- Table structure for his_activity_signin
-- ----------------------------
DROP TABLE IF EXISTS `his_activity_signin`;
CREATE TABLE `his_activity_signin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVITY_CALENDAR_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_ACTIVITY_CALENDAR，外键字段：ID',
  `SIGNED_MEMBER` int(11) DEFAULT NULL COMMENT '签到会员标识，外键表：HIS_MEMBER，外键字段：ID',
  `SIGNED_NAME` varchar(50) DEFAULT NULL COMMENT '非会员签到人姓名',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ACTIVITY_CALENDAR_ID` (`ACTIVITY_CALENDAR_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `SIGNED_MEMBER` (`SIGNED_MEMBER`),
  CONSTRAINT `his_activity_signin_ibfk_1` FOREIGN KEY (`ACTIVITY_CALENDAR_ID`) REFERENCES `his_activity_calendar` (`ID`),
  CONSTRAINT `his_activity_signin_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_activity_signin_ibfk_3` FOREIGN KEY (`SIGNED_MEMBER`) REFERENCES `his_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_activity_signin
-- ----------------------------

-- ----------------------------
-- Table structure for his_attachment
-- ----------------------------
DROP TABLE IF EXISTS `his_attachment`;
CREATE TABLE `his_attachment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FILE_NAME` varchar(50) DEFAULT NULL,
  `FILE_TYPE` tinyint(3) NOT NULL DEFAULT '0' COMMENT '附件类型：无类型-0，文档-1，图片-2，音频-3，视频-4',
  `FILE_SIZE` float(6,2) DEFAULT '0.00' COMMENT '单位MB',
  `FILE_PATH` varchar(100) DEFAULT NULL COMMENT '完整路径（附件的相对文件路径+存储文件名）',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_creator` (`CREATOR`),
  CONSTRAINT `fk_creator` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=850 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- ----------------------------
-- Records of his_attachment
-- ----------------------------
INSERT INTO `his_attachment` VALUES ('835', '体检报告.jpg', '2', '0.77', '/81a81cfa-bb69-4b12-8e16-09bd0207fafc.jpg', '1021', '2018-03-13 11:31:09');
INSERT INTO `his_attachment` VALUES ('836', '体检报告.jpg', '2', '0.77', '/b3829cee-0fa4-43b0-b53f-bb5a1a77125f.jpg', '1021', '2018-03-13 15:00:34');
INSERT INTO `his_attachment` VALUES ('837', '活动公告.jpg', '2', '0.10', '/eebc22d4-2b69-4020-8719-bcc3ec824245.jpg', '1021', '2018-03-13 15:19:00');
INSERT INTO `his_attachment` VALUES ('838', '活动公告.jpg', '2', '0.10', '/6e25de13-1678-4d84-9dbf-c3b0366badb6.jpg', '1021', '2018-03-13 15:19:31');
INSERT INTO `his_attachment` VALUES ('839', '活动公告.jpg', '2', '0.10', '/6b31c921-6069-4d9a-a010-16cb35ea0794.jpg', '1021', '2018-03-13 15:20:09');
INSERT INTO `his_attachment` VALUES ('840', '活动公告.jpg', '2', '0.10', '/a96e641d-2d7d-4117-a803-6240a0022a7f.jpg', '1021', '2018-03-13 15:20:59');
INSERT INTO `his_attachment` VALUES ('841', '体检报告.jpg', '2', '0.77', '/4419b6d9-5360-4fe9-ae5f-085a0274abc9.jpg', '1021', '2018-03-13 15:26:42');
INSERT INTO `his_attachment` VALUES ('842', '体检报告.jpg', '2', '0.77', '/e663c5b0-2197-45f7-9290-db0514a62a13.jpg', '1021', '2018-03-13 15:47:51');
INSERT INTO `his_attachment` VALUES ('843', '体检报告.jpg', '2', '0.77', '/86053711-c41b-41fe-9658-e42158772d48.jpg', '1021', '2018-03-13 16:23:08');
INSERT INTO `his_attachment` VALUES ('844', '体检报告.jpg', '2', '0.77', '/7150ccdd-a9e3-430d-808d-b90b00926440.jpg', '1021', '2018-03-13 17:00:21');
INSERT INTO `his_attachment` VALUES ('845', '体检报告.jpg', '2', '0.77', '/643055db-59c9-4fbf-bbca-c18424330aa6.jpg', '1021', '2018-03-13 17:00:44');
INSERT INTO `his_attachment` VALUES ('849', '整合需求列表.xlsx', '1', '0.02', '/3002546c-b9fa-48d2-bf2d-b82f8719975e.xlsx', '1021', '2018-04-27 18:00:01');

-- ----------------------------
-- Table structure for his_bed
-- ----------------------------
DROP TABLE IF EXISTS `his_bed`;
CREATE TABLE `his_bed` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `REGION_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：DIC_BED_REGION，外键字段：ID',
  `BED_NO` varchar(20) DEFAULT NULL,
  `COST_ID` int(11) DEFAULT NULL COMMENT '外键表：DIC_COST，外键字段：ID',
  `REMARK` varchar(100) DEFAULT NULL,
  `FLAG` tinyint(3) DEFAULT '1' COMMENT '停用-0，空闲-1，占用-2，默认1',
  `CREATOR` int(11) NOT NULL DEFAULT '1' COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_REGION_BED` (`REGION_ID`),
  KEY `FK_USER_BED` (`CREATOR`),
  KEY `CHARGE_ID` (`COST_ID`),
  CONSTRAINT `FK_REGION_BED` FOREIGN KEY (`REGION_ID`) REFERENCES `dic_bed_region` (`id`),
  CONSTRAINT `FK_USER_BED` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_bed_ibfk_1` FOREIGN KEY (`COST_ID`) REFERENCES `dic_cost` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_bed
-- ----------------------------
INSERT INTO `his_bed` VALUES ('206', '161', 'A01', '79', '', '2', '1021', '2018-03-13 13:57:14', '2018-03-13 13:57:14');
INSERT INTO `his_bed` VALUES ('207', '162', 'B01', '81', '', '2', '1021', '2018-03-13 13:58:35', '2018-03-13 13:58:35');
INSERT INTO `his_bed` VALUES ('208', '162', 'B02', '81', '', '2', '1021', '2018-03-13 13:59:00', '2018-03-13 13:59:00');
INSERT INTO `his_bed` VALUES ('209', '162', 'B03', '79', '', '2', '1021', '2018-03-13 13:59:45', '2018-03-13 13:59:45');
INSERT INTO `his_bed` VALUES ('210', '162', 'B04', '81', '', '2', '1021', '2018-03-13 14:00:08', '2018-03-13 14:00:08');
INSERT INTO `his_bed` VALUES ('211', '162', 'B05', '81', '', '2', '1021', '2018-03-13 14:00:26', '2018-03-13 14:00:26');
INSERT INTO `his_bed` VALUES ('212', '162', 'B06', '81', '', '2', '1021', '2018-03-13 14:00:50', '2018-03-13 14:01:03');

-- ----------------------------
-- Table structure for his_bed_use
-- ----------------------------
DROP TABLE IF EXISTS `his_bed_use`;
CREATE TABLE `his_bed_use` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：HIS_BED，外键字段：ID',
  `MEMBER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FK_BED_USER` (`BED_ID`),
  UNIQUE KEY `FK_MEMBER_BED` (`MEMBER_ID`),
  CONSTRAINT `FK_BED_USER` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `FK_MEMBER_BED` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=328 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_bed_use
-- ----------------------------
INSERT INTO `his_bed_use` VALUES ('321', '206', '432');
INSERT INTO `his_bed_use` VALUES ('322', '207', '433');
INSERT INTO `his_bed_use` VALUES ('323', '208', '434');
INSERT INTO `his_bed_use` VALUES ('324', '209', '435');
INSERT INTO `his_bed_use` VALUES ('325', '210', '436');
INSERT INTO `his_bed_use` VALUES ('326', '211', '438');
INSERT INTO `his_bed_use` VALUES ('327', '212', '437');

-- ----------------------------
-- Table structure for his_callback
-- ----------------------------
DROP TABLE IF EXISTS `his_callback`;
CREATE TABLE `his_callback` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `SOURCE` tinyint(4) NOT NULL COMMENT '咨询回访-1，投诉回访-2，订单回访-3',
  `SOURCE_ID` int(11) NOT NULL COMMENT '咨询ID，投诉ID，订单ID',
  `WAY` tinyint(4) DEFAULT NULL COMMENT '电话回访-1，上门回访-2',
  `CONTENT` varchar(100) DEFAULT NULL COMMENT '回访内容',
  `CALLBACK_PERSON` varchar(10) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_CALLBACK_CREATOR` (`CREATOR`),
  CONSTRAINT `FK_CALLBACK_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=375 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_callback
-- ----------------------------
INSERT INTO `his_callback` VALUES ('372', '1', '266', '1', '身体健康状况，家庭状况。', '陈磊', '1021', '2017-03-20 10:05:07');
INSERT INTO `his_callback` VALUES ('373', '1', '274', '1', '123', '小明', '1021', '2018-05-24 10:08:19');
INSERT INTO `his_callback` VALUES ('374', '1', '274', '1', '123', '小红', '1021', '2018-05-24 10:08:39');

-- ----------------------------
-- Table structure for his_charge
-- ----------------------------
DROP TABLE IF EXISTS `his_charge`;
CREATE TABLE `his_charge` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `CHECKIN_DATE` date DEFAULT NULL COMMENT '试入住时为试入住时间',
  `CHECKIN_DURATION` int(11) DEFAULT NULL COMMENT '单位天，试入住时为试住时长',
  `CHECKOUT_DATE` date DEFAULT NULL COMMENT '试入住时为试入住到期时间',
  `PAY_TYPE` tinyint(4) DEFAULT NULL COMMENT '月度缴费-1，季度缴费-2，半年度缴费-3，年度缴费-4，试入住缴费-5',
  `FIRST_PAY_DATE` date DEFAULT NULL COMMENT '初次缴费日期',
  `STATEMENT_DATE` tinyint(4) DEFAULT NULL COMMENT '缴费账单日[1-28]',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '0-试入住，1-正式入住',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_charge_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_charge_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_charge
-- ----------------------------
INSERT INTO `his_charge` VALUES ('490', '432', '2017-04-28', '31', '2017-05-28', '5', '2018-03-13', '1', '0', '1022', '2018-03-13 14:05:39', null);
INSERT INTO `his_charge` VALUES ('491', '432', '2017-05-28', '655', '2019-03-13', '1', '2018-03-13', '1', '1', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge` VALUES ('492', '433', '2018-01-03', '32', '2018-02-03', '5', '2018-01-03', '1', '0', '1022', '2018-03-13 15:04:00', null);
INSERT INTO `his_charge` VALUES ('493', '433', '2018-02-03', '3', '2018-02-05', '1', '2018-03-13', '1', '1', '1022', '2018-03-13 15:05:20', null);
INSERT INTO `his_charge` VALUES ('494', '434', '2018-03-05', '2', '2018-03-06', '5', '2018-03-05', '1', '0', '1022', '2018-03-13 15:27:46', null);
INSERT INTO `his_charge` VALUES ('495', '435', '2018-03-12', '2', '2018-03-13', '5', '2018-03-13', '1', '0', '1022', '2018-03-13 15:49:16', null);
INSERT INTO `his_charge` VALUES ('496', '436', '2017-03-06', '1', '2017-03-06', '5', '2017-03-06', '1', '0', '1022', '2018-03-13 16:24:27', null);
INSERT INTO `his_charge` VALUES ('497', '436', '2017-04-06', '1', '2017-04-06', '1', '2018-03-13', '1', '1', '1022', '2018-03-13 16:25:05', null);
INSERT INTO `his_charge` VALUES ('498', '438', '2018-03-03', '1', '2018-03-03', '5', '2018-03-03', '1', '0', '1022', '2018-03-13 17:01:53', null);
INSERT INTO `his_charge` VALUES ('499', '437', '2018-03-13', '1', '2018-03-13', '5', '2018-03-13', '1', '0', '1022', '2018-03-13 17:02:14', null);

-- ----------------------------
-- Table structure for his_charge_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_charge_detail`;
CREATE TABLE `his_charge_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CHARGE_RECORD_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_CHARGE，外键字段：ID',
  `COST_ID` int(11) DEFAULT NULL COMMENT '外键表：DIC_COST，外键字段：ID',
  `MATERIAL_ID` int(11) DEFAULT NULL COMMENT '外键表：DIC_MATERIAL_CATEGORY，外键字段：ID',
  `COST_TYPE` tinyint(4) DEFAULT NULL COMMENT '基本费用-1，押金费用-2，其他费用-3',
  `COST_COUNT` tinyint(4) DEFAULT NULL,
  `COST_TOTAL` decimal(6,1) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CHARGE_ID` (`CHARGE_RECORD_ID`),
  KEY `COST_ID` (`COST_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `MATERIAL_CATEGORY_ID` (`MATERIAL_ID`),
  CONSTRAINT `his_charge_detail_ibfk_2` FOREIGN KEY (`COST_ID`) REFERENCES `dic_cost` (`id`),
  CONSTRAINT `his_charge_detail_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_charge_detail_ibfk_4` FOREIGN KEY (`MATERIAL_ID`) REFERENCES `dic_material_category` (`ID`),
  CONSTRAINT `his_charge_detail_ibfk_5` FOREIGN KEY (`CHARGE_RECORD_ID`) REFERENCES `his_charge_record` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2744 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_charge_detail
-- ----------------------------
INSERT INTO `his_charge_detail` VALUES ('2550', '656', '79', null, '1', null, '1605.2', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2551', '656', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2552', '656', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2553', '656', '85', null, '1', null, '100.3', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2554', '656', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2555', '656', '80', null, '2', null, '1000.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2556', '656', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2557', '656', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2558', '656', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2559', '656', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2560', '656', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:05:39');
INSERT INTO `his_charge_detail` VALUES ('2561', '657', '79', null, '1', null, '206.5', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2562', '657', '83', null, '1', null, '60.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2563', '657', '84', null, '1', null, '120.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2564', '657', '85', null, '1', null, '12.9', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2565', '657', '86', null, '1', null, '2.2', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2566', '657', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2567', '657', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2568', '657', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2569', '657', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2570', '657', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:07:29');
INSERT INTO `his_charge_detail` VALUES ('2571', '658', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2572', '658', '83', null, '1', null, '450.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2573', '658', '84', null, '1', null, '900.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2574', '658', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2575', '658', '86', null, '1', null, '16.4', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2576', '658', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2577', '658', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2578', '658', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2579', '658', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2580', '658', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:07:52');
INSERT INTO `his_charge_detail` VALUES ('2581', '659', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2582', '659', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2583', '659', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2584', '659', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2585', '659', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2586', '659', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2587', '659', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2588', '659', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2589', '659', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2590', '659', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:07:58');
INSERT INTO `his_charge_detail` VALUES ('2591', '660', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2592', '660', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2593', '660', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2594', '660', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2595', '660', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2596', '660', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2597', '660', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2598', '660', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2599', '660', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2600', '660', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:08:04');
INSERT INTO `his_charge_detail` VALUES ('2601', '661', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2602', '661', '83', null, '1', null, '450.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2603', '661', '84', null, '1', null, '900.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2604', '661', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2605', '661', '86', null, '1', null, '16.4', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2606', '661', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2607', '661', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2608', '661', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2609', '661', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2610', '661', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2611', '661', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2612', '661', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:08:19');
INSERT INTO `his_charge_detail` VALUES ('2613', '662', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2614', '662', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2615', '662', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2616', '662', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2617', '662', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2618', '662', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2619', '662', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2620', '662', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2621', '662', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2622', '662', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2623', '662', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2624', '662', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:08:34');
INSERT INTO `his_charge_detail` VALUES ('2625', '663', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2626', '663', '83', null, '1', null, '450.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2627', '663', '84', null, '1', null, '900.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2628', '663', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2629', '663', '86', null, '1', null, '16.4', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2630', '663', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2631', '663', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2632', '663', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2633', '663', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2634', '663', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2635', '663', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2636', '663', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:08:56');
INSERT INTO `his_charge_detail` VALUES ('2637', '664', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2638', '664', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2639', '664', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2640', '664', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2641', '664', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2642', '664', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2643', '664', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2644', '664', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2645', '664', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2646', '664', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2647', '664', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2648', '664', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:09:11');
INSERT INTO `his_charge_detail` VALUES ('2649', '665', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2650', '665', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2651', '665', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2652', '665', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2653', '665', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2654', '665', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2655', '665', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2656', '665', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2657', '665', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2658', '665', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2659', '665', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2660', '665', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:09:19');
INSERT INTO `his_charge_detail` VALUES ('2661', '666', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2662', '666', '83', null, '1', null, '420.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2663', '666', '84', null, '1', null, '840.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2664', '666', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2665', '666', '86', null, '1', null, '15.3', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2666', '666', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2667', '666', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2668', '666', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2669', '666', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2670', '666', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2671', '666', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2672', '666', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:09:27');
INSERT INTO `his_charge_detail` VALUES ('2673', '667', '79', null, '1', null, '1600.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2674', '667', '83', null, '1', null, '465.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2675', '667', '84', null, '1', null, '930.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2676', '667', '85', null, '1', null, '100.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2677', '667', '86', null, '1', null, '17.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2678', '667', null, '109', '3', '1', '100.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2679', '667', null, '105', '3', '1', '10.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2680', '667', null, '106', '3', '1', '10.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2681', '667', null, '108', '3', '1', '20.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2682', '667', null, '107', '3', '1', '15.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2683', '667', null, '110', '3', '1', '20.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2684', '667', null, '111', '3', '1', '30.0', '1022', '2018-03-13 14:09:51');
INSERT INTO `his_charge_detail` VALUES ('2685', '680', '81', null, '1', null, '312.7', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2686', '680', '80', null, '2', null, '1000.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2687', '680', null, '106', '3', '1', '10.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2688', '680', null, '108', '3', '1', '20.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2689', '680', null, '105', '3', '1', '10.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2690', '680', null, '107', '3', '1', '15.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2691', '680', null, '109', '3', '1', '100.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2692', '680', null, '110', '3', '1', '20.0', '1022', '2018-03-13 15:04:00');
INSERT INTO `his_charge_detail` VALUES ('2693', '681', '81', null, '1', null, '32.1', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2694', '681', null, '108', '3', '1', '20.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2695', '681', null, '106', '3', '1', '10.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2696', '681', null, '107', '3', '1', '15.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2697', '681', null, '105', '3', '1', '10.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2698', '681', null, '109', '3', '1', '100.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2699', '681', null, '110', '3', '1', '20.0', '1022', '2018-03-13 15:05:20');
INSERT INTO `his_charge_detail` VALUES ('2700', '682', '81', null, '1', null, '19.4', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2701', '682', '80', null, '2', null, '1000.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2702', '682', null, '106', '3', '1', '10.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2703', '682', null, '107', '3', '1', '15.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2704', '682', null, '108', '3', '1', '20.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2705', '682', null, '105', '3', '1', '10.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2706', '682', null, '109', '3', '1', '100.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2707', '682', null, '110', '3', '1', '20.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2708', '682', null, '111', '3', '1', '30.0', '1022', '2018-03-13 15:27:46');
INSERT INTO `his_charge_detail` VALUES ('2709', '683', '81', null, '1', null, '19.4', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2710', '683', '82', null, '1', null, '16.4', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2711', '683', '85', null, '1', null, '6.5', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2712', '683', '80', null, '2', null, '1000.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2713', '683', null, '110', '3', '1', '20.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2714', '683', null, '111', '3', '1', '30.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2715', '683', null, '108', '3', '1', '20.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2716', '683', null, '105', '3', '1', '10.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2717', '683', null, '107', '3', '1', '15.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2718', '683', null, '106', '3', '1', '10.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2719', '683', null, '109', '3', '1', '100.0', '1022', '2018-03-13 15:49:16');
INSERT INTO `his_charge_detail` VALUES ('2720', '684', '81', null, '1', null, '9.7', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2721', '684', '80', null, '2', null, '1000.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2722', '684', null, '111', '3', '1', '30.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2723', '684', null, '110', '3', '1', '20.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2724', '684', null, '109', '3', '1', '100.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2725', '684', null, '106', '3', '1', '10.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2726', '684', null, '108', '3', '1', '20.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2727', '684', null, '105', '3', '1', '10.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2728', '684', null, '107', '3', '1', '15.0', '1022', '2018-03-13 16:24:27');
INSERT INTO `his_charge_detail` VALUES ('2729', '685', '81', null, '1', null, '10.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2730', '685', null, '109', '3', '1', '100.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2731', '685', null, '110', '3', '1', '20.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2732', '685', null, '111', '3', '1', '30.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2733', '685', null, '108', '3', '1', '20.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2734', '685', null, '107', '3', '1', '15.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2735', '685', null, '106', '3', '1', '10.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2736', '685', null, '105', '3', '1', '10.0', '1022', '2018-03-13 16:25:05');
INSERT INTO `his_charge_detail` VALUES ('2737', '686', '81', null, '1', null, '9.7', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2738', '686', '80', null, '2', null, '1000.0', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2739', '686', null, '109', '3', '1', '100.0', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2740', '686', null, '111', '3', '1', '30.0', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2741', '686', null, '107', '3', '1', '15.0', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2742', '686', null, '108', '3', '1', '20.0', '1022', '2018-03-13 17:01:53');
INSERT INTO `his_charge_detail` VALUES ('2743', '687', '81', null, '1', null, '9.7', '1022', '2018-03-13 17:02:14');

-- ----------------------------
-- Table structure for his_charge_record
-- ----------------------------
DROP TABLE IF EXISTS `his_charge_record`;
CREATE TABLE `his_charge_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CHARGE_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_CHARGE，外键字段：ID',
  `BED_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_BED，外键字段：ID',
  `CHECK_NUMS` tinyint(4) DEFAULT NULL,
  `CHECKIN_DATE` date DEFAULT NULL COMMENT '本期账单的起始日期',
  `CHECKIN_DURATION` int(11) DEFAULT NULL COMMENT '单位天，试入住时为试住时长',
  `CHECKOUT_DATE` date DEFAULT NULL COMMENT '本期账单的结束日期',
  `NEED_COST` decimal(6,1) DEFAULT NULL COMMENT '单位元',
  `RETURN_COST` decimal(6,1) DEFAULT NULL COMMENT '单位元',
  `REAL_COST` decimal(6,1) DEFAULT NULL COMMENT '单位元',
  `PAY_TIME` date DEFAULT NULL COMMENT '当期账单账单日日期，可用于缴费提醒',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '0-未缴，1-已缴，默认0',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CHARGE_ID` (`CHARGE_ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_charge_record_ibfk_1` FOREIGN KEY (`CHARGE_ID`) REFERENCES `his_charge` (`ID`),
  CONSTRAINT `his_charge_record_ibfk_2` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_charge_record_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_charge_record
-- ----------------------------
INSERT INTO `his_charge_record` VALUES ('656', '490', '206', '1', '2017-04-28', '31', '2017-05-28', '4287.5', '0.0', '4288.0', '2017-04-01', '1', '1022', '2018-03-13 14:05:39', '2018-03-13 14:05:39');
INSERT INTO `his_charge_record` VALUES ('657', '491', '206', '1', '2017-05-28', '4', '2017-05-31', '571.6', '0.0', '572.0', '2017-05-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:07:29');
INSERT INTO `his_charge_record` VALUES ('658', '491', '206', '2', '2017-06-01', '30', '2017-06-30', '3236.4', '0.0', '3236.0', '2017-06-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:07:52');
INSERT INTO `his_charge_record` VALUES ('659', '491', '206', '3', '2017-07-01', '31', '2017-07-31', '3282.0', '0.0', '3282.0', '2017-07-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:07:58');
INSERT INTO `his_charge_record` VALUES ('660', '491', '206', '4', '2017-08-01', '31', '2017-08-31', '3282.0', '0.0', '3282.0', '2017-08-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:08:04');
INSERT INTO `his_charge_record` VALUES ('661', '491', '206', '5', '2017-09-01', '30', '2017-09-30', '3271.4', '0.0', '3271.0', '2017-09-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:08:19');
INSERT INTO `his_charge_record` VALUES ('662', '491', '206', '6', '2017-10-01', '31', '2017-10-31', '3317.0', '0.0', '3317.0', '2017-10-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:08:34');
INSERT INTO `his_charge_record` VALUES ('663', '491', '206', '7', '2017-11-01', '30', '2017-11-30', '3271.4', '0.0', '3271.0', '2017-11-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:08:56');
INSERT INTO `his_charge_record` VALUES ('664', '491', '206', '8', '2017-12-01', '31', '2017-12-31', '3317.0', '0.0', '3317.0', '2017-12-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:09:11');
INSERT INTO `his_charge_record` VALUES ('665', '491', '206', '9', '2018-01-01', '31', '2018-01-31', '3317.0', '0.0', '3317.0', '2018-01-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:09:19');
INSERT INTO `his_charge_record` VALUES ('666', '491', '206', '10', '2018-02-01', '28', '2018-02-28', '3180.3', '0.0', '3180.0', '2018-02-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:09:27');
INSERT INTO `his_charge_record` VALUES ('667', '491', '206', '11', '2018-03-01', '31', '2018-03-31', '3317.0', '0.0', '3317.0', '2018-03-01', '1', '1022', '2018-03-13 14:07:29', '2018-03-13 14:09:51');
INSERT INTO `his_charge_record` VALUES ('668', '491', '206', '12', '2018-04-01', '30', '2018-04-30', null, null, null, '2018-04-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('669', '491', '206', '13', '2018-05-01', '31', '2018-05-31', null, null, null, '2018-05-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('670', '491', '206', '14', '2018-06-01', '30', '2018-06-30', null, null, null, '2018-06-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('671', '491', '206', '15', '2018-07-01', '31', '2018-07-31', null, null, null, '2018-07-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('672', '491', '206', '16', '2018-08-01', '31', '2018-08-31', null, null, null, '2018-08-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('673', '491', '206', '17', '2018-09-01', '30', '2018-09-30', null, null, null, '2018-09-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('674', '491', '206', '18', '2018-10-01', '31', '2018-10-31', null, null, null, '2018-10-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('675', '491', '206', '19', '2018-11-01', '30', '2018-11-30', null, null, null, '2018-11-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('676', '491', '206', '20', '2018-12-01', '31', '2018-12-31', null, null, null, '2018-12-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('677', '491', '206', '21', '2019-01-01', '31', '2019-01-31', null, null, null, '2019-01-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('678', '491', '206', '22', '2019-02-01', '28', '2019-02-28', null, null, null, '2019-02-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('679', '491', '206', '23', '2019-03-01', '13', '2019-03-13', null, null, null, '2019-03-01', '0', '1022', '2018-03-13 14:07:29', null);
INSERT INTO `his_charge_record` VALUES ('680', '492', '207', '1', '2018-01-03', '32', '2018-02-03', '1487.7', '0.0', '1488.0', '2018-01-01', '1', '1022', '2018-03-13 15:04:00', '2018-03-13 15:04:00');
INSERT INTO `his_charge_record` VALUES ('681', '493', '207', '1', '2018-02-03', '3', '2018-02-05', '207.1', '0.0', '207.0', '2018-02-01', '1', '1022', '2018-03-13 15:05:20', '2018-03-13 15:05:20');
INSERT INTO `his_charge_record` VALUES ('682', '494', '208', '1', '2018-03-05', '2', '2018-03-06', '1224.4', '0.0', '1224.0', '2018-03-01', '1', '1022', '2018-03-13 15:27:46', '2018-03-13 15:27:46');
INSERT INTO `his_charge_record` VALUES ('683', '495', '209', '1', '2018-03-12', '2', '2018-03-13', '1247.3', '0.0', '1247.0', '2018-03-01', '1', '1022', '2018-03-13 15:49:16', '2018-03-13 15:49:16');
INSERT INTO `his_charge_record` VALUES ('684', '496', '210', '1', '2017-03-06', '1', '2017-03-06', '1214.7', '0.0', '1215.0', '2017-03-01', '1', '1022', '2018-03-13 16:24:27', '2018-03-13 16:24:27');
INSERT INTO `his_charge_record` VALUES ('685', '497', '210', '1', '2017-04-06', '1', '2017-04-06', '215.0', '0.0', '215.0', '2017-04-01', '1', '1022', '2018-03-13 16:25:05', '2018-03-13 16:25:05');
INSERT INTO `his_charge_record` VALUES ('686', '498', '211', '1', '2018-03-03', '1', '2018-03-03', '1174.7', '0.0', '1175.0', '2018-03-01', '1', '1022', '2018-03-13 17:01:53', '2018-03-13 17:01:53');
INSERT INTO `his_charge_record` VALUES ('687', '499', '212', '1', '2018-03-13', '1', '2018-03-13', '9.7', '0.0', '10.0', '2018-03-01', '1', '1022', '2018-03-13 17:02:14', '2018-03-13 17:02:14');

-- ----------------------------
-- Table structure for his_checkup_attachment
-- ----------------------------
DROP TABLE IF EXISTS `his_checkup_attachment`;
CREATE TABLE `his_checkup_attachment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CHECKUP_ID` int(3) NOT NULL DEFAULT '0',
  `ATTACHMENT_ID` int(11) NOT NULL DEFAULT '0',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CHECKUP_ID` (`CHECKUP_ID`),
  KEY `ATTACHMENT_ID` (`ATTACHMENT_ID`),
  CONSTRAINT `his_checkup_attachment_ibfk_1` FOREIGN KEY (`CHECKUP_ID`) REFERENCES `his_member_checkup` (`ID`),
  CONSTRAINT `his_checkup_attachment_ibfk_2` FOREIGN KEY (`ATTACHMENT_ID`) REFERENCES `his_attachment` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8 COMMENT='体检附件中间表';

-- ----------------------------
-- Records of his_checkup_attachment
-- ----------------------------
INSERT INTO `his_checkup_attachment` VALUES ('286', '371', '835', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('287', '372', '836', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('288', '373', '841', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('289', '374', '842', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('290', '375', '843', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('291', '376', '844', null, null);
INSERT INTO `his_checkup_attachment` VALUES ('292', '377', '845', null, null);

-- ----------------------------
-- Table structure for his_consult
-- ----------------------------
DROP TABLE IF EXISTS `his_consult`;
CREATE TABLE `his_consult` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `CONSULT_TYPE` tinyint(4) NOT NULL COMMENT '外键表：DIC__CONSULT_CATEGORY，外键：ID',
  `NAME` varchar(10) NOT NULL,
  `AGE` tinyint(4) DEFAULT NULL,
  `MOBILE` char(15) DEFAULT NULL,
  `TEL` char(15) DEFAULT NULL,
  `ADDRESS` varchar(50) DEFAULT NULL,
  `MEMBER_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER,外键字段：ID',
  `MEMBER_RELATIONSHIP` tinyint(4) DEFAULT NULL COMMENT '本人-1，子女-2，亲戚-3，朋友-4',
  `CONTENT` varchar(200) NOT NULL,
  `SOURCE_TYPE` tinyint(4) NOT NULL COMMENT '登记方式：来电-1，来访-2',
  `RECEIVER` varchar(10) DEFAULT NULL,
  `VISIT_DATE` date DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '处理状态：已处理-1，需反馈-2',
  `CHECK_INTENTION` tinyint(4) DEFAULT NULL COMMENT '近期入住-1，将来入住-2，不会入住-3',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `REMARK` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CONSULT_TYPE` (`CONSULT_TYPE`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_consult_ibfk_1` FOREIGN KEY (`CONSULT_TYPE`) REFERENCES `dic_consult_category` (`ID`),
  CONSTRAINT `his_consult_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_consult_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_consult
-- ----------------------------
INSERT INTO `his_consult` VALUES ('266', '3', '宋欣荣', '56', '17600060666', null, '北京 市辖区 东城区 ', '432', '1', '养老入住条件及费用', '2', '陈磊', '2017-03-13', '2', '2', '1021', '2018-03-13 10:02:03', '状态良好，行动语言流利。');
INSERT INTO `his_consult` VALUES ('267', '2', '王卫国', '68', '15632251252', null, '北京市昌平区北七家镇平西王府村', '433', '1', '入住养老院所需具备的条件及收费、服务信息。', '2', '陈磊', '2016-11-15', '2', '2', '1021', '2018-03-13 14:48:46', '');
INSERT INTO `his_consult` VALUES ('268', '2', '石光荣', '88', '18922231643', null, '北京市西城区', '434', '2', '咨询入住信息', '1', '陈磊', '2018-03-03', '2', '1', '1021', '2018-03-13 15:14:23', '');
INSERT INTO `his_consult` VALUES ('269', '2', '褚琴', '60', '15912135431', null, '北京市昌平区沙河镇于辛庄村', '435', '1', '入住情况、活动、资费', '2', '陈磊', '2018-03-10', '2', '1', '1021', '2018-03-13 15:40:50', '');
INSERT INTO `his_consult` VALUES ('270', '2', '杨大海', '65', '13313455463', null, '北京市海淀区', '436', '1', '入住养老院所需要求', '2', '陈磊', '2017-03-03', '2', '1', '1021', '2018-03-13 16:17:16', '');
INSERT INTO `his_consult` VALUES ('271', '2', '陈健', '65', '15632255435', null, '北京市昌平区', '437', '1', '入住咨询', '1', '陈磊', '2018-03-01', '2', '1', '1021', '2018-03-13 16:53:16', '');
INSERT INTO `his_consult` VALUES ('272', '2', '江涛', '69', '15632252315', null, '北京市', '438', '1', '入住咨询', '2', '陈磊', '2018-03-03', '2', '1', '1021', '2018-03-13 16:55:30', '');
INSERT INTO `his_consult` VALUES ('273', '19', '冯建军', '56', '13673687689', null, '北京市昌平区', '439', '1', '费用咨询', '1', '陈磊', '2018-03-14', '1', '1', '1021', '2018-03-14 15:37:27', '');
INSERT INTO `his_consult` VALUES ('274', '2', '李亚鹏', '60', '13044678971', null, '北京市昌平区', '440', '1', '入院咨询', '2', '陈磊', '2018-05-23', '2', '1', '1021', '2018-05-23 18:54:56', '无');

-- ----------------------------
-- Table structure for his_dict_check
-- ----------------------------
DROP TABLE IF EXISTS `his_dict_check`;
CREATE TABLE `his_dict_check` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键非空自增,字典表在总表的ID',
  `TAB_NAME` varchar(30) DEFAULT NULL,
  `TAB_ALIAS` varchar(30) DEFAULT NULL,
  `FLDS_NAME` varchar(100) DEFAULT NULL COMMENT '字段名用英文逗号分隔',
  `FLDS_ALIAS` varchar(100) DEFAULT NULL COMMENT '字段中文名，用英文逗号分隔',
  `FLDS_LENGTH` varchar(30) DEFAULT NULL COMMENT '字段长度，以英文逗号分隔',
  `IS_TREE` tinyint(4) DEFAULT NULL COMMENT '1-是，0-否',
  `SEQ_NO` tinyint(4) DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL COMMENT '字典表页面地址',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_dict_check
-- ----------------------------
INSERT INTO `his_dict_check` VALUES ('1', 'dic_consult_category', '咨询分类', 'category_name', '咨询类别', '15', '0', null, 'dicConsultType');
INSERT INTO `his_dict_check` VALUES ('2', 'dic_rate_category', '评级分类', 'category_name', '评级类别', '15', '0', null, 'dicRateCategory');
INSERT INTO `his_dict_check` VALUES ('3', 'dic_certificate_class', '证件分类', 'certificateType,className', '证件类型(身份证件-1，资质证件-2),证件名', '127,15', '0', null, 'dicCertificateClass');
INSERT INTO `his_dict_check` VALUES ('4', 'dic_district', '行政区划', 'parent,districtName,flag', '父节点ID,区域名称,状态', '11,15,127', '1', null, 'dicDistrict');
INSERT INTO `his_dict_check` VALUES ('5', 'dic_region', '商圈区域', 'district,regionName,pinyin,flag', '行政区域编号,商圈名称/地名/地标,拼音首字母,状态', '11,15,15,127', '1', null, 'dicRegion');
INSERT INTO `his_dict_check` VALUES ('6', 'dic_tag', '客户标签', 'tagName,tagType', '标签名,标签类型(1-用户标签)', '15,127', '0', null, 'dicTag');
INSERT INTO `his_dict_check` VALUES ('7', 'dic_bed_region', '床位区域', 'parent,districtName,flag', '父节点ID,区域名称,状态', '11,15,127', '1', null, 'dicBedRegion');
INSERT INTO `his_dict_check` VALUES ('8', 'dic_cost_category', '费用类别', 'categoryName,categoryType', '费用名称,费用类别(基本费用-1，押金费用-2，其他费用-3)', '15,3', '0', null, 'dicCostCategory');
INSERT INTO `his_dict_check` VALUES ('9', 'dic_material_category', '物资分类', 'parent,districtName,price,flag', '父节点ID,物资名称,价格,状态', '11,15,6,127', '1', null, 'dicMaterialCategory');
INSERT INTO `his_dict_check` VALUES ('10', 'dic_job_category', '工作岗位', 'jobName,flag', '岗位名称,状态(1-启用，0-停用)', '15,3', '0', null, 'dicJobCategory');
INSERT INTO `his_dict_check` VALUES ('11', 'dic_leave_type', '请假分类', 'leaveType', '请假类别', '15', '0', null, 'dicLeaveType');
INSERT INTO `his_dict_check` VALUES ('12', 'dic_nurse_grade', '护理等级', 'gradeName,minScore,maxScore,tricare', '等级名称,最小分数,最大分数,对照等级', '15,11,11,50', '0', null, 'dicNurseGrade');
INSERT INTO `his_dict_check` VALUES ('13', 'dic_activity_type', '活动类型', 'activityType', '活动类别', '15', '0', null, 'dicActivityType');
INSERT INTO `his_dict_check` VALUES ('14', 'dic_nurse_record_template', '护理内容模板', 'itemName', '护理内容模板', '100', '0', null, 'dicNurseRecordTemplate');

-- ----------------------------
-- Table structure for his_document
-- ----------------------------
DROP TABLE IF EXISTS `his_document`;
CREATE TABLE `his_document` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL DEFAULT '新建文件',
  `FLAG` tinyint(3) DEFAULT NULL COMMENT '停用-0，使用中-1，默认1',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_USER_DOCUMENT` (`CREATOR`),
  CONSTRAINT `FK_USER_DOCUMENT` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_document
-- ----------------------------
INSERT INTO `his_document` VALUES ('86', '公告', '1', '1021', '2018-03-13 15:19:00', '2018-03-13 15:19:00');
INSERT INTO `his_document` VALUES ('87', '节假日通知', '1', '1021', '2018-03-13 15:19:31', '2018-03-13 15:19:31');
INSERT INTO `his_document` VALUES ('88', '表现优秀员工奖励通知', '1', '1021', '2018-03-13 15:20:09', '2018-03-13 15:20:09');
INSERT INTO `his_document` VALUES ('89', '精神最佳老人奖', '1', '1021', '2018-03-13 15:20:59', '2018-03-13 15:20:59');

-- ----------------------------
-- Table structure for his_document_attachment
-- ----------------------------
DROP TABLE IF EXISTS `his_document_attachment`;
CREATE TABLE `his_document_attachment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DOCUMENT_ID` int(11) NOT NULL DEFAULT '0',
  `ATTACHMENT_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_DOCUMENT_ATTACHMENT` (`DOCUMENT_ID`),
  KEY `FK_ATTACHMENT_DOCUMENT` (`ATTACHMENT_ID`),
  CONSTRAINT `FK_ATTACHMENT_DOCUMENT` FOREIGN KEY (`ATTACHMENT_ID`) REFERENCES `his_attachment` (`Id`),
  CONSTRAINT `FK_DOCUMENT_ATTACHMENT` FOREIGN KEY (`DOCUMENT_ID`) REFERENCES `his_document` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_document_attachment
-- ----------------------------
INSERT INTO `his_document_attachment` VALUES ('109', '86', '837');
INSERT INTO `his_document_attachment` VALUES ('110', '87', '838');
INSERT INTO `his_document_attachment` VALUES ('111', '88', '839');
INSERT INTO `his_document_attachment` VALUES ('112', '89', '840');

-- ----------------------------
-- Table structure for his_employe
-- ----------------------------
DROP TABLE IF EXISTS `his_employe`;
CREATE TABLE `his_employe` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL DEFAULT '1',
  `EMPNO` char(10) DEFAULT NULL,
  `JOB_ID` int(11) NOT NULL DEFAULT '1',
  `FLAG` tinyint(3) DEFAULT NULL COMMENT '人员当前状态：1-正常，0-停用，默认1',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_USER_EMPLOYE` (`USER_ID`),
  KEY `FK_USER_CREATOR` (`CREATOR`),
  KEY `FK_JOB_EMPLOYE` (`JOB_ID`),
  CONSTRAINT `FK_JOB_EMPLOYE` FOREIGN KEY (`JOB_ID`) REFERENCES `dic_job_category` (`ID`),
  CONSTRAINT `FK_USER_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `FK_USER_EMPLOYE` FOREIGN KEY (`USER_ID`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_employe
-- ----------------------------
INSERT INTO `his_employe` VALUES ('101', '1025', 'A001', '2', '1', '1021', '2018-03-13 15:00:37', '2018-03-13 15:39:19');
INSERT INTO `his_employe` VALUES ('102', '1026', 'A002', '1', '1', '1021', '2018-03-13 15:01:13', '2018-03-13 15:01:13');
INSERT INTO `his_employe` VALUES ('103', '1027', 'A003', '2', '1', '1021', '2018-03-13 15:03:15', '2018-03-13 15:38:40');
INSERT INTO `his_employe` VALUES ('104', '1028', 'A004', '1', '1', '1021', '2018-03-13 15:04:36', '2018-03-13 15:04:36');
INSERT INTO `his_employe` VALUES ('105', '1029', 'A005', '2', '1', '1021', '2018-03-13 15:05:25', '2018-03-13 15:39:12');
INSERT INTO `his_employe` VALUES ('106', '1030', 'A006', '1', '1', '1021', '2018-03-13 15:06:11', '2018-03-13 15:06:11');
INSERT INTO `his_employe` VALUES ('107', '1031', 'A007', '2', '1', '1021', '2018-03-13 15:07:43', '2018-03-13 15:39:00');

-- ----------------------------
-- Table structure for his_employe_duty_area
-- ----------------------------
DROP TABLE IF EXISTS `his_employe_duty_area`;
CREATE TABLE `his_employe_duty_area` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMPLOYE_ID` int(10) DEFAULT NULL,
  `DUTY_AREA_ID` int(11) DEFAULT NULL,
  `BEDS` varchar(500) DEFAULT NULL COMMENT '逗号分隔的床位ID',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `EMPLOYE_ID` (`EMPLOYE_ID`),
  KEY `DUTY_AREA_ID` (`DUTY_AREA_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_employe_duty_area_ibfk_1` FOREIGN KEY (`EMPLOYE_ID`) REFERENCES `his_employe` (`ID`),
  CONSTRAINT `his_employe_duty_area_ibfk_2` FOREIGN KEY (`DUTY_AREA_ID`) REFERENCES `dic_duty_area` (`ID`),
  CONSTRAINT `his_employe_duty_area_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_employe_duty_area
-- ----------------------------
INSERT INTO `his_employe_duty_area` VALUES ('104', '107', '75', '206,207', '1021', '2018-03-13 15:08:14', '2018-03-13 18:26:58');
INSERT INTO `his_employe_duty_area` VALUES ('105', '106', '75', '206,207', '1021', '2018-03-13 15:08:22', '2018-03-13 18:27:04');
INSERT INTO `his_employe_duty_area` VALUES ('106', '105', '75', '208', '1021', '2018-03-13 15:08:39', null);
INSERT INTO `his_employe_duty_area` VALUES ('107', '104', '75', '209', '1021', '2018-03-13 15:08:47', null);
INSERT INTO `his_employe_duty_area` VALUES ('108', '103', '69', null, '1021', '2018-03-13 15:08:53', '2018-03-13 18:31:31');
INSERT INTO `his_employe_duty_area` VALUES ('109', '102', '75', '211', '1021', '2018-03-13 15:09:01', null);
INSERT INTO `his_employe_duty_area` VALUES ('110', '101', '75', '212', '1021', '2018-03-13 15:09:12', null);

-- ----------------------------
-- Table structure for his_eva_answer
-- ----------------------------
DROP TABLE IF EXISTS `his_eva_answer`;
CREATE TABLE `his_eva_answer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `QUESTION_ID` int(11) NOT NULL COMMENT '外键表：HIS_EVA_QUESTION，外键字段：ID',
  `TITLE` varchar(100) DEFAULT NULL,
  `SEQ_NO` tinyint(4) DEFAULT NULL COMMENT '问题序号，默认按增加顺序递增',
  `SCORE` tinyint(4) DEFAULT NULL COMMENT '答案的分值',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `QUESTION_ID` (`QUESTION_ID`),
  CONSTRAINT `his_eva_answer_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_eva_answer_ibfk_2` FOREIGN KEY (`QUESTION_ID`) REFERENCES `his_eva_question` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_eva_answer
-- ----------------------------
INSERT INTO `his_eva_answer` VALUES ('1', '65', '准确', '0', '5', null, null);
INSERT INTO `his_eva_answer` VALUES ('2', '65', '与实际年龄相差2岁以内', '0', '10', null, null);
INSERT INTO `his_eva_answer` VALUES ('3', '65', '与实际年龄相差2岁以外', '0', '10', null, null);
INSERT INTO `his_eva_answer` VALUES ('4', '66', '1个正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('5', '66', '2个正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('6', '66', '3个正确', '0', '3', null, null);
INSERT INTO `his_eva_answer` VALUES ('7', '66', '4个正确', '0', '4', null, null);
INSERT INTO `his_eva_answer` VALUES ('8', '67', '回答正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('9', '67', '提示后正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('10', '67', '提示后错误', '0', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('11', '68', '1个正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('12', '68', '2个正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('13', '68', '3个正确', '0', '3', null, null);
INSERT INTO `his_eva_answer` VALUES ('14', '69', '正确', '0', '5', null, null);
INSERT INTO `his_eva_answer` VALUES ('15', '69', '不正确', '0', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('16', '70', '正确', '0', '5', null, null);
INSERT INTO `his_eva_answer` VALUES ('17', '70', '不正确', '0', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('18', '71', '1个正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('19', '71', '2个正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('20', '71', '3个正确', '0', '3', null, null);
INSERT INTO `his_eva_answer` VALUES ('21', '71', '4个正确', '0', '4', null, null);
INSERT INTO `his_eva_answer` VALUES ('22', '72', '1个正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('23', '72', '2个正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('24', '72', '3个正确', '0', '3', null, null);
INSERT INTO `his_eva_answer` VALUES ('25', '72', '4个以上正确', '0', '4', null, null);
INSERT INTO `his_eva_answer` VALUES ('26', '73', '0-5个正确', '0', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('27', '73', '6个正确', '0', '1', null, null);
INSERT INTO `his_eva_answer` VALUES ('28', '73', '7个正确', '0', '2', null, null);
INSERT INTO `his_eva_answer` VALUES ('29', '73', '8个正确', '0', '3', null, null);
INSERT INTO `his_eva_answer` VALUES ('30', '73', '9个正确', '0', '4', null, null);
INSERT INTO `his_eva_answer` VALUES ('31', '73', '10个以上正确', '0', '5', null, null);
INSERT INTO `his_eva_answer` VALUES ('32', '1', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('33', '1', '左上肢', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('34', '1', '右上肢', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('35', '1', '左下肢', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('36', '1', '其他（四肢缺陷）', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('37', '2', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('38', '2', '肩关节', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('39', '2', '胯关节', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('40', '2', '膝关节', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('41', '2', '其他（四肢缺陷）', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('42', '3', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('43', '3', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('44', '3', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('45', '4', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('46', '4', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('47', '4', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('48', '5', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('49', '5', '自己用手撑着可以维持', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('50', '5', '被人扶着可以维持', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('51', '5', '不能', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('52', '6', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('53', '6', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('54', '6', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('55', '7', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('56', '7', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('57', '7', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('58', '8', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('59', '8', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('60', '8', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('61', '9', '可以自主', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('62', '9', '在一定辅助下可以', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('63', '9', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('64', '10', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('65', '10', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('66', '10', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('67', '10', '不能', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('68', '11', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('69', '11', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('70', '11', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('71', '12', '普通（无碍日常生活）', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('72', '12', '能看到约一米远的视力确认表的图形', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('73', '12', '能够看到放在眼前的实力确认表', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('74', '12', '几乎看不见', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('75', '12', '无法判断', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('76', '13', '普通', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('77', '13', '平时勉强能听见，也有听错或听不见的情况', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('78', '13', '很大声才能听见', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('79', '13', '几乎听不见', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('80', '13', '无法判断', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('81', '14', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('82', '14', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('83', '14', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('84', '14', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('85', '15', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('86', '15', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('87', '15', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('88', '15', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('89', '16', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('90', '16', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('91', '16', '不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('92', '17', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('93', '17', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('94', '17', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('95', '17', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('96', '18', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('97', '18', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('98', '18', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('99', '18', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('100', '19', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('101', '19', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('102', '19', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('103', '19', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('104', '20', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('105', '20', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('106', '20', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('107', '21', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('108', '21', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('109', '21', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('110', '22', '自理', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('111', '22', '需要一定的辅助', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('112', '22', '完全依赖辅助', '6', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('113', '23', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('114', '23', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('115', '23', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('116', '24', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('117', '24', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('118', '24', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('119', '25', '每周一次', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('120', '25', '每月一次', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('121', '25', '每月不到一次', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('122', '26', '能够向他人传递自己的想法', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('123', '26', '有时能有时不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('124', '26', '几乎不能', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('125', '26', '不能', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('126', '27', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('127', '27', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('128', '28', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('129', '28', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('130', '29', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('131', '29', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('132', '30', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('133', '30', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('134', '31', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('135', '31', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('136', '32', '可以', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('137', '32', '不能', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('138', '33', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('139', '33', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('140', '33', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('141', '34', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('142', '34', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('143', '34', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('144', '35', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('145', '35', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('146', '35', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('147', '36', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('148', '36', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('149', '36', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('150', '37', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('151', '37', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('152', '37', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('153', '38', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('154', '38', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('155', '38', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('156', '39', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('157', '39', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('158', '39', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('159', '40', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('160', '40', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('161', '40', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('162', '41', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('163', '41', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('164', '41', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('165', '42', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('166', '42', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('167', '42', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('168', '43', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('169', '43', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('170', '43', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('171', '44', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('172', '44', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('173', '44', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('174', '45', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('175', '45', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('176', '45', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('177', '46', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('178', '46', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('179', '46', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('180', '47', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('181', '47', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('182', '47', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('183', '48', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('184', '48', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('185', '48', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('186', '49', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('187', '49', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('188', '49', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('189', '50', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('190', '50', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('191', '50', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('192', '50', '不能', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('193', '51', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('194', '51', '需要一定的辅助', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('195', '51', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('196', '52', '可以（即便是特殊场合也可以）', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('197', '52', '除了特殊场合之外', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('198', '52', '常规的都困难', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('199', '52', '不能', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('200', '53', '没有', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('201', '53', '有时', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('202', '53', '有', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('204', '54', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('205', '54', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('206', '54', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('207', '54', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('208', '55', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('209', '55', '需要旁边有人看着', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('210', '55', '需要一定的辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('211', '55', '完全依赖辅助', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('212', '56', '输液', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('213', '56', '肠外营养输液', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('214', '56', '透析', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('215', '56', '肛门的处理', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('216', '56', '氧疗', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('217', '56', '人工呼吸器', '6', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('218', '56', '气管切开', '7', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('219', '56', '疼痛的护理', '8', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('220', '56', '肠内营养', '9', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('221', '57', '监控测定（血压、心跳数、氧饱和度等）', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('222', '57', '褥疮的处置', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('223', '57', '导尿管', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('224', '58', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('225', '58', 'J 1', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('226', '58', 'J 2', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('227', '58', 'A 1', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('228', '58', 'A 2', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('229', '58', 'B 1', '6', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('230', '58', 'B 2', '7', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('231', '58', 'C 1', '8', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('232', '58', 'C 2', '9', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('233', '59', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('234', '59', 'Ⅰ', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('235', '59', 'Ⅱ a', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('236', '59', 'Ⅱ b', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('237', '59', 'Ⅲ a', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('238', '59', 'Ⅲ b', '6', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('239', '59', 'Ⅳ', '7', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('240', '59', 'M', '8', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('241', '60', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('242', '60', '稍微有点困难', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('243', '60', '需要有人在旁边看着', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('244', '60', '不能判断', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('245', '61', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('246', '61', '稍微有点困难', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('247', '61', '仅限于具体要求', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('248', '61', '不能传达', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('249', '62', '没有问题', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('250', '62', '有问题', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('251', '62', 'Ⅱ a', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('252', '63', '自理', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('253', '63', '勉强能够自己吃', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('254', '63', '完全依赖辅助', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('255', '64', '自理', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('256', '64', 'Ⅰ', '1', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('257', '64', 'Ⅱ a', '2', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('258', '64', 'Ⅱ b', '3', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('259', '64', 'Ⅲ a', '4', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('260', '64', 'Ⅲ b', '5', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('261', '64', 'Ⅳ', '6', '0', null, null);
INSERT INTO `his_eva_answer` VALUES ('262', '64', 'M', '7', '0', null, null);

-- ----------------------------
-- Table structure for his_eva_attachment
-- ----------------------------
DROP TABLE IF EXISTS `his_eva_attachment`;
CREATE TABLE `his_eva_attachment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `RECORD_ID` int(11) NOT NULL DEFAULT '0' COMMENT '评估记录标识',
  `ATTACHMENT_ID` int(11) NOT NULL DEFAULT '0' COMMENT '附件标识',
  `CREATOR` int(11) DEFAULT NULL COMMENT '创建人',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`Id`),
  KEY `CREATOR` (`CREATOR`),
  KEY `RECORD_ID` (`RECORD_ID`),
  KEY `fk_attachmentId` (`ATTACHMENT_ID`),
  CONSTRAINT `fk_attachmentId` FOREIGN KEY (`ATTACHMENT_ID`) REFERENCES `his_attachment` (`Id`),
  CONSTRAINT `his_eva_attachment_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`) ON DELETE SET NULL,
  CONSTRAINT `his_eva_attachment_ibfk_2` FOREIGN KEY (`RECORD_ID`) REFERENCES `his_eva_record` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='评估附件表';

-- ----------------------------
-- Records of his_eva_attachment
-- ----------------------------

-- ----------------------------
-- Table structure for his_eva_process
-- ----------------------------
DROP TABLE IF EXISTS `his_eva_process`;
CREATE TABLE `his_eva_process` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `RECORD_ID` int(11) NOT NULL COMMENT '外键表：HIS_EVA_RECORD，外键字段：ID',
  `QUESTION_ID` int(11) NOT NULL COMMENT '外键表：HIS_EVA_QUESTION，外键字段：ID',
  `ANSWER_ID` int(11) NOT NULL COMMENT '外键表：HIS_EVA_ANSWER，外键字段：ID',
  `QUESTION_SCORE` int(11) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `RECORD_ID` (`RECORD_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `QUESTION_ID` (`QUESTION_ID`),
  KEY `ANSWER_ID` (`ANSWER_ID`),
  CONSTRAINT `his_eva_process_ibfk_1` FOREIGN KEY (`RECORD_ID`) REFERENCES `his_eva_record` (`ID`),
  CONSTRAINT `his_eva_process_ibfk_4` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_eva_process_ibfk_5` FOREIGN KEY (`QUESTION_ID`) REFERENCES `his_eva_question` (`ID`),
  CONSTRAINT `his_eva_process_ibfk_6` FOREIGN KEY (`ANSWER_ID`) REFERENCES `his_eva_answer` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5420 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_eva_process
-- ----------------------------
INSERT INTO `his_eva_process` VALUES ('4917', '1191', '65', '1', '5', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4918', '1191', '66', '4', '1', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4919', '1191', '67', '8', '2', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4920', '1191', '68', '12', '2', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4921', '1191', '69', '15', '0', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4922', '1191', '70', '17', '0', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4923', '1191', '71', '19', '2', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4924', '1191', '72', '23', '2', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4925', '1191', '73', '27', '1', '1021', '2018-03-13 10:12:41');
INSERT INTO `his_eva_process` VALUES ('4926', '1192', '1', '32', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4927', '1192', '2', '37', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4928', '1192', '3', '43', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4929', '1192', '4', '45', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4930', '1192', '5', '49', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4931', '1192', '6', '53', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4932', '1192', '7', '55', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4933', '1192', '8', '58', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4934', '1192', '9', '61', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4935', '1192', '10', '65', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4936', '1192', '11', '68', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4937', '1192', '12', '72', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4938', '1192', '13', '77', '0', '1021', '2018-03-13 10:14:41');
INSERT INTO `his_eva_process` VALUES ('4939', '1192', '14', '82', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4940', '1192', '15', '85', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4941', '1192', '16', '90', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4942', '1192', '17', '93', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4943', '1192', '18', '96', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4944', '1192', '19', '101', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4945', '1192', '20', '104', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4946', '1192', '21', '108', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4947', '1192', '22', '110', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4948', '1192', '23', '114', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4949', '1192', '24', '116', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4950', '1192', '25', '119', '0', '1021', '2018-03-13 10:15:08');
INSERT INTO `his_eva_process` VALUES ('4951', '1192', '26', '123', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4952', '1192', '27', '127', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4953', '1192', '28', '129', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4954', '1192', '29', '130', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4955', '1192', '30', '133', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4956', '1192', '31', '134', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4957', '1192', '32', '136', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4958', '1192', '33', '139', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4959', '1192', '34', '142', '0', '1021', '2018-03-13 10:15:28');
INSERT INTO `his_eva_process` VALUES ('4960', '1192', '35', '145', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4961', '1192', '36', '148', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4962', '1192', '37', '151', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4963', '1192', '38', '153', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4964', '1192', '39', '157', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4965', '1192', '40', '159', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4966', '1192', '41', '163', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4967', '1192', '42', '166', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4968', '1192', '43', '168', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4969', '1192', '44', '172', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4970', '1192', '45', '174', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4971', '1192', '46', '178', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4972', '1192', '47', '180', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4973', '1192', '48', '184', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4974', '1192', '49', '186', '0', '1021', '2018-03-13 10:15:50');
INSERT INTO `his_eva_process` VALUES ('4975', '1192', '50', '190', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4976', '1192', '51', '193', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4977', '1192', '52', '197', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4978', '1192', '53', '201', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4979', '1192', '54', '206', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4980', '1192', '55', '208', '0', '1021', '2018-03-13 10:16:00');
INSERT INTO `his_eva_process` VALUES ('4981', '1192', '56', '213', '0', '1021', '2018-03-13 10:16:12');
INSERT INTO `his_eva_process` VALUES ('4982', '1192', '56', '217', '0', '1021', '2018-03-13 10:16:12');
INSERT INTO `his_eva_process` VALUES ('4983', '1192', '56', '219', '0', '1021', '2018-03-13 10:16:12');
INSERT INTO `his_eva_process` VALUES ('4984', '1192', '57', '222', '0', '1021', '2018-03-13 10:16:12');
INSERT INTO `his_eva_process` VALUES ('4985', '1192', '58', '228', '0', '1021', '2018-03-13 10:16:18');
INSERT INTO `his_eva_process` VALUES ('4986', '1192', '59', '236', '0', '1021', '2018-03-13 10:16:18');
INSERT INTO `his_eva_process` VALUES ('4987', '1192', '60', '243', '0', '1021', '2018-03-13 10:16:32');
INSERT INTO `his_eva_process` VALUES ('4988', '1192', '61', '246', '0', '1021', '2018-03-13 10:16:32');
INSERT INTO `his_eva_process` VALUES ('4989', '1192', '62', '250', '0', '1021', '2018-03-13 10:16:32');
INSERT INTO `his_eva_process` VALUES ('4990', '1192', '63', '253', '0', '1021', '2018-03-13 10:16:32');
INSERT INTO `his_eva_process` VALUES ('4991', '1192', '64', '258', '0', '1021', '2018-03-13 10:16:32');
INSERT INTO `his_eva_process` VALUES ('4992', '1194', '1', '32', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4993', '1194', '2', '37', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4994', '1194', '3', '42', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4995', '1194', '4', '45', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4996', '1194', '5', '48', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4997', '1194', '6', '52', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4998', '1194', '7', '55', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('4999', '1194', '8', '58', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5000', '1194', '9', '61', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5001', '1194', '10', '64', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5002', '1194', '11', '68', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5003', '1194', '12', '71', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5004', '1194', '13', '76', '0', '1021', '2018-03-13 14:56:17');
INSERT INTO `his_eva_process` VALUES ('5005', '1194', '14', '81', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5006', '1194', '15', '85', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5007', '1194', '16', '89', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5008', '1194', '17', '92', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5009', '1194', '18', '96', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5010', '1194', '19', '100', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5011', '1194', '20', '104', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5012', '1194', '21', '107', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5013', '1194', '22', '110', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5014', '1194', '23', '113', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5015', '1194', '24', '116', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5016', '1194', '25', '119', '0', '1021', '2018-03-13 14:56:27');
INSERT INTO `his_eva_process` VALUES ('5017', '1194', '26', '122', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5018', '1194', '27', '126', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5019', '1194', '28', '128', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5020', '1194', '29', '130', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5021', '1194', '30', '132', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5022', '1194', '31', '134', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5023', '1194', '32', '136', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5024', '1194', '33', '138', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5025', '1194', '34', '141', '0', '1021', '2018-03-13 14:56:31');
INSERT INTO `his_eva_process` VALUES ('5026', '1194', '35', '144', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5027', '1194', '36', '147', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5028', '1194', '37', '150', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5029', '1194', '38', '153', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5030', '1194', '39', '156', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5031', '1194', '40', '159', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5032', '1194', '41', '162', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5033', '1194', '42', '165', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5034', '1194', '43', '168', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5035', '1194', '44', '171', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5036', '1194', '45', '174', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5037', '1194', '46', '177', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5038', '1194', '47', '180', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5039', '1194', '48', '183', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5040', '1194', '49', '186', '0', '1021', '2018-03-13 14:56:42');
INSERT INTO `his_eva_process` VALUES ('5041', '1194', '50', '189', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5042', '1194', '51', '193', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5043', '1194', '52', '196', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5044', '1194', '53', '200', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5045', '1194', '54', '204', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5046', '1194', '55', '208', '0', '1021', '2018-03-13 14:56:47');
INSERT INTO `his_eva_process` VALUES ('5047', '1194', '56', '212', '0', '1021', '2018-03-13 14:57:10');
INSERT INTO `his_eva_process` VALUES ('5048', '1194', '57', '221', '0', '1021', '2018-03-13 14:57:10');
INSERT INTO `his_eva_process` VALUES ('5049', '1194', '58', '224', '0', '1021', '2018-03-13 14:57:14');
INSERT INTO `his_eva_process` VALUES ('5050', '1194', '59', '233', '0', '1021', '2018-03-13 14:57:14');
INSERT INTO `his_eva_process` VALUES ('5051', '1194', '60', '241', '0', '1021', '2018-03-13 14:57:19');
INSERT INTO `his_eva_process` VALUES ('5052', '1194', '61', '245', '0', '1021', '2018-03-13 14:57:19');
INSERT INTO `his_eva_process` VALUES ('5053', '1194', '62', '249', '0', '1021', '2018-03-13 14:57:19');
INSERT INTO `his_eva_process` VALUES ('5054', '1194', '63', '252', '0', '1021', '2018-03-13 14:57:19');
INSERT INTO `his_eva_process` VALUES ('5055', '1194', '64', '255', '0', '1021', '2018-03-13 14:57:19');
INSERT INTO `his_eva_process` VALUES ('5056', '1196', '65', '3', '10', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5057', '1196', '66', '5', '2', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5058', '1196', '67', '9', '1', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5059', '1196', '68', '13', '3', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5060', '1196', '69', '14', '5', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5061', '1196', '70', '17', '0', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5062', '1196', '71', '18', '1', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5063', '1196', '72', '24', '3', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5064', '1196', '73', '28', '2', '1021', '2018-03-13 15:23:14');
INSERT INTO `his_eva_process` VALUES ('5065', '1197', '1', '36', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5066', '1197', '2', '41', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5067', '1197', '3', '44', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5068', '1197', '4', '47', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5069', '1197', '5', '50', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5070', '1197', '6', '54', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5071', '1197', '7', '57', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5072', '1197', '8', '60', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5073', '1197', '9', '63', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5074', '1197', '10', '67', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5075', '1197', '11', '70', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5076', '1197', '12', '74', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5077', '1197', '13', '77', '0', '1021', '2018-03-13 15:24:09');
INSERT INTO `his_eva_process` VALUES ('5078', '1197', '14', '84', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5079', '1197', '15', '88', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5080', '1197', '16', '91', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5081', '1197', '17', '95', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5082', '1197', '18', '99', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5083', '1197', '19', '103', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5084', '1197', '20', '104', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5085', '1197', '21', '109', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5086', '1197', '22', '112', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5087', '1197', '23', '115', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5088', '1197', '24', '118', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5089', '1197', '25', '119', '0', '1021', '2018-03-13 15:24:25');
INSERT INTO `his_eva_process` VALUES ('5090', '1197', '26', '123', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5091', '1197', '27', '127', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5092', '1197', '28', '129', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5093', '1197', '29', '130', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5094', '1197', '30', '132', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5095', '1197', '31', '135', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5096', '1197', '32', '137', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5097', '1197', '33', '138', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5098', '1197', '34', '141', '0', '1021', '2018-03-13 15:24:35');
INSERT INTO `his_eva_process` VALUES ('5099', '1197', '35', '144', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5100', '1197', '36', '147', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5101', '1197', '37', '150', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5102', '1197', '38', '153', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5103', '1197', '39', '156', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5104', '1197', '40', '159', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5105', '1197', '41', '162', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5106', '1197', '42', '165', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5107', '1197', '43', '168', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5108', '1197', '44', '171', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5109', '1197', '45', '174', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5110', '1197', '46', '177', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5111', '1197', '47', '180', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5112', '1197', '48', '183', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5113', '1197', '49', '186', '0', '1021', '2018-03-13 15:24:40');
INSERT INTO `his_eva_process` VALUES ('5114', '1197', '50', '189', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5115', '1197', '51', '193', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5116', '1197', '52', '196', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5117', '1197', '53', '200', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5118', '1197', '54', '204', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5119', '1197', '55', '208', '0', '1021', '2018-03-13 15:24:43');
INSERT INTO `his_eva_process` VALUES ('5120', '1197', '56', '217', '0', '1021', '2018-03-13 15:24:55');
INSERT INTO `his_eva_process` VALUES ('5121', '1197', '57', '221', '0', '1021', '2018-03-13 15:24:55');
INSERT INTO `his_eva_process` VALUES ('5122', '1197', '57', '222', '0', '1021', '2018-03-13 15:24:55');
INSERT INTO `his_eva_process` VALUES ('5123', '1197', '57', '223', '0', '1021', '2018-03-13 15:24:55');
INSERT INTO `his_eva_process` VALUES ('5124', '1197', '58', '232', '0', '1021', '2018-03-13 15:25:01');
INSERT INTO `his_eva_process` VALUES ('5125', '1197', '59', '240', '0', '1021', '2018-03-13 15:25:01');
INSERT INTO `his_eva_process` VALUES ('5126', '1197', '60', '243', '0', '1021', '2018-03-13 15:25:14');
INSERT INTO `his_eva_process` VALUES ('5127', '1197', '61', '247', '0', '1021', '2018-03-13 15:25:14');
INSERT INTO `his_eva_process` VALUES ('5128', '1197', '62', '251', '0', '1021', '2018-03-13 15:25:14');
INSERT INTO `his_eva_process` VALUES ('5129', '1197', '63', '253', '0', '1021', '2018-03-13 15:25:14');
INSERT INTO `his_eva_process` VALUES ('5130', '1197', '64', '262', '0', '1021', '2018-03-13 15:25:14');
INSERT INTO `his_eva_process` VALUES ('5131', '1199', '65', '1', '5', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5132', '1199', '66', '4', '1', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5133', '1199', '67', '8', '2', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5134', '1199', '68', '11', '1', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5135', '1199', '69', '14', '5', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5136', '1199', '70', '16', '5', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5137', '1199', '71', '18', '1', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5138', '1199', '72', '22', '1', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5139', '1199', '73', '26', '0', '1021', '2018-03-13 15:46:09');
INSERT INTO `his_eva_process` VALUES ('5140', '1200', '3', '42', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5141', '1200', '4', '45', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5142', '1200', '5', '48', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5143', '1200', '6', '52', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5144', '1200', '7', '55', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5145', '1200', '8', '58', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5146', '1200', '9', '61', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5147', '1200', '10', '64', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5148', '1200', '11', '68', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5149', '1200', '12', '71', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5150', '1200', '13', '76', '0', '1021', '2018-03-13 15:46:41');
INSERT INTO `his_eva_process` VALUES ('5151', '1200', '14', '81', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5152', '1200', '15', '85', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5153', '1200', '16', '89', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5154', '1200', '17', '92', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5155', '1200', '18', '96', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5156', '1200', '19', '100', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5157', '1200', '20', '104', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5158', '1200', '21', '107', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5159', '1200', '22', '110', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5160', '1200', '23', '113', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5161', '1200', '24', '116', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5162', '1200', '25', '119', '0', '1021', '2018-03-13 15:46:47');
INSERT INTO `his_eva_process` VALUES ('5163', '1200', '26', '122', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5164', '1200', '27', '126', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5165', '1200', '28', '128', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5166', '1200', '29', '130', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5167', '1200', '30', '132', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5168', '1200', '31', '134', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5169', '1200', '32', '136', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5170', '1200', '33', '138', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5171', '1200', '34', '141', '0', '1021', '2018-03-13 15:46:50');
INSERT INTO `his_eva_process` VALUES ('5172', '1200', '35', '144', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5173', '1200', '36', '147', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5174', '1200', '37', '150', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5175', '1200', '38', '153', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5176', '1200', '39', '156', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5177', '1200', '40', '159', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5178', '1200', '41', '162', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5179', '1200', '42', '165', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5180', '1200', '43', '168', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5181', '1200', '44', '171', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5182', '1200', '45', '174', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5183', '1200', '46', '177', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5184', '1200', '47', '180', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5185', '1200', '48', '183', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5186', '1200', '49', '186', '0', '1021', '2018-03-13 15:46:52');
INSERT INTO `his_eva_process` VALUES ('5187', '1200', '50', '189', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5188', '1200', '51', '193', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5189', '1200', '52', '196', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5190', '1200', '53', '200', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5191', '1200', '54', '204', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5192', '1200', '55', '208', '0', '1021', '2018-03-13 15:46:55');
INSERT INTO `his_eva_process` VALUES ('5193', '1200', '58', '224', '0', '1021', '2018-03-13 15:46:59');
INSERT INTO `his_eva_process` VALUES ('5194', '1200', '59', '233', '0', '1021', '2018-03-13 15:46:59');
INSERT INTO `his_eva_process` VALUES ('5195', '1200', '60', '241', '0', '1021', '2018-03-13 15:47:02');
INSERT INTO `his_eva_process` VALUES ('5196', '1200', '61', '245', '0', '1021', '2018-03-13 15:47:02');
INSERT INTO `his_eva_process` VALUES ('5197', '1200', '62', '249', '0', '1021', '2018-03-13 15:47:02');
INSERT INTO `his_eva_process` VALUES ('5198', '1200', '63', '252', '0', '1021', '2018-03-13 15:47:02');
INSERT INTO `his_eva_process` VALUES ('5199', '1200', '64', '255', '0', '1021', '2018-03-13 15:47:02');
INSERT INTO `his_eva_process` VALUES ('5200', '1202', '65', '1', '5', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5201', '1202', '66', '4', '1', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5202', '1202', '67', '8', '2', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5203', '1202', '68', '11', '1', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5204', '1202', '69', '14', '5', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5205', '1202', '70', '16', '5', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5206', '1202', '71', '18', '1', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5207', '1202', '72', '22', '1', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5208', '1202', '73', '26', '0', '1021', '2018-03-13 16:18:37');
INSERT INTO `his_eva_process` VALUES ('5209', '1203', '3', '42', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5210', '1203', '4', '45', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5211', '1203', '5', '48', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5212', '1203', '6', '52', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5213', '1203', '7', '55', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5214', '1203', '8', '58', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5215', '1203', '9', '61', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5216', '1203', '10', '64', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5217', '1203', '11', '68', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5218', '1203', '12', '71', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5219', '1203', '13', '76', '0', '1021', '2018-03-13 16:19:12');
INSERT INTO `his_eva_process` VALUES ('5220', '1203', '14', '81', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5221', '1203', '15', '85', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5222', '1203', '16', '89', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5223', '1203', '17', '92', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5224', '1203', '18', '96', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5225', '1203', '19', '100', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5226', '1203', '20', '104', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5227', '1203', '21', '107', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5228', '1203', '22', '110', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5229', '1203', '23', '113', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5230', '1203', '24', '116', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5231', '1203', '25', '119', '0', '1021', '2018-03-13 16:19:17');
INSERT INTO `his_eva_process` VALUES ('5232', '1203', '26', '122', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5233', '1203', '27', '126', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5234', '1203', '28', '128', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5235', '1203', '29', '130', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5236', '1203', '30', '132', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5237', '1203', '31', '134', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5238', '1203', '32', '136', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5239', '1203', '33', '138', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5240', '1203', '34', '141', '0', '1021', '2018-03-13 16:19:20');
INSERT INTO `his_eva_process` VALUES ('5241', '1203', '35', '144', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5242', '1203', '36', '147', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5243', '1203', '37', '150', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5244', '1203', '38', '153', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5245', '1203', '39', '156', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5246', '1203', '40', '159', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5247', '1203', '41', '162', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5248', '1203', '42', '165', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5249', '1203', '43', '168', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5250', '1203', '44', '171', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5251', '1203', '45', '174', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5252', '1203', '46', '177', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5253', '1203', '47', '180', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5254', '1203', '48', '183', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5255', '1203', '49', '186', '0', '1021', '2018-03-13 16:19:22');
INSERT INTO `his_eva_process` VALUES ('5256', '1203', '50', '189', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5257', '1203', '51', '193', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5258', '1203', '52', '196', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5259', '1203', '53', '200', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5260', '1203', '54', '204', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5261', '1203', '55', '208', '0', '1021', '2018-03-13 16:19:25');
INSERT INTO `his_eva_process` VALUES ('5262', '1203', '58', '224', '0', '1021', '2018-03-13 16:19:29');
INSERT INTO `his_eva_process` VALUES ('5263', '1203', '59', '233', '0', '1021', '2018-03-13 16:19:29');
INSERT INTO `his_eva_process` VALUES ('5264', '1203', '60', '241', '0', '1021', '2018-03-13 16:19:32');
INSERT INTO `his_eva_process` VALUES ('5265', '1203', '61', '245', '0', '1021', '2018-03-13 16:19:32');
INSERT INTO `his_eva_process` VALUES ('5266', '1203', '62', '249', '0', '1021', '2018-03-13 16:19:32');
INSERT INTO `his_eva_process` VALUES ('5267', '1203', '63', '252', '0', '1021', '2018-03-13 16:19:32');
INSERT INTO `his_eva_process` VALUES ('5268', '1203', '64', '255', '0', '1021', '2018-03-13 16:19:32');
INSERT INTO `his_eva_process` VALUES ('5269', '1205', '65', '1', '5', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5270', '1205', '66', '4', '1', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5271', '1205', '67', '8', '2', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5272', '1205', '68', '11', '1', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5273', '1205', '69', '14', '5', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5274', '1205', '70', '16', '5', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5275', '1205', '71', '18', '1', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5276', '1205', '72', '22', '1', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5277', '1205', '73', '26', '0', '1021', '2018-03-13 16:57:26');
INSERT INTO `his_eva_process` VALUES ('5278', '1206', '3', '42', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5279', '1206', '4', '45', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5280', '1206', '5', '48', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5281', '1206', '6', '52', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5282', '1206', '7', '55', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5283', '1206', '8', '58', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5284', '1206', '9', '61', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5285', '1206', '10', '64', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5286', '1206', '11', '68', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5287', '1206', '12', '71', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5288', '1206', '13', '76', '0', '1021', '2018-03-13 16:57:42');
INSERT INTO `his_eva_process` VALUES ('5289', '1206', '14', '81', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5290', '1206', '15', '85', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5291', '1206', '16', '89', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5292', '1206', '17', '92', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5293', '1206', '18', '96', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5294', '1206', '19', '100', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5295', '1206', '20', '104', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5296', '1206', '21', '107', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5297', '1206', '22', '110', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5298', '1206', '23', '113', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5299', '1206', '24', '116', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5300', '1206', '25', '119', '0', '1021', '2018-03-13 16:57:46');
INSERT INTO `his_eva_process` VALUES ('5301', '1206', '26', '122', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5302', '1206', '27', '126', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5303', '1206', '28', '128', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5304', '1206', '29', '130', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5305', '1206', '30', '132', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5306', '1206', '31', '134', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5307', '1206', '32', '136', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5308', '1206', '33', '138', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5309', '1206', '34', '141', '0', '1021', '2018-03-13 16:57:48');
INSERT INTO `his_eva_process` VALUES ('5310', '1206', '35', '144', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5311', '1206', '36', '147', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5312', '1206', '37', '150', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5313', '1206', '38', '153', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5314', '1206', '39', '156', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5315', '1206', '40', '159', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5316', '1206', '41', '162', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5317', '1206', '42', '165', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5318', '1206', '43', '168', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5319', '1206', '44', '171', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5320', '1206', '45', '174', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5321', '1206', '46', '177', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5322', '1206', '47', '180', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5323', '1206', '48', '183', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5324', '1206', '49', '186', '0', '1021', '2018-03-13 16:57:51');
INSERT INTO `his_eva_process` VALUES ('5325', '1206', '50', '189', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5326', '1206', '51', '193', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5327', '1206', '52', '196', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5328', '1206', '53', '200', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5329', '1206', '54', '204', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5330', '1206', '55', '208', '0', '1021', '2018-03-13 16:57:53');
INSERT INTO `his_eva_process` VALUES ('5331', '1206', '58', '224', '0', '1021', '2018-03-13 16:57:57');
INSERT INTO `his_eva_process` VALUES ('5332', '1206', '59', '233', '0', '1021', '2018-03-13 16:57:57');
INSERT INTO `his_eva_process` VALUES ('5333', '1206', '60', '241', '0', '1021', '2018-03-13 16:58:00');
INSERT INTO `his_eva_process` VALUES ('5334', '1206', '61', '245', '0', '1021', '2018-03-13 16:58:00');
INSERT INTO `his_eva_process` VALUES ('5335', '1206', '62', '249', '0', '1021', '2018-03-13 16:58:00');
INSERT INTO `his_eva_process` VALUES ('5336', '1206', '63', '252', '0', '1021', '2018-03-13 16:58:00');
INSERT INTO `his_eva_process` VALUES ('5337', '1206', '64', '255', '0', '1021', '2018-03-13 16:58:00');
INSERT INTO `his_eva_process` VALUES ('5338', '1208', '65', '1', '5', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5339', '1208', '66', '4', '1', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5340', '1208', '67', '8', '2', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5341', '1208', '68', '11', '1', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5342', '1208', '69', '14', '5', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5343', '1208', '70', '16', '5', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5344', '1208', '71', '18', '1', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5345', '1208', '72', '22', '1', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5346', '1208', '73', '26', '0', '1021', '2018-03-13 16:59:00');
INSERT INTO `his_eva_process` VALUES ('5347', '1209', '3', '42', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5348', '1209', '4', '45', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5349', '1209', '5', '48', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5350', '1209', '6', '52', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5351', '1209', '7', '55', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5352', '1209', '8', '58', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5353', '1209', '9', '61', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5354', '1209', '10', '64', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5355', '1209', '11', '68', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5356', '1209', '12', '71', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5357', '1209', '13', '76', '0', '1021', '2018-03-13 16:59:16');
INSERT INTO `his_eva_process` VALUES ('5358', '1209', '14', '81', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5359', '1209', '15', '85', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5360', '1209', '16', '89', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5361', '1209', '17', '92', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5362', '1209', '18', '96', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5363', '1209', '19', '100', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5364', '1209', '20', '104', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5365', '1209', '21', '107', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5366', '1209', '22', '110', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5367', '1209', '23', '113', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5368', '1209', '24', '116', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5369', '1209', '25', '119', '0', '1021', '2018-03-13 16:59:22');
INSERT INTO `his_eva_process` VALUES ('5370', '1209', '26', '122', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5371', '1209', '27', '126', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5372', '1209', '28', '128', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5373', '1209', '29', '130', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5374', '1209', '30', '132', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5375', '1209', '31', '134', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5376', '1209', '32', '136', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5377', '1209', '33', '138', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5378', '1209', '34', '141', '0', '1021', '2018-03-13 16:59:25');
INSERT INTO `his_eva_process` VALUES ('5379', '1209', '35', '144', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5380', '1209', '36', '147', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5381', '1209', '37', '150', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5382', '1209', '38', '153', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5383', '1209', '39', '156', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5384', '1209', '40', '159', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5385', '1209', '41', '162', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5386', '1209', '42', '165', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5387', '1209', '43', '168', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5388', '1209', '44', '171', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5389', '1209', '45', '174', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5390', '1209', '46', '177', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5391', '1209', '47', '180', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5392', '1209', '48', '183', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5393', '1209', '49', '186', '0', '1021', '2018-03-13 16:59:28');
INSERT INTO `his_eva_process` VALUES ('5394', '1209', '50', '189', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5395', '1209', '51', '193', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5396', '1209', '52', '196', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5397', '1209', '53', '200', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5398', '1209', '54', '204', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5399', '1209', '55', '208', '0', '1021', '2018-03-13 16:59:30');
INSERT INTO `his_eva_process` VALUES ('5400', '1209', '58', '224', '0', '1021', '2018-03-13 16:59:34');
INSERT INTO `his_eva_process` VALUES ('5401', '1209', '59', '233', '0', '1021', '2018-03-13 16:59:34');
INSERT INTO `his_eva_process` VALUES ('5402', '1209', '60', '241', '0', '1021', '2018-03-13 16:59:39');
INSERT INTO `his_eva_process` VALUES ('5403', '1209', '61', '245', '0', '1021', '2018-03-13 16:59:39');
INSERT INTO `his_eva_process` VALUES ('5404', '1209', '62', '249', '0', '1021', '2018-03-13 16:59:39');
INSERT INTO `his_eva_process` VALUES ('5405', '1209', '63', '252', '0', '1021', '2018-03-13 16:59:39');
INSERT INTO `his_eva_process` VALUES ('5406', '1209', '64', '255', '0', '1021', '2018-03-13 16:59:39');
INSERT INTO `his_eva_process` VALUES ('5407', '1210', '1', '32', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5408', '1210', '2', '41', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5409', '1210', '3', '42', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5410', '1210', '4', '45', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5411', '1210', '5', '48', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5412', '1210', '6', '52', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5413', '1210', '7', '55', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5414', '1210', '8', '58', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5415', '1210', '9', '61', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5416', '1210', '10', '64', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5417', '1210', '11', '69', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5418', '1210', '12', '73', '0', '1021', '2018-03-15 10:57:29');
INSERT INTO `his_eva_process` VALUES ('5419', '1210', '13', '77', '0', '1021', '2018-03-15 10:57:29');

-- ----------------------------
-- Table structure for his_eva_question
-- ----------------------------
DROP TABLE IF EXISTS `his_eva_question`;
CREATE TABLE `his_eva_question` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `EVA_TYPE` tinyint(4) DEFAULT NULL COMMENT '1-综合健康评估，2-护理等级评估，3-简易智力评估，4-居家环境评估',
  `RATE_CATEGORY_ID` tinyint(4) DEFAULT NULL COMMENT '评估类型为2时设置',
  `TITLE` varchar(100) DEFAULT NULL,
  `SEQ_NO` tinyint(4) DEFAULT NULL COMMENT '问题序号，默认按增加顺序递增',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '问题状态，正常-1，停用-0，默认1',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `his_eva_question_ibfk_2` (`RATE_CATEGORY_ID`),
  KEY `ID` (`ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_eva_question_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_eva_question
-- ----------------------------
INSERT INTO `his_eva_question` VALUES ('1', '2', '1', '有无瘫痪', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('2', '2', '1', '有无拘挛', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('3', '2', '1', '翻身', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('4', '2', '1', '起床起身', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('5', '2', '1', '保持坐着', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('6', '2', '1', '两只脚站立', '6', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('7', '2', '1', '歩行', '7', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('8', '2', '1', '站立起来', '8', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('9', '2', '1', '一只脚站立', '9', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('10', '2', '1', '洗澡', '10', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('11', '2', '1', '剪指甲', '11', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('12', '2', '1', '視力', '12', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('13', '2', '1', '听力', '13', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('14', '2', '2', '移乘', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('15', '2', '2', '移动', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('16', '2', '2', '吞咽', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('17', '2', '2', '进食', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('18', '2', '2', '排尿', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('19', '2', '2', '排便', '6', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('20', '2', '2', '口腔清洁', '7', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('21', '2', '2', '洗脸', '8', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('22', '2', '2', '理发', '9', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('23', '2', '2', '穿脱上衣', '10', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('24', '2', '2', '穿脱裤子', '11', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('25', '2', '2', '外出频率', '12', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('26', '2', '3', '想法的传达', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('27', '2', '3', '对于每日例行活动的理解 ', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('28', '2', '3', '说出出生年月日', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('29', '2', '3', '短期记忆', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('30', '2', '3', '说出自己的名字', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('31', '2', '3', '了解当下是什么季节', '6', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('32', '2', '3', '了解自己所在场所', '7', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('33', '2', '3', '徘徊', '8', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('34', '2', '3', '外出不返', '9', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('35', '2', '4', '被害妄想', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('36', '2', '4', '编造没有根据的话，自己深信不疑', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('37', '2', '4', '情绪不稳定', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('38', '2', '4', '昼夜颠倒', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('39', '2', '4', '重复同样的话', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('40', '2', '4', '大声喊叫', '6', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('41', '2', '4', '抵触被护理', '7', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('42', '2', '4', '会说起“我要回家”之类的话，情绪不太冷静', '8', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('43', '2', '4', '一个人出走', '9', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('44', '2', '4', '收集癖', '10', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('45', '2', '4', '破坏物品或衣物', '11', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('46', '2', '4', '严重的健忘', '12', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('47', '2', '4', '自言自语，自说自话', '13', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('48', '2', '4', '自己随意行动', '14', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('49', '2', '4', '说话没有重点', '15', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('50', '2', '5', '服药', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('51', '2', '5', '金钱管理', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('52', '2', '5', '对日常事务做决定', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('53', '2', '5', '对人群（人多）有不适感', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('54', '2', '5', '买东西', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('55', '2', '5', '简单的烹饪', '6', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('56', '2', '6', '处置内容', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('57', '2', '6', '特别处置', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('58', '2', '7', '身体有残疾的老人的自理度（卧床不起的程度）', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('59', '2', '7', '痴呆老人的自理度', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('60', '2', '8', '具有对日常事务做决定的认知能力', '1', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('61', '2', '8', '自己想法的传达能力', '2', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('62', '2', '8', '短期记忆', '3', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('63', '2', '8', '自己吃东西', '4', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('64', '2', '8', '痴呆症老人的日常生活自理程度', '5', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('65', '3', null, '您今年高寿？', '65', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('66', '3', null, '今天是何年何月何日？星期几？（年、月、日，星期正解各得一分）', '66', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('67', '3', null, '我们现在在哪里？（主动回答得2分，5秒之后提出选项在家吗？在医院吗？在养老院吗？选择正确得一分。）', '67', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('68', '3', null, '请您重复您所听到的三个词语，：⒜樱花⒝猫⒞电车 ：⒜梅花⒝狗⒞汽车', '68', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('69', '3', null, '请用100依次减七。（100-7=？所得结果再减7?如果最初的结果不正确，请停止。）', '69', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('70', '3', null, '请您倒着复述您所听到的数字。（6-8-2、3-5-2-9，如果三位数为一组的复述失败，请停止。）', '70', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('71', '3', null, '请把4题背诵的词语再复述一遍。（主动回答各得2分，如果回答不出的场合，请给予以下提示：⒜植物⒝动物⒞交通工具，回答正确各得一分。）', '71', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('72', '3', null, '请看展示的五件物品，收起来之后，请说出五件物品的名称。（表、钥匙、烟、笔、硬币等等，要求一定是相互没有关系的物品。）', '72', '1', null, null);
INSERT INTO `his_eva_question` VALUES ('73', '3', null, '尽可能多的说出您所知道的蔬菜的名字。（回答出的蔬菜名字记入右栏里，途中停顿约十秒的场合，请停止。）0～5=0分，6=1分，7=2分，8=3分，9=4分，10=5分', '73', '1', null, null);

-- ----------------------------
-- Table structure for his_eva_record
-- ----------------------------
DROP TABLE IF EXISTS `his_eva_record`;
CREATE TABLE `his_eva_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `EVA_ID` int(11) NOT NULL COMMENT '外键表：HIS_MEMBER_EVALUATE，外键字段：ID',
  `EVA_TYPE` tinyint(4) NOT NULL COMMENT '1-综合健康评估，2-护理等级评估，3-简易智力评估，4-居家环境评估',
  `SCORE_SUM` int(11) DEFAULT '0',
  `EVA_RESULT` tinyint(4) DEFAULT NULL COMMENT '通过-1，不通过-0，护理等级（一级-2，二级-3，三级-4，四级-5），待定-6',
  `EVA_REMARK` varchar(500) DEFAULT NULL,
  `EVALUATOR` varchar(10) DEFAULT NULL,
  `EVA_TIME` datetime DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT '0207-01-01 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `his_eva_record_ibfk_1` (`EVA_ID`),
  CONSTRAINT `his_eva_record_ibfk_1` FOREIGN KEY (`EVA_ID`) REFERENCES `his_member_evaluate` (`ID`),
  CONSTRAINT `his_eva_record_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1211 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_eva_record
-- ----------------------------
INSERT INTO `his_eva_record` VALUES ('1190', '806', '1', null, '1', '语言流利，行动自如。', '陈磊', '2018-04-04 10:07:22', '1021', '2018-03-13 10:11:23', null);
INSERT INTO `his_eva_record` VALUES ('1191', '806', '3', '15', '1', '听力和记忆力较差。', '陈磊', '2017-04-04 10:23:00', '1021', '2018-03-13 10:12:42', null);
INSERT INTO `his_eva_record` VALUES ('1192', '806', '2', '75', '18', '身体机能老化，需要特殊照顾。', '陈磊', '2017-04-13 12:33:00', '1021', '2018-03-13 10:14:42', null);
INSERT INTO `his_eva_record` VALUES ('1193', '808', '1', null, '1', '健康状态良好', '陈磊', '2018-01-03 14:55:25', '1021', '2018-03-13 14:55:52', null);
INSERT INTO `his_eva_record` VALUES ('1194', '808', '2', '31', '17', '老人状态良好', '陈磊', '2018-01-03 00:00:00', '1021', '2018-03-13 14:56:18', null);
INSERT INTO `his_eva_record` VALUES ('1195', '809', '1', null, '1', '生活不能自理，需要照顾', '陈磊', '2018-03-05 15:22:33', '1021', '2018-03-13 15:22:55', null);
INSERT INTO `his_eva_record` VALUES ('1196', '809', '3', '27', '1', '生活不能自理，需要照顾', '陈磊', '2018-03-05 00:00:00', '1021', '2018-03-13 15:23:14', null);
INSERT INTO `his_eva_record` VALUES ('1197', '809', '2', '120', '18', '生活需要照顾', '陈磊', '2018-03-05 00:00:00', '1021', '2018-03-13 15:24:10', null);
INSERT INTO `his_eva_record` VALUES ('1198', '810', '1', null, '1', '身体健康，能够自理', '陈磊', '2018-03-11 15:45:34', '1021', '2018-03-13 15:46:03', null);
INSERT INTO `his_eva_record` VALUES ('1199', '810', '3', '21', '1', '身体健康，能够自理', '陈磊', '2018-03-11 00:00:00', '1021', '2018-03-13 15:46:10', null);
INSERT INTO `his_eva_record` VALUES ('1200', '810', '2', '23', '16', '身体健康，能够自理', '陈磊', '2018-03-11 00:00:00', '1021', '2018-03-13 15:46:42', null);
INSERT INTO `his_eva_record` VALUES ('1201', '811', '1', null, '1', '身体健康', '陈磊', '2017-03-05 16:18:13', '1021', '2018-03-13 16:18:34', null);
INSERT INTO `his_eva_record` VALUES ('1202', '811', '3', '21', '1', '身体健康，神志清醒', '陈磊', '2017-03-05 00:00:00', '1021', '2018-03-13 16:18:38', null);
INSERT INTO `his_eva_record` VALUES ('1203', '811', '2', '23', '16', '身体健康', '陈磊', '2017-03-05 00:00:00', '1021', '2018-03-13 16:19:13', null);
INSERT INTO `his_eva_record` VALUES ('1204', '812', '1', null, '1', '身体健康，精神矍铄', '陈磊', '2018-03-03 16:56:27', '1021', '2018-03-13 16:57:14', null);
INSERT INTO `his_eva_record` VALUES ('1205', '812', '3', '21', '1', '身体健康，精神矍铄', '陈磊', '2018-03-03 00:00:00', '1021', '2018-03-13 16:57:27', null);
INSERT INTO `his_eva_record` VALUES ('1206', '812', '2', '23', '16', '身体健康，精神矍铄', '陈磊', '2018-03-04 00:00:00', '1021', '2018-03-13 16:57:42', null);
INSERT INTO `his_eva_record` VALUES ('1207', '813', '1', null, '1', '身体健康，精神矍铄', '陈磊', '2018-03-03 16:58:42', '1021', '2018-03-13 16:58:57', null);
INSERT INTO `his_eva_record` VALUES ('1208', '813', '3', '21', '1', '身体健康，精神矍铄', '陈磊', '2018-01-03 00:00:00', '1021', '2018-03-13 16:59:01', null);
INSERT INTO `his_eva_record` VALUES ('1209', '813', '2', '23', '16', '身体健康，精神矍铄', '陈磊', '2018-03-03 00:00:00', '1021', '2018-03-13 16:59:17', null);
INSERT INTO `his_eva_record` VALUES ('1210', '815', '2', '0', null, null, null, null, '1021', '2018-03-15 10:57:29', null);

-- ----------------------------
-- Table structure for his_incidental
-- ----------------------------
DROP TABLE IF EXISTS `his_incidental`;
CREATE TABLE `his_incidental` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `TITLE` varchar(30) DEFAULT NULL,
  `CHARGE` decimal(6,1) DEFAULT NULL,
  `SERVICE_STAFF` varchar(50) DEFAULT NULL,
  `REMARK` varchar(200) DEFAULT NULL,
  `SERVICE_DATE` date DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime NOT NULL DEFAULT '2017-01-01 00:00:00',
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_MEMBER_INCIDENTAL` (`MEMBER_ID`),
  KEY `FK_USER_INCIDENTAL` (`CREATOR`),
  CONSTRAINT `FK_MEMBER_INCIDENTAL` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `FK_USER_INCIDENTAL` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_incidental
-- ----------------------------
INSERT INTO `his_incidental` VALUES ('80', '432', '打扫', '20.0', '元天睿', '', '2018-03-13', '1022', '2018-03-13 17:52:45', '2018-03-13 17:52:45');

-- ----------------------------
-- Table structure for his_inoutstock
-- ----------------------------
DROP TABLE IF EXISTS `his_inoutstock`;
CREATE TABLE `his_inoutstock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STOCK_ID` int(11) DEFAULT NULL,
  `INOUTSTOCK_NO` varchar(10) DEFAULT NULL COMMENT 'YYMMDD+ 4位顺序号',
  `INOUTSTOCK_COUNT` int(11) DEFAULT NULL COMMENT '统计值',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  `AUDITOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `AUDIT_TIME` datetime DEFAULT NULL,
  `AUDIT_OPINION` varchar(200) DEFAULT NULL,
  `INOUT_TYPE` tinyint(4) DEFAULT NULL COMMENT '入库还是出库标识',
  PRIMARY KEY (`ID`),
  KEY `FK_his_inoutstock` (`CREATOR`),
  KEY `FK_his_inoutstock_auditor` (`AUDITOR`),
  KEY `STOCK_ID` (`STOCK_ID`),
  CONSTRAINT `FK_his_inoutstock` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `FK_his_inoutstock_auditor` FOREIGN KEY (`AUDITOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_inoutstock_ibfk_1` FOREIGN KEY (`STOCK_ID`) REFERENCES `his_stockhouse` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_inoutstock
-- ----------------------------
INSERT INTO `his_inoutstock` VALUES ('126', '44', '1803130000', '7', '1022', '2018-03-13 15:49:28', null, null, null, null, '0');
INSERT INTO `his_inoutstock` VALUES ('127', '44', '1803130126', '4', '1022', '2018-03-13 15:58:33', null, null, null, null, '1');

-- ----------------------------
-- Table structure for his_inoutstock_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_inoutstock_detail`;
CREATE TABLE `his_inoutstock_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `INOUTSTOCK_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_INOUTSTOCK，外键字段：ID',
  `MATERIAL_TYPE` int(11) DEFAULT NULL COMMENT '外键表：DIC_MATERIAL_CATEGORY，外键字段：ID',
  `NAME` varchar(50) DEFAULT NULL,
  `PRICE` decimal(6,1) DEFAULT NULL,
  `SPECIFICATION` varchar(200) DEFAULT NULL,
  `QUANTITY` int(11) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_his_inoutstock_detail` (`CREATOR`),
  KEY `FK_his_inoutstock_detail_inoutstockId` (`INOUTSTOCK_ID`),
  KEY `MATERIAL_TYPE` (`MATERIAL_TYPE`),
  CONSTRAINT `FK_his_inoutstock_detail` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `FK_his_inoutstock_detail_inoutstockId` FOREIGN KEY (`INOUTSTOCK_ID`) REFERENCES `his_inoutstock` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `his_inoutstock_detail_ibfk_1` FOREIGN KEY (`MATERIAL_TYPE`) REFERENCES `dic_material_category` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_inoutstock_detail
-- ----------------------------
INSERT INTO `his_inoutstock_detail` VALUES ('179', '126', '109', '针灸套装', '500.0', '整套', '30', '1022', '2018-03-13 15:49:28');
INSERT INTO `his_inoutstock_detail` VALUES ('180', '126', '111', '全棉拖布', '25.0', '整套', '300', '1022', '2018-03-13 15:50:24');
INSERT INTO `his_inoutstock_detail` VALUES ('181', '126', '110', '扫帚', '15.0', '塑料把扫帚', '400', '1022', '2018-03-13 15:51:38');
INSERT INTO `his_inoutstock_detail` VALUES ('182', '126', '108', '清洁控油洗面奶', '56.0', '瓶', '600', '1022', '2018-03-13 15:52:28');
INSERT INTO `his_inoutstock_detail` VALUES ('183', '126', '107', '全棉毛巾', '10.0', '一条', '1000', '1022', '2018-03-13 15:53:22');
INSERT INTO `his_inoutstock_detail` VALUES ('184', '126', '106', '刷牙杯套装', '35.0', '刷牙杯，牙膏，牙刷', '1000', '1022', '2018-03-13 15:54:23');
INSERT INTO `his_inoutstock_detail` VALUES ('185', '126', '105', '牙刷', '10.0', '软毛牙刷', '1000', '1022', '2018-03-13 15:55:12');
INSERT INTO `his_inoutstock_detail` VALUES ('186', '127', '109', '针灸套装', '500.0', '整套', '5', '1022', '2018-03-13 15:58:33');
INSERT INTO `his_inoutstock_detail` VALUES ('187', '127', '108', '清洁控油洗面奶', '56.0', '瓶', '20', '1022', '2018-03-13 15:58:53');
INSERT INTO `his_inoutstock_detail` VALUES ('188', '127', '107', '全棉毛巾', '10.0', '一条', '100', '1022', '2018-03-13 15:59:11');
INSERT INTO `his_inoutstock_detail` VALUES ('189', '127', '106', '刷牙杯套装', '35.0', '刷牙杯，牙膏，牙刷', '50', '1022', '2018-03-13 15:59:25');

-- ----------------------------
-- Table structure for his_leave_cost
-- ----------------------------
DROP TABLE IF EXISTS `his_leave_cost`;
CREATE TABLE `his_leave_cost` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LEAVE_TYPE` int(11) DEFAULT NULL COMMENT '外键表：DIC_LEAVE_TYPE，外键字段：ID',
  `COST_ID` int(11) DEFAULT NULL COMMENT '外键表：DIC_COST，外键字段：ID',
  `MIN_COST_DAY` tinyint(4) DEFAULT NULL COMMENT '改请假类型进行费用计算的最少请假天数',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `LEAVE_TYPE` (`LEAVE_TYPE`),
  KEY `COST_ID` (`COST_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_leave_cost_ibfk_1` FOREIGN KEY (`LEAVE_TYPE`) REFERENCES `dic_leave_type` (`ID`),
  CONSTRAINT `his_leave_cost_ibfk_2` FOREIGN KEY (`COST_ID`) REFERENCES `dic_cost` (`id`),
  CONSTRAINT `his_leave_cost_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_leave_cost
-- ----------------------------
INSERT INTO `his_leave_cost` VALUES ('52', '1', '79', '2', '1021', '2018-03-13 17:53:12');

-- ----------------------------
-- Table structure for his_leave_record
-- ----------------------------
DROP TABLE IF EXISTS `his_leave_record`;
CREATE TABLE `his_leave_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_BED，外键字段：ID',
  `MEMBER_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `LEAVE_TYPE` int(11) DEFAULT NULL COMMENT '外键表：DIC_LEAVE_TYPE，外键字段：ID',
  `LEAVE_DATE` date DEFAULT NULL COMMENT '选择日期',
  `LEAVE_DAY` tinyint(4) DEFAULT NULL COMMENT '不小于1',
  `REMARK` varchar(100) DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '已通过-1，待审核-2，审核拒绝-3，已销假-4，-1-已删除，已结算-0',
  `AUDITOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `AUDIT_TIME` datetime DEFAULT NULL,
  `REFUSE_REASON` varchar(100) DEFAULT NULL,
  `BACK_DATE` date DEFAULT NULL COMMENT '选择日期，必须大于等于请假时间',
  `REAL_LEAVE_DAY` tinyint(4) DEFAULT NULL COMMENT '（销假时间-请假时间）+1',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `LEAVE_TYPE` (`LEAVE_TYPE`),
  KEY `AUDITOR` (`AUDITOR`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_leave_record_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_leave_record_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_leave_record_ibfk_3` FOREIGN KEY (`LEAVE_TYPE`) REFERENCES `dic_leave_type` (`ID`),
  CONSTRAINT `his_leave_record_ibfk_4` FOREIGN KEY (`AUDITOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_leave_record_ibfk_5` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_leave_record
-- ----------------------------
INSERT INTO `his_leave_record` VALUES ('93', '206', '432', '2', '2017-07-20', '5', '去妹妹家住几天。', '4', '1021', '2018-03-13 15:22:58', '合情合理', '2017-07-26', '7', '1021', '2018-03-13 15:22:44', '2018-03-13 15:22:58');
INSERT INTO `his_leave_record` VALUES ('94', '207', '433', '2', '2017-08-13', '5', '回家', '4', '1021', '2018-03-13 15:27:29', '同意', '2017-08-18', '6', '1021', '2018-03-13 15:27:15', '2018-03-13 15:27:29');
INSERT INTO `his_leave_record` VALUES ('95', '206', '432', '2', '2017-10-13', '3', '回女儿家', '4', '1021', '2018-03-13 15:28:52', '同意', '2017-10-20', '8', '1021', '2018-03-13 15:28:43', '2018-03-13 15:28:52');
INSERT INTO `his_leave_record` VALUES ('96', '206', '432', '2', '2018-01-13', '15', '回儿子家过年。', '4', '1021', '2018-03-13 15:29:59', '同意', '2018-02-28', '47', '1021', '2018-03-13 15:29:51', '2018-03-13 15:29:59');
INSERT INTO `his_leave_record` VALUES ('97', '206', '432', '1', '2018-03-13', '3', '', '4', '1021', '2018-03-13 18:24:52', '', '2018-03-15', '3', '1021', '2018-03-13 18:24:49', '2018-03-13 18:24:52');
INSERT INTO `his_leave_record` VALUES ('98', '208', '434', '1', '2018-03-13', '1', '无', '2', null, null, null, null, null, '1029', '2018-03-13 18:39:34', null);

-- ----------------------------
-- Table structure for his_life_care
-- ----------------------------
DROP TABLE IF EXISTS `his_life_care`;
CREATE TABLE `his_life_care` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_BED，外键字段：ID',
  `MEMBER_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `WATER_INTAKE_SUM` int(11) DEFAULT NULL COMMENT '水分摄入量合计，单位mL',
  `EXCRETION_COUNT` tinyint(4) DEFAULT NULL COMMENT 'EXCRETION_COUNT',
  `BATH_COUNT` tinyint(4) DEFAULT NULL COMMENT 'BATH_COUNT',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT 'FLAG',
  `RECORD_TIME` datetime DEFAULT NULL COMMENT '用户选择的录入时间',
  `CREATOR` int(11) DEFAULT NULL COMMENT 'CREATOR',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_life_care_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_life_care_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_life_care_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=329 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_life_care
-- ----------------------------

-- ----------------------------
-- Table structure for his_life_care_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_life_care_detail`;
CREATE TABLE `his_life_care_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LIFE_CARE_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_LIFE_CARE，外键字段：ID',
  `CARE_POINT` tinyint(4) DEFAULT NULL COMMENT '取值1~24的整点时刻',
  `IS_LEAVE` tinyint(4) DEFAULT '0',
  `IS_WATER_INTAKE` tinyint(4) DEFAULT NULL COMMENT '无-0，饭类-1，水-2，水果-3',
  `INTAKE` int(11) DEFAULT NULL COMMENT '如果IS_WATER_INTAKE=1，INTAKE为评分值；如果IS_WATER_INTAKE=2或3，INTAKE为水分摄入量，单位mL；',
  `EXCRETION` tinyint(4) DEFAULT NULL COMMENT '无-0，小便-1，大便（小）-2，大便（中）-3，大便（大）-4',
  `EXCRETION_DESC` varchar(200) DEFAULT NULL,
  `MEDICATION` tinyint(4) DEFAULT NULL COMMENT '有-1，无-0，拒服-2',
  `CHECK_REST` tinyint(4) DEFAULT NULL COMMENT '无-0，睡-1，醒-2，晨-3，晚-4',
  `BATH` tinyint(4) DEFAULT NULL COMMENT '无-0，擦浴-1，沐浴-2，拒洗-3',
  `PHYSICAY_STATE` varchar(10) DEFAULT NULL COMMENT '左、右、平、半坐、坐、步行、放松',
  `REMARK` varchar(200) DEFAULT NULL COMMENT '记录未吃饭和外出吃饭的原因',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `LIFE_CARE_ID` (`LIFE_CARE_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_life_care_detail_ibfk_1` FOREIGN KEY (`LIFE_CARE_ID`) REFERENCES `his_life_care` (`ID`),
  CONSTRAINT `his_life_care_detail_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_life_care_detail
-- ----------------------------

-- ----------------------------
-- Table structure for his_medication_check
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_check`;
CREATE TABLE `his_medication_check` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `MEDICATION_DATE` time DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `MEDICATION_PHASE` tinyint(4) DEFAULT NULL,
  `FLAG` tinyint(4) NOT NULL,
  `DRUG_SUBTOTAL` varchar(100) DEFAULT NULL,
  `DRUG_TOTAL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_medication_check_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_medication_check_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_medication_check
-- ----------------------------
INSERT INTO `his_medication_check` VALUES ('71', '438', '08:00:00', '1021', '2018-03-13 19:14:47', '1', '1', '10片灰色<br>', '10片<br>');
INSERT INTO `his_medication_check` VALUES ('72', '438', '12:05:00', '1021', '2018-03-13 19:18:04', '2', '1', '7片白色<br>', '7片<br>');
INSERT INTO `his_medication_check` VALUES ('73', '437', '08:30:00', '1021', '2018-03-13 19:20:00', '1', '1', '3半片黄色<br>4片白色<br>', '3半片<br>4片<br>');
INSERT INTO `his_medication_check` VALUES ('74', '436', '08:30:00', '1021', '2018-03-13 19:20:51', '1', '1', '12片白色<br>', '12片<br>');
INSERT INTO `his_medication_check` VALUES ('75', '436', '12:30:00', '1021', '2018-03-13 19:21:36', '2', '1', '1半袋蓝色<br>', '1半袋<br>');
INSERT INTO `his_medication_check` VALUES ('76', '436', '19:00:00', '1021', '2018-03-13 19:22:22', '1', '1', '5袋黄色<br>', '5袋<br>');

-- ----------------------------
-- Table structure for his_medication_check_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_check_detail`;
CREATE TABLE `his_medication_check_detail` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MEDICATION_CHECK_ID` int(11) DEFAULT NULL,
  `DRUG_NAME` varchar(30) DEFAULT NULL,
  `DOSAGE` varchar(20) DEFAULT NULL,
  `DRUG_FUNCTION` varchar(100) DEFAULT NULL,
  `DRUG_QUANTITY` tinyint(3) DEFAULT NULL,
  `QUANTITY_UNIT` varchar(10) DEFAULT NULL,
  `DRUG_COLOR` varchar(10) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL,
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  `flag` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `MEDICATION_CHECK_ID` (`MEDICATION_CHECK_ID`),
  KEY `FK_his_medication_check_detail` (`CREATOR`),
  CONSTRAINT `FK_his_medication_check_detail` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_medication_check_detail_ibfk_1` FOREIGN KEY (`MEDICATION_CHECK_ID`) REFERENCES `his_medication_check` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_medication_check_detail
-- ----------------------------
INSERT INTO `his_medication_check_detail` VALUES ('80', '71', '阿莫西林', '1', '消炎', '10', '2', '3', '1021', '2018-03-13 19:14:47', null, '1');
INSERT INTO `his_medication_check_detail` VALUES ('81', '72', '硝酸甘油', '1', '心脏病急救', '7', '2', '1', '1021', '2018-03-13 19:18:04', null, '1');
INSERT INTO `his_medication_check_detail` VALUES ('82', '73', '阿德福韦', '1', '肝炎', '4', '2', '1', '1021', '2018-03-13 19:19:14', '2018-03-13 19:20:00', '1');
INSERT INTO `his_medication_check_detail` VALUES ('83', '73', '拉米夫定片', '1', '肝炎', '3', '1', '5', '1021', '2018-03-13 19:20:00', null, '1');
INSERT INTO `his_medication_check_detail` VALUES ('84', '74', '阿莫西林', '1', '消炎', '12', '2', '1', '1021', '2018-03-13 19:20:51', null, '1');
INSERT INTO `his_medication_check_detail` VALUES ('85', '75', '阿巴卡韦拉米夫定片', '1', '乙肝', '1', '5', '6', '1021', '2018-03-13 19:21:36', null, '1');
INSERT INTO `his_medication_check_detail` VALUES ('86', '76', '贺普丁', '1', '肝炎', '5', '6', '5', '1021', '2018-03-13 19:22:22', null, '1');

-- ----------------------------
-- Table structure for his_medication_mistake_omission
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_mistake_omission`;
CREATE TABLE `his_medication_mistake_omission` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `MISTAKE_DATE` datetime DEFAULT NULL COMMENT '错漏时间',
  `DETAIL` varchar(200) DEFAULT NULL COMMENT '药物疏漏详情',
  `REASON` varchar(200) DEFAULT NULL COMMENT '疏漏原因',
  `DISCOVERER` varchar(10) DEFAULT NULL COMMENT '发现人',
  `CORRECTION_METHOD` varchar(200) DEFAULT NULL COMMENT '改正方法',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_medication_mistake_omission_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_medication_mistake_omission_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_medication_mistake_omission_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COMMENT='错漏摆记录表';

-- ----------------------------
-- Records of his_medication_mistake_omission
-- ----------------------------

-- ----------------------------
-- Table structure for his_medication_notification
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_notification`;
CREATE TABLE `his_medication_notification` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `ATTACHMENT_ID` int(11) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `ATTACHMENT_ID` (`ATTACHMENT_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_medication_notification_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_medication_notification_ibfk_3` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_medication_notification_ibfk_4` FOREIGN KEY (`ATTACHMENT_ID`) REFERENCES `his_attachment` (`Id`),
  CONSTRAINT `his_medication_notification_ibfk_5` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_medication_notification
-- ----------------------------

-- ----------------------------
-- Table structure for his_medication_store
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_store`;
CREATE TABLE `his_medication_store` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL,
  `DRUG_NAME` varchar(50) DEFAULT NULL,
  `DRUG_QUANTITY` varchar(50) DEFAULT NULL,
  `EXPIRY_DATE` date DEFAULT NULL,
  `DRUG_FUNCTION` varchar(200) DEFAULT NULL,
  `SIDE_EFFECT` varchar(200) DEFAULT NULL,
  `USAGE_DOSAGE` varchar(200) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(11) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `UPDATE_USER` (`UPDATE_USER`),
  CONSTRAINT `his_medication_store_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_medication_store_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_medication_store_ibfk_3` FOREIGN KEY (`UPDATE_USER`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_medication_store
-- ----------------------------
INSERT INTO `his_medication_store` VALUES ('27', '434', '阿莫西林胶囊', '4', '2019-06-13', '消炎药', '肾功能障碍者慎用。', '口服2粒，一日3次。', null, '2018-03-13 15:38:14', '1025', '2018-03-13 15:39:38');
INSERT INTO `his_medication_store` VALUES ('28', '434', '复方氨酚烷胺', '2', '2019-03-13', '感冒药', '谨遵医嘱。', '口服1粒，一日2次。', '1025', '2018-03-13 15:41:06', '1025', '2018-03-13 15:41:06');
INSERT INTO `his_medication_store` VALUES ('29', '434', '头孢', '2', '2019-03-13', '消炎药', '肾功能不全者慎用，不得饮酒。', '口服2粒，一日3次。', '1025', '2018-03-13 15:42:21', '1025', '2018-03-13 15:42:21');
INSERT INTO `his_medication_store` VALUES ('30', '433', '999感冒灵', '3', '2019-03-13', '感冒药', '谨遵医嘱。', '口服1粒，一日2次。', '1027', '2018-03-13 15:43:46', '1027', '2018-03-13 15:43:46');
INSERT INTO `his_medication_store` VALUES ('31', '432', '三精补血口服液', '4', '2019-03-13', '补血', '谨遵医嘱。', '口服1瓶，一日2次。', '1027', '2018-03-13 15:45:22', '1027', '2018-03-13 15:45:22');

-- ----------------------------
-- Table structure for his_medication_using
-- ----------------------------
DROP TABLE IF EXISTS `his_medication_using`;
CREATE TABLE `his_medication_using` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `USING_TIME` datetime NOT NULL,
  `USING_PHASE` tinyint(4) NOT NULL,
  `MEDICATION_CHECK_ID` int(11) DEFAULT NULL,
  `CHECK_TIME` time DEFAULT NULL,
  `REJECT_REASON` varchar(100) DEFAULT NULL,
  `FLAG` tinyint(4) NOT NULL,
  `REMARK` text,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `MEDICATION_CHECK_ID` (`MEDICATION_CHECK_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_medication_using_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_medication_using_ibfk_2` FOREIGN KEY (`MEDICATION_CHECK_ID`) REFERENCES `his_medication_check` (`Id`),
  CONSTRAINT `his_medication_using_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_medication_using
-- ----------------------------

-- ----------------------------
-- Table structure for his_member
-- ----------------------------
DROP TABLE IF EXISTS `his_member`;
CREATE TABLE `his_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL DEFAULT '1' COMMENT '外键表：UUMS_USER，外键字段：ID',
  `NAME` varchar(10) NOT NULL DEFAULT '',
  `SEX` tinyint(3) NOT NULL DEFAULT '1',
  `NATIVE_PLACE` varchar(20) DEFAULT NULL,
  `AGE` tinyint(3) DEFAULT NULL,
  `BIRTHDAY` date DEFAULT NULL,
  `NATION` varchar(15) DEFAULT NULL,
  `RELIGION` varchar(15) DEFAULT NULL,
  `EDUCATION_LEVEL` char(5) DEFAULT NULL COMMENT '博士-1，硕士-2，本科-3，大专-4，高中-5，中专-6，初中-7，小学-8，半文盲-9，文盲-10',
  `CERTIFICATE_CLASS` tinyint(3) DEFAULT '0' COMMENT '外键表：DIC__CERTIFICATE_CLASS，外键字段：ID',
  `CERTIFICATE_NUMBER` char(20) DEFAULT '',
  `MOBILE` char(15) DEFAULT NULL,
  `TEL` varchar(15) DEFAULT '',
  `SELFCARE_ABILITY` tinyint(10) DEFAULT NULL COMMENT '生活能自理-1、生活半自理-2、生活不能自理-3',
  `ADDRESS` varchar(50) NOT NULL DEFAULT '' COMMENT '详细地址，到门牌号',
  `MEMBER_SOURCE` tinyint(3) DEFAULT NULL COMMENT '经人或项目介绍-1，看门牌-2，看见宣传单页及宣传片-3',
  `ESTIMATE_INTETION` tinyint(3) DEFAULT NULL COMMENT '机构养老-居家养老',
  `IS_ACCEPT_INVITATION` tinyint(4) DEFAULT '0' COMMENT '是-1，否-0，默认0',
  `MEDICARE_NO` char(20) DEFAULT NULL,
  `REMARK` varchar(500) DEFAULT '1' COMMENT '对应原型中的客户具体情况',
  `PLAN_CHECKIN_TIME` date DEFAULT '2017-01-01',
  `HAVE_EVALUATTION` tinyint(3) DEFAULT '0' COMMENT '是-1，否-0，默认0',
  `EVALUATE_TIME` datetime DEFAULT NULL COMMENT '如果是否安排评估为1，则需设置评估时间',
  `HAVE_CONTRACT` tinyint(3) DEFAULT NULL COMMENT '是-1，否-0，默认0',
  `CREATOR` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL DEFAULT '2017-01-01 00:00:00',
  `UPDATE_TIME` datetime DEFAULT NULL,
  `FLAG` tinyint(3) NOT NULL DEFAULT '3' COMMENT '正常-1，停用-0，注销-2，储备客户-3，待评估-4，待体检-5，体检待初审-6，体检待复审-7，待试住-8，待试住缴费-9，试住-10，待正式缴费-11，退住-12，默认3',
  PRIMARY KEY (`ID`),
  KEY `FK_USER_MEMBER` (`USER_ID`),
  KEY `FK_USER_MEMBER_1` (`CREATOR`),
  KEY `FK_CERTIFICATE_MEMBER` (`CERTIFICATE_CLASS`),
  KEY `FK_LEVEL_MEMBER` (`REMARK`(255)),
  CONSTRAINT `FK_CERTIFICATE_MEMBER` FOREIGN KEY (`CERTIFICATE_CLASS`) REFERENCES `dic_certificate_class` (`ID`),
  CONSTRAINT `FK_USER_MEMBER` FOREIGN KEY (`USER_ID`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `FK_USER_MEMBER_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=441 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member
-- ----------------------------
INSERT INTO `his_member` VALUES ('432', '1023', '宋欣荣', '2', '北京 市辖区 东城区 ', '56', null, '汉', '无', '', '1', '110101196205014831', '17600060666', '', '2', '北京 市辖区 东城区 ', null, null, null, null, '状态良好，行动语言流利。', '2017-04-21', null, '2018-04-04 00:00:00', null, '1021', '2018-03-13 10:02:03', null, '1');
INSERT INTO `his_member` VALUES ('433', '1024', '王卫国', '1', '北京', '68', '1950-05-05', '汉', '', null, '1', '110106195005058618', '15632251252', '', '1', '北京市昌平区北七家镇平西王府村', null, null, null, '', '身体健朗，能够自理', '2018-01-03', null, '2018-01-03 00:00:00', '1', '1021', '2018-03-13 14:48:46', '2018-03-13 14:53:17', '1');
INSERT INTO `his_member` VALUES ('434', '1032', '石光荣', '1', '河北', '88', null, '汉', '', '9', '1', '110106193007062494', '18922231643', '', '3', '北京市西城区', null, null, '0', null, '生活不能自理', '2018-03-05', null, '2018-03-05 00:00:00', '0', '1021', '2018-03-13 15:14:23', null, '10');
INSERT INTO `his_member` VALUES ('435', '1033', '褚琴', '2', '', '60', null, '汉', '', '', '1', '110102195801019366', '15912135431', '', '1', '北京市昌平区沙河镇于辛庄村', null, null, '1', null, '', '2018-03-11', null, '2018-03-11 00:00:00', '0', '1021', '2018-03-13 15:40:50', null, '10');
INSERT INTO `his_member` VALUES ('436', '1034', '杨大海', '1', '', '65', null, '汉', '', '', '1', '110102195301011903', '13313455463', '', '1', '北京市海淀区', null, null, '1', null, '', '2017-03-06', null, '2017-03-05 00:00:00', '0', '1021', '2018-03-13 16:17:16', null, '1');
INSERT INTO `his_member` VALUES ('437', '1035', '陈健', '1', '', '65', null, 'h汉', '', '', '1', '110102195801011823', '15632255435', '', '1', '北京市昌平区', null, null, '1', null, '身体健康，能够自理', '2018-03-03', null, '2018-03-03 16:54:00', '0', '1021', '2018-03-13 16:53:16', null, '10');
INSERT INTO `his_member` VALUES ('438', '1036', '江涛', '1', '', '69', null, '汉', '', '', '1', '110102195104052367', '15632252315', '', '1', '北京市', null, null, '1', null, '身体健康', '2018-03-04', null, '2018-03-04 00:00:00', '0', '1021', '2018-03-13 16:55:30', null, '10');
INSERT INTO `his_member` VALUES ('439', '1038', '冯建军', '1', '北京市昌平区', '56', null, '汉', '无', '6', '1', '110114196303140040', '13673687689', '', '1', '北京市昌平区', null, null, '1', null, '', '2018-05-24', null, '2018-03-15 10:06:41', null, '1021', '2018-03-14 15:37:27', null, '4');
INSERT INTO `his_member` VALUES ('440', '1040', '李亚鹏', '1', '', '60', null, '', '', '', '1', '110224198105111578', '13044678971', '', '1', '北京市昌平区', null, null, null, null, '无', null, null, null, null, '1021', '2018-05-23 18:54:56', null, '3');

-- ----------------------------
-- Table structure for his_member_checkup
-- ----------------------------
DROP TABLE IF EXISTS `his_member_checkup`;
CREATE TABLE `his_member_checkup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `FIRST_CHECK_PERSON` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `FIRST_CHECK_TIME` datetime DEFAULT NULL,
  `RECHECK_PERSON` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `RECHECK_TIME` datetime DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '待初审-1，初审通过 待复审-2，初审未通过-3，复审通过-4，复审未通过-5',
  `CREATOR` int(11) DEFAULT NULL COMMENT '体检报告录入人员，外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `cause` varchar(255) DEFAULT NULL COMMENT '原因',
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `FIRST_CHECK_PERSON` (`FIRST_CHECK_PERSON`),
  KEY `RECHECK_PERSON` (`RECHECK_PERSON`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_member_checkup_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_member_checkup_ibfk_2` FOREIGN KEY (`FIRST_CHECK_PERSON`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_member_checkup_ibfk_3` FOREIGN KEY (`RECHECK_PERSON`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_member_checkup_ibfk_4` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_checkup
-- ----------------------------
INSERT INTO `his_member_checkup` VALUES ('371', '432', '1021', '2018-03-13 11:32:10', '1021', '2018-03-13 11:32:31', '4', '1021', '2018-03-13 11:31:09', '未发现异常。', '未发现身体异常及严重疾病。');
INSERT INTO `his_member_checkup` VALUES ('372', '433', '1021', '2018-03-13 15:00:56', '1021', '2018-03-13 15:01:02', '4', '1021', '2018-03-13 15:00:34', '状态良好', '');
INSERT INTO `his_member_checkup` VALUES ('373', '434', '1021', '2018-03-13 15:26:46', '1021', '2018-03-13 15:26:49', '4', '1021', '2018-03-13 15:26:42', '无', '');
INSERT INTO `his_member_checkup` VALUES ('374', '435', '1021', '2018-03-13 15:47:55', '1021', '2018-03-13 15:47:57', '4', '1021', '2018-03-13 15:47:51', '身体健康，能够自理', '');
INSERT INTO `his_member_checkup` VALUES ('375', '436', '1021', '2018-03-13 16:23:12', '1021', '2018-03-13 16:23:15', '4', '1021', '2018-03-13 16:23:08', '无', '');
INSERT INTO `his_member_checkup` VALUES ('376', '437', '1021', '2018-03-13 17:00:26', '1021', '2018-03-13 17:00:29', '4', '1021', '2018-03-13 17:00:21', '身体健康，精神矍铄', '');
INSERT INTO `his_member_checkup` VALUES ('377', '438', '1021', '2018-03-13 17:01:09', '1021', '2018-03-13 17:01:11', '4', '1021', '2018-03-13 17:00:44', '身体健康，精神矍铄', '');

-- ----------------------------
-- Table structure for his_member_emergency_contact
-- ----------------------------
DROP TABLE IF EXISTS `his_member_emergency_contact`;
CREATE TABLE `his_member_emergency_contact` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：BMS_MEMBER，外键字段：ID',
  `NAME` varchar(10) NOT NULL DEFAULT '',
  `MOBILE` char(11) NOT NULL DEFAULT '',
  `ADDRESS` varchar(50) NOT NULL DEFAULT '' COMMENT '详细地址，到门牌号',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_USER_CHILDREN` (`CREATOR`),
  KEY `FK_MEMBER_CHILDREN` (`MEMBER_ID`),
  CONSTRAINT `FK_MEMBER_CHILDREN` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `FK_USER_CHILDREN` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_emergency_contact
-- ----------------------------

-- ----------------------------
-- Table structure for his_member_evaluate
-- ----------------------------
DROP TABLE IF EXISTS `his_member_evaluate`;
CREATE TABLE `his_member_evaluate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `EVALUATOR` varchar(10) DEFAULT NULL,
  `EVA_TIME` datetime DEFAULT NULL,
  `EVA_RESULT` tinyint(4) DEFAULT NULL COMMENT '通过-1，不通过-0',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '只读-0，编辑-1，默认1',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：USER，外键字段ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_member_evaluate_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_member_evaluate_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=817 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_evaluate
-- ----------------------------
INSERT INTO `his_member_evaluate` VALUES ('806', '432', '1021', '2018-03-13 11:24:35', '1', '1', '1021', '2018-03-13 10:06:45');
INSERT INTO `his_member_evaluate` VALUES ('807', '433', null, null, null, '0', '1021', '2018-03-13 14:54:25');
INSERT INTO `his_member_evaluate` VALUES ('808', '433', '1021', '2018-03-13 14:58:06', '1', '1', '1021', '2018-03-13 14:54:35');
INSERT INTO `his_member_evaluate` VALUES ('809', '434', '1021', '2018-03-13 15:25:44', '1', '1', '1021', '2018-03-13 15:21:52');
INSERT INTO `his_member_evaluate` VALUES ('810', '435', '1021', '2018-03-13 15:47:26', '1', '1', '1021', '2018-03-13 15:45:32');
INSERT INTO `his_member_evaluate` VALUES ('811', '436', '1021', '2018-03-13 16:21:12', '1', '0', '1021', '2018-03-13 16:18:11');
INSERT INTO `his_member_evaluate` VALUES ('812', '438', '1021', '2018-03-13 16:58:27', '1', '1', '1021', '2018-03-13 16:56:23');
INSERT INTO `his_member_evaluate` VALUES ('813', '437', '1021', '2018-03-13 17:00:01', '1', '1', '1021', '2018-03-13 16:58:40');
INSERT INTO `his_member_evaluate` VALUES ('814', '436', null, null, null, '0', '1021', '2018-03-15 10:04:17');
INSERT INTO `his_member_evaluate` VALUES ('815', '439', null, null, null, '1', '1021', '2018-03-15 10:56:28');
INSERT INTO `his_member_evaluate` VALUES ('816', '436', null, null, null, '1', '1021', '2018-03-16 12:20:57');

-- ----------------------------
-- Table structure for his_member_health
-- ----------------------------
DROP TABLE IF EXISTS `his_member_health`;
CREATE TABLE `his_member_health` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL DEFAULT '0',
  `SIGHT` varchar(100) DEFAULT NULL,
  `HEARING` varchar(100) DEFAULT NULL,
  `DEFECATION` varchar(100) DEFAULT NULL,
  `URINATION` varchar(100) DEFAULT NULL,
  `MEDICAL_HISTORY` varchar(500) DEFAULT NULL COMMENT '既往史/现病史',
  `DESIGNATED_HOSPITAL` varchar(100) DEFAULT NULL,
  `DRUG_USE` varchar(500) DEFAULT NULL,
  `REMARK` varchar(500) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_MEMBER_HEALTH` (`MEMBER_ID`),
  KEY `FK_USER_HEALTH` (`CREATOR`),
  CONSTRAINT `FK_MEMBER_HEALTH` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `FK_USER_HEALTH` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_health
-- ----------------------------

-- ----------------------------
-- Table structure for his_member_medication
-- ----------------------------
DROP TABLE IF EXISTS `his_member_medication`;
CREATE TABLE `his_member_medication` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL,
  `DRUG_NAME` varchar(50) DEFAULT NULL,
  `DRUG_QUANTITY` varchar(50) DEFAULT NULL,
  `USAGE_DOSAGE` varchar(200) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_member_medication_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_member_medication_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_medication
-- ----------------------------
INSERT INTO `his_member_medication` VALUES ('34', '434', '阿莫西林胶囊', '4', '饭后口服2粒，一日3次。', '1021', '2018-03-13 15:31:47', null);
INSERT INTO `his_member_medication` VALUES ('35', '434', '复方氨酚烷胺胶囊', '2', '口服1粒，一日两次。', '1021', '2018-03-13 15:32:45', null);
INSERT INTO `his_member_medication` VALUES ('36', '434', '头孢', '2', '口服2粒，一日3次。', '1021', '2018-03-13 15:33:21', null);
INSERT INTO `his_member_medication` VALUES ('37', '433', '999感冒灵', '3', '口服1粒，一日2次。', '1021', '2018-03-13 15:34:17', null);
INSERT INTO `his_member_medication` VALUES ('38', '432', '吴太太补血口服液', '2', '口服1瓶，一日2次。', '1021', '2018-03-13 15:35:25', null);

-- ----------------------------
-- Table structure for his_member_profile
-- ----------------------------
DROP TABLE IF EXISTS `his_member_profile`;
CREATE TABLE `his_member_profile` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：BMS_MEMBER，外键字段：ID',
  `HOBBY` varchar(200) DEFAULT '',
  `DAY_NIGHT_NURSE` varchar(200) DEFAULT NULL,
  `BATH` varchar(200) DEFAULT '',
  `CLOTHING` varchar(200) DEFAULT '',
  `FOOD` varchar(200) DEFAULT '',
  `WALK` varchar(200) DEFAULT '',
  `EXCRETION` varchar(200) DEFAULT '',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_MEMBER_PROFILE` (`MEMBER_ID`),
  KEY `FK_USER_PROFILE` (`CREATOR`),
  CONSTRAINT `FK_MEMBER_PROFILE` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `FK_USER_PROFILE` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_member_profile
-- ----------------------------

-- ----------------------------
-- Table structure for his_nersing_care_plan
-- ----------------------------
DROP TABLE IF EXISTS `his_nersing_care_plan`;
CREATE TABLE `his_nersing_care_plan` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `EVA_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER_EVALUATE，外键字段：ID',
  `CARE_PROGRAM` text COMMENT '照料方案富文本',
  `CAUTIONS` text COMMENT '注意事项富文本',
  `CREATOR` int(3) NOT NULL DEFAULT '0' COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `EVA_ID` (`EVA_ID`),
  CONSTRAINT `his_nersing_care_plan_ibfk_1` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_nersing_care_plan_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_nersing_care_plan_ibfk_3` FOREIGN KEY (`EVA_ID`) REFERENCES `his_member_evaluate` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COMMENT='护理计划表';

-- ----------------------------
-- Records of his_nersing_care_plan
-- ----------------------------
INSERT INTO `his_nersing_care_plan` VALUES ('130', '432', '806', '安排护理人员照顾起居饮食，组织参加简单有意思的户外和室内活动，改善精神和记忆力状况，配备辅助听力设备。', '精神较好，身体机能退化，注意饮食营养搭配。', '1021', '2018-03-13 11:29:01', null);
INSERT INTO `his_nersing_care_plan` VALUES ('131', '433', '808', '日常生活照料，生命体征护理', '无\n                                \n                            ', '1021', '2018-03-13 14:59:02', null);
INSERT INTO `his_nersing_care_plan` VALUES ('132', '434', '809', '<p>生活照料</p><p>翻身</p><p>生命体征</p><p>\n                                \n                            </p>', '注意看护\n                                \n                            ', '1021', '2018-03-13 15:26:17', null);
INSERT INTO `his_nersing_care_plan` VALUES ('133', '435', '810', '身体健康，能够自理\n                                \n                            ', '无\n                                \n                            ', '1021', '2018-03-13 15:47:35', null);
INSERT INTO `his_nersing_care_plan` VALUES ('134', '436', '811', '生命体征照料\n                                \n                            ', '无\n                                \n                            ', '1021', '2018-03-13 16:21:26', null);

-- ----------------------------
-- Table structure for his_notice
-- ----------------------------
DROP TABLE IF EXISTS `his_notice`;
CREATE TABLE `his_notice` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(50) NOT NULL,
  `NOTICE_WAY` tinyint(4) DEFAULT NULL COMMENT '1-站内信，2-短信',
  `CONTENT` text COMMENT '富文本',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '待发送-0，已发送-1，默认0',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_notice_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_notice
-- ----------------------------
INSERT INTO `his_notice` VALUES ('273', '全体会议', '1', '宣讲党政会议精神', '1', '1021', '2018-03-13 14:29:46', null);
INSERT INTO `his_notice` VALUES ('274', '123', '1', '123', '1', '1021', '2018-04-27 18:00:00', null);

-- ----------------------------
-- Table structure for his_notice_attachment
-- ----------------------------
DROP TABLE IF EXISTS `his_notice_attachment`;
CREATE TABLE `his_notice_attachment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOTICE_ID` int(11) NOT NULL COMMENT '外键表：HIS_NOTICE，外键字段：ID',
  `ATTACHMENT_ID` int(11) NOT NULL COMMENT '外键表：HIS_ATTACHMENT，外键字段：ID',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `NOTICE_ID` (`NOTICE_ID`),
  KEY `ATTACHMENT_ID` (`ATTACHMENT_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_notice_attachment_ibfk_1` FOREIGN KEY (`NOTICE_ID`) REFERENCES `his_notice` (`ID`),
  CONSTRAINT `his_notice_attachment_ibfk_2` FOREIGN KEY (`ATTACHMENT_ID`) REFERENCES `his_attachment` (`Id`),
  CONSTRAINT `his_notice_attachment_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_notice_attachment
-- ----------------------------
INSERT INTO `his_notice_attachment` VALUES ('197', '274', '849', null, null);

-- ----------------------------
-- Table structure for his_notice_process
-- ----------------------------
DROP TABLE IF EXISTS `his_notice_process`;
CREATE TABLE `his_notice_process` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOTICE_ID` int(11) NOT NULL COMMENT '外键表：HIS_NOTICE，外键字段：ID',
  `SENDER` int(11) DEFAULT NULL,
  `SEND_TIME` datetime DEFAULT NULL,
  `RECEIVER` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `RECEIVE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `NOTICE_ID` (`NOTICE_ID`),
  KEY `SENDER` (`SENDER`),
  KEY `RECEIVER` (`RECEIVER`),
  CONSTRAINT `his_notice_process_ibfk_1` FOREIGN KEY (`NOTICE_ID`) REFERENCES `his_notice` (`ID`),
  CONSTRAINT `his_notice_process_ibfk_2` FOREIGN KEY (`SENDER`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_notice_process_ibfk_3` FOREIGN KEY (`RECEIVER`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1183 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_notice_process
-- ----------------------------
INSERT INTO `his_notice_process` VALUES ('1180', '273', '1021', '2018-03-13 14:30:03', '1022', null);
INSERT INTO `his_notice_process` VALUES ('1181', '273', '1021', '2018-03-13 14:30:03', '1023', null);
INSERT INTO `his_notice_process` VALUES ('1182', '274', '1021', '2018-04-27 18:00:27', '1022', null);

-- ----------------------------
-- Table structure for his_nursing_care_record
-- ----------------------------
DROP TABLE IF EXISTS `his_nursing_care_record`;
CREATE TABLE `his_nursing_care_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `REMARK` varchar(500) DEFAULT NULL,
  `RECORD_TIME` datetime DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_nursing_care_record_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_nursing_care_record_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_nursing_care_record_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_nursing_care_record
-- ----------------------------
INSERT INTO `his_nursing_care_record` VALUES ('242', '206', '432', '1.查房，老人于床上休息，无明显异常。', '2017-04-29 02:13:32', '1021', '2018-03-13 14:14:16', null);
INSERT INTO `his_nursing_care_record` VALUES ('243', '207', '433', '5.查房，老人于三层花园休息，无明显异常。', '2018-02-21 15:06:58', '1021', '2018-03-13 15:07:20', null);
INSERT INTO `his_nursing_care_record` VALUES ('244', '208', '434', '1.查房，老人于床上休息，无明显异常。', '2018-03-13 15:28:54', '1021', '2018-03-13 15:29:08', null);
INSERT INTO `his_nursing_care_record` VALUES ('245', '209', '435', '5.查房，老人于三层花园休息，无明显异常。', '2018-03-13 15:50:28', '1021', '2018-03-13 15:50:45', null);
INSERT INTO `his_nursing_care_record` VALUES ('246', '210', '436', '3.查房，老人于轮椅上休息，无明显异常。', '2018-03-13 16:26:19', '1021', '2018-03-13 16:26:34', null);
INSERT INTO `his_nursing_care_record` VALUES ('247', '211', '438', '2.查房，老人于椅子上休息，无明显异常。', '2018-03-13 17:03:42', '1021', '2018-03-13 17:03:55', null);
INSERT INTO `his_nursing_care_record` VALUES ('248', '212', '437', '5.查房，老人于三层花园休息，无明显异常。', '2018-03-13 17:04:03', '1021', '2018-03-13 17:04:13', null);
INSERT INTO `his_nursing_care_record` VALUES ('249', '208', '434', '2.查房，老人于椅子上休息，无明显异常。', '2018-03-13 18:37:36', '1029', '2018-03-13 18:37:40', null);
INSERT INTO `his_nursing_care_record` VALUES ('250', '206', '432', '1.查房，老人于床上休息，无明显异常。', '2018-04-08 10:36:59', '1021', '2018-04-08 10:37:15', null);
INSERT INTO `his_nursing_care_record` VALUES ('251', '206', '432', '1.查房，老人于床上休息，无明显异常。', '2018-04-08 10:37:20', '1021', '2018-04-08 10:37:37', null);
INSERT INTO `his_nursing_care_record` VALUES ('252', '208', '434', '1.查房，老人于床上休息，无明显异常。', '2018-04-08 10:38:45', '1021', '2018-04-08 10:38:54', null);
INSERT INTO `his_nursing_care_record` VALUES ('253', '206', '432', '1.查房，老人于床上休息，无明显异常。', '2018-04-08 10:39:41', '1021', '2018-04-08 10:39:49', null);
INSERT INTO `his_nursing_care_record` VALUES ('254', '207', '433', '1.查房，老人于床上休息，无明显异常。', '2018-04-08 11:54:07', '1021', '2018-04-08 11:54:14', null);
INSERT INTO `his_nursing_care_record` VALUES ('255', '207', '433', '3.查房，老人于轮椅上休息，无明显异常。', '2018-04-08 11:57:06', '1021', '2018-04-08 11:57:04', null);

-- ----------------------------
-- Table structure for his_return_charge_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_return_charge_detail`;
CREATE TABLE `his_return_charge_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CHARGE_RECORD_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_CHARGE_RECORD，外键字段：ID',
  `RETURN_TYPE` int(11) DEFAULT NULL COMMENT '请假-1',
  `LEAVE_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_LEAVE，外键字段：ID',
  `COST_TOTAL` decimal(6,1) DEFAULT NULL COMMENT '请假退费标准*假期天数',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CHARGE_RECORD_ID` (`CHARGE_RECORD_ID`),
  KEY `LEAVE_ID` (`LEAVE_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_return_charge_detail_ibfk_1` FOREIGN KEY (`CHARGE_RECORD_ID`) REFERENCES `his_charge_record` (`ID`),
  CONSTRAINT `his_return_charge_detail_ibfk_2` FOREIGN KEY (`LEAVE_ID`) REFERENCES `his_leave_record` (`ID`),
  CONSTRAINT `his_return_charge_detail_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_return_charge_detail
-- ----------------------------

-- ----------------------------
-- Table structure for his_schedule
-- ----------------------------
DROP TABLE IF EXISTS `his_schedule`;
CREATE TABLE `his_schedule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) DEFAULT NULL,
  `START_TIME` time DEFAULT NULL,
  `END_TIME` time DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_schedule_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_schedule
-- ----------------------------
INSERT INTO `his_schedule` VALUES ('96', 'A01', '07:05:00', '15:05:00', '1021', '2018-03-13 15:11:06', '2018-03-13 15:11:06');
INSERT INTO `his_schedule` VALUES ('97', 'A02', '15:05:00', '22:05:00', '1021', '2018-03-13 15:12:47', '2018-03-13 15:12:47');

-- ----------------------------
-- Table structure for his_schedule_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_schedule_detail`;
CREATE TABLE `his_schedule_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SCHEDULE_DATE` date DEFAULT NULL,
  `SCHEDULE_ID` int(11) DEFAULT NULL,
  `EMPLOYES` varchar(300) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `SCHEDULE_ID` (`SCHEDULE_ID`),
  CONSTRAINT `his_schedule_detail_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_schedule_detail_ibfk_2` FOREIGN KEY (`SCHEDULE_ID`) REFERENCES `his_schedule` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_schedule_detail
-- ----------------------------
INSERT INTO `his_schedule_detail` VALUES ('158', '2018-03-13', '96', '101,102,103', '1', '2018-03-13 15:13:35', '2018-03-13 15:14:56');
INSERT INTO `his_schedule_detail` VALUES ('159', '2018-03-14', '96', '104,105,106', '1', '2018-03-13 15:15:55', '2018-03-13 15:15:55');
INSERT INTO `his_schedule_detail` VALUES ('160', '2018-03-13', '97', '104,105,106,107', '1', '2018-03-13 15:16:17', '2018-03-13 15:16:17');
INSERT INTO `his_schedule_detail` VALUES ('161', '2018-03-14', '97', '101,102,103', '1', '2018-03-13 15:16:26', '2018-03-13 15:16:26');
INSERT INTO `his_schedule_detail` VALUES ('162', '2018-03-15', '96', '101,102,103', '1', '2018-03-13 15:16:40', '2018-03-13 15:16:40');
INSERT INTO `his_schedule_detail` VALUES ('163', '2018-03-16', '96', '104,105,106', '1', '2018-03-13 15:16:49', '2018-03-13 15:16:49');
INSERT INTO `his_schedule_detail` VALUES ('164', '2018-03-15', '97', '104,105,106', '1', '2018-03-13 15:17:00', '2018-03-13 15:17:00');
INSERT INTO `his_schedule_detail` VALUES ('165', '2018-03-16', '97', '101,102,103', '1', '2018-03-13 15:17:06', '2018-03-13 15:17:06');
INSERT INTO `his_schedule_detail` VALUES ('166', '2018-03-12', '97', '101', '1', '2018-03-13 18:36:06', '2018-03-13 18:36:06');

-- ----------------------------
-- Table structure for his_shift
-- ----------------------------
DROP TABLE IF EXISTS `his_shift`;
CREATE TABLE `his_shift` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `remark` varchar(500) DEFAULT NULL COMMENT '说明',
  `EXCHANGE_PERSON` varchar(100) DEFAULT NULL COMMENT '接班人名，逗号分隔',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '1-已交班，0-为交班，默认0',
  `EXCHANGE_TIME` datetime DEFAULT NULL,
  `creator` int(11) DEFAULT NULL COMMENT '外键表：uums_user,外键字段：id',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`Id`),
  KEY `creator` (`creator`),
  CONSTRAINT `his_shift_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8 COMMENT='日常交班表';

-- ----------------------------
-- Records of his_shift
-- ----------------------------
INSERT INTO `his_shift` VALUES ('170', '交班说明。', '祖秋白', '1', '2018-03-13 18:30:51', '1031', '2018-03-13 18:28:03', null);
INSERT INTO `his_shift` VALUES ('171', '交班说明。', null, '0', null, '1029', '2018-03-13 18:32:30', null);

-- ----------------------------
-- Table structure for his_shift_book
-- ----------------------------
DROP TABLE IF EXISTS `his_shift_book`;
CREATE TABLE `his_shift_book` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `bed_id` int(11) DEFAULT NULL COMMENT '外键床位ID',
  `member_id` int(11) DEFAULT NULL COMMENT '用户id',
  `flag` tinyint(3) DEFAULT NULL COMMENT '未选择-0\\异常-1\\事故-2\\入住-3\\退住-4\\请假-5\\销假-6\\住院-7\\其他-8',
  `remark` varchar(300) DEFAULT NULL COMMENT '备注',
  `creator` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `bed_id` (`bed_id`),
  KEY `member_id` (`member_id`),
  KEY `creator` (`creator`),
  CONSTRAINT `his_shift_book_ibfk_1` FOREIGN KEY (`bed_id`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_shift_book_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_shift_book_ibfk_3` FOREIGN KEY (`creator`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8 COMMENT='护理交班薄';

-- ----------------------------
-- Records of his_shift_book
-- ----------------------------

-- ----------------------------
-- Table structure for his_shift_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_shift_detail`;
CREATE TABLE `his_shift_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SHIFT_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_SHIFT，外键字段：ID',
  `CONTENT` varchar(500) DEFAULT NULL,
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SHIFT_ID` (`SHIFT_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_shift_detail_ibfk_1` FOREIGN KEY (`SHIFT_ID`) REFERENCES `his_shift` (`Id`),
  CONSTRAINT `his_shift_detail_ibfk_2` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_shift_detail
-- ----------------------------
INSERT INTO `his_shift_detail` VALUES ('59', '170', '交班说明', '1031', '2018-03-13 18:28:03', null);
INSERT INTO `his_shift_detail` VALUES ('60', '171', '交班说明', '1029', '2018-03-13 18:32:30', null);

-- ----------------------------
-- Table structure for his_shift_exchange
-- ----------------------------
DROP TABLE IF EXISTS `his_shift_exchange`;
CREATE TABLE `his_shift_exchange` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SHIFT_ID` int(11) NOT NULL,
  `RECEIVER` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `SHIFT_ID` (`SHIFT_ID`),
  KEY `RECEIVER` (`RECEIVER`),
  CONSTRAINT `his_shift_exchange_ibfk_1` FOREIGN KEY (`SHIFT_ID`) REFERENCES `his_shift` (`Id`),
  CONSTRAINT `his_shift_exchange_ibfk_2` FOREIGN KEY (`RECEIVER`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_shift_exchange
-- ----------------------------
INSERT INTO `his_shift_exchange` VALUES ('22', '170', '1030');

-- ----------------------------
-- Table structure for his_stockhouse
-- ----------------------------
DROP TABLE IF EXISTS `his_stockhouse`;
CREATE TABLE `his_stockhouse` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`),
  KEY `FK_his_stockhouse` (`CREATOR`),
  CONSTRAINT `FK_his_stockhouse` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_stockhouse
-- ----------------------------
INSERT INTO `his_stockhouse` VALUES ('44', '昌平仓', '1022', '2018-03-13 15:47:29');
INSERT INTO `his_stockhouse` VALUES ('45', '东城仓', '1022', '2018-03-13 15:47:45');
INSERT INTO `his_stockhouse` VALUES ('46', '朝阳仓', '1022', '2018-03-13 15:47:57');
INSERT INTO `his_stockhouse` VALUES ('47', '丰台仓', '1022', '2018-03-13 15:48:12');

-- ----------------------------
-- Table structure for his_stock_check
-- ----------------------------
DROP TABLE IF EXISTS `his_stock_check`;
CREATE TABLE `his_stock_check` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STOCK_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_STOCKHOUSE，外键字段：ID',
  `CHECK_NO` varchar(10) DEFAULT NULL COMMENT 'YYMMDD+ 4位顺序号',
  `MATERIAL_COUNT` int(11) DEFAULT NULL COMMENT '统计值',
  `PROFIT_LOSS_COUNT` int(11) DEFAULT NULL COMMENT '统计值',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  `AUDITOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `AUDIT_TIME` datetime DEFAULT NULL,
  `AUDIT_OPINION` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_his_stock_check` (`AUDITOR`),
  KEY `FK_his_stock_check_creator` (`CREATOR`),
  KEY `STOCK_ID` (`STOCK_ID`),
  CONSTRAINT `FK_his_stock_check` FOREIGN KEY (`AUDITOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `FK_his_stock_check_creator` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_stock_check_ibfk_1` FOREIGN KEY (`STOCK_ID`) REFERENCES `his_stockhouse` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_stock_check
-- ----------------------------
INSERT INTO `his_stock_check` VALUES ('39', '44', '1803130000', '7', '1', '1022', '2018-03-13 15:59:42', '2018-03-13 16:00:05', null, null, null);
INSERT INTO `his_stock_check` VALUES ('40', '44', '1803130039', '7', '0', '1022', '2018-03-13 16:00:24', null, null, null, null);

-- ----------------------------
-- Table structure for his_stock_check_detail
-- ----------------------------
DROP TABLE IF EXISTS `his_stock_check_detail`;
CREATE TABLE `his_stock_check_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STOCK_CHECK_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_STOCK_CHECK，外键字段：ID',
  `MATERIAL_TYPE` int(11) DEFAULT NULL COMMENT '外键表：DIC_MATERIAL_CATEGORY，外键字段：ID',
  `NAME` varchar(50) DEFAULT NULL,
  `PRICE` decimal(6,1) DEFAULT NULL,
  `SPECIFICATION` varchar(200) DEFAULT NULL,
  `STOCK_QUANTITY` int(11) DEFAULT NULL,
  `REAL_QUANTITY` int(11) DEFAULT NULL,
  `PROFIT_LOSS_QUANTITY` int(11) DEFAULT NULL COMMENT '盈亏数量=库存数量-实际数量',
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_his_stock_check_detail` (`CREATOR`),
  KEY `STOCK_CHECK_ID` (`STOCK_CHECK_ID`),
  KEY `MATERIAL_TYPE` (`MATERIAL_TYPE`),
  CONSTRAINT `FK_his_stock_check_detail` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_stock_check_detail_ibfk_1` FOREIGN KEY (`STOCK_CHECK_ID`) REFERENCES `his_stock_check` (`ID`),
  CONSTRAINT `his_stock_check_detail_ibfk_2` FOREIGN KEY (`MATERIAL_TYPE`) REFERENCES `dic_material_category` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_stock_check_detail
-- ----------------------------
INSERT INTO `his_stock_check_detail` VALUES ('180', '39', '109', '针灸套装', '500.0', '整套', '25', '25', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('181', '39', '111', '全棉拖布', '25.0', '整套', '300', '300', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('182', '39', '110', '扫帚', '15.0', '塑料把扫帚', '400', '400', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('183', '39', '108', '清洁控油洗面奶', '56.0', '瓶', '580', '580', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('184', '39', '107', '全棉毛巾', '10.0', '一条', '900', '898', '-2', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('185', '39', '106', '刷牙杯套装', '35.0', '刷牙杯，牙膏，牙刷', '950', '950', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('186', '39', '105', '牙刷', '10.0', '软毛牙刷', '1000', '1000', '0', '1022', '2018-03-13 15:59:42');
INSERT INTO `his_stock_check_detail` VALUES ('187', '40', '109', '针灸套装', '500.0', '整套', '25', '25', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('188', '40', '111', '全棉拖布', '25.0', '整套', '300', '300', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('189', '40', '110', '扫帚', '15.0', '塑料把扫帚', '400', '400', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('190', '40', '108', '清洁控油洗面奶', '56.0', '瓶', '580', '580', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('191', '40', '107', '全棉毛巾', '10.0', '一条', '900', '900', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('192', '40', '106', '刷牙杯套装', '35.0', '刷牙杯，牙膏，牙刷', '950', '950', '0', '1022', '2018-03-13 16:00:24');
INSERT INTO `his_stock_check_detail` VALUES ('193', '40', '105', '牙刷', '10.0', '软毛牙刷', '1000', '1000', '0', '1022', '2018-03-13 16:00:24');

-- ----------------------------
-- Table structure for his_stock_material
-- ----------------------------
DROP TABLE IF EXISTS `his_stock_material`;
CREATE TABLE `his_stock_material` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STOCK_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_STOCKHOUSE，外键字段：ID',
  `MATERIAL_TYPE` int(11) DEFAULT NULL COMMENT '外键表：DIC_MATERIAL_CATEGORY，外键字段：ID',
  `NAME` varchar(50) DEFAULT NULL,
  `PRICE` decimal(6,1) DEFAULT NULL,
  `SPECIFICATION` varchar(200) DEFAULT NULL,
  `STOCK_QUANTITY` int(11) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_his_stock_material` (`CREATOR`),
  KEY `STOCK_ID` (`STOCK_ID`),
  KEY `MATERIAL_TYPE` (`MATERIAL_TYPE`),
  CONSTRAINT `FK_his_stock_material` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_stock_material_ibfk_1` FOREIGN KEY (`STOCK_ID`) REFERENCES `his_stockhouse` (`ID`),
  CONSTRAINT `his_stock_material_ibfk_2` FOREIGN KEY (`MATERIAL_TYPE`) REFERENCES `dic_material_category` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_stock_material
-- ----------------------------
INSERT INTO `his_stock_material` VALUES ('70', '44', '109', '针灸套装', '500.0', '整套', '25', '1022', '2018-03-13 15:49:28', '2018-03-13 15:58:33');
INSERT INTO `his_stock_material` VALUES ('71', '44', '111', '全棉拖布', '25.0', '整套', '300', '1022', '2018-03-13 15:50:24', null);
INSERT INTO `his_stock_material` VALUES ('72', '44', '110', '扫帚', '15.0', '塑料把扫帚', '400', '1022', '2018-03-13 15:51:38', null);
INSERT INTO `his_stock_material` VALUES ('73', '44', '108', '清洁控油洗面奶', '56.0', '瓶', '580', '1022', '2018-03-13 15:52:28', '2018-03-13 15:58:53');
INSERT INTO `his_stock_material` VALUES ('74', '44', '107', '全棉毛巾', '10.0', '一条', '900', '1022', '2018-03-13 15:53:22', '2018-03-13 15:59:11');
INSERT INTO `his_stock_material` VALUES ('75', '44', '106', '刷牙杯套装', '35.0', '刷牙杯，牙膏，牙刷', '950', '1022', '2018-03-13 15:54:23', '2018-03-13 15:59:25');
INSERT INTO `his_stock_material` VALUES ('76', '44', '105', '牙刷', '10.0', '软毛牙刷', '1000', '1022', '2018-03-13 15:55:12', null);

-- ----------------------------
-- Table structure for his_turn_over_record
-- ----------------------------
DROP TABLE IF EXISTS `his_turn_over_record`;
CREATE TABLE `his_turn_over_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_BED，外键字段：ID',
  `MEMBER_ID` int(11) DEFAULT NULL COMMENT '外键表：HIS_MEMBER，外键字段：ID',
  `IS_TURN_OVER` tinyint(4) DEFAULT '0' COMMENT '翻身-1，未翻身-0',
  `TURN_OVER_TIME` datetime DEFAULT NULL COMMENT '记录翻身时间',
  `FLAG` tinyint(4) DEFAULT '1' COMMENT '记录有效标志，1-有效，0-无效，历史翻身记录两小时后无效',
  `PRINCIPAL` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATOR` int(11) DEFAULT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  KEY `PRINCIPAL` (`PRINCIPAL`),
  CONSTRAINT `his_turn_over_record_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_turn_over_record_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_turn_over_record_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `his_turn_over_record_ibfk_4` FOREIGN KEY (`PRINCIPAL`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=531 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_turn_over_record
-- ----------------------------
INSERT INTO `his_turn_over_record` VALUES ('527', '206', '432', '1', '2018-04-11 17:00:51', '0', '1021', '1021', '2018-03-14 09:00:00', null);
INSERT INTO `his_turn_over_record` VALUES ('528', '207', '433', '0', '2018-03-14 09:00:00', '1', '1021', '1021', '2018-03-14 09:00:00', null);
INSERT INTO `his_turn_over_record` VALUES ('529', '210', '436', '0', '2018-03-14 09:00:00', '1', '1021', '1021', '2018-03-14 09:00:00', null);
INSERT INTO `his_turn_over_record` VALUES ('530', '206', '432', '0', '2018-04-11 19:00:51', '1', '1021', '1021', '2018-04-11 17:00:51', null);

-- ----------------------------
-- Table structure for his_vital_signs
-- ----------------------------
DROP TABLE IF EXISTS `his_vital_signs`;
CREATE TABLE `his_vital_signs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BED_ID` int(11) DEFAULT NULL,
  `MEMBER_ID` int(11) DEFAULT NULL,
  `BODY_POSITION` float(4,1) DEFAULT NULL,
  `PULSE` int(11) DEFAULT NULL,
  `BREATHE` int(11) DEFAULT NULL,
  `BLOOD_PRESSURE_HIGH` int(11) DEFAULT NULL,
  `BLOOD_PRESSURE_LOW` int(11) DEFAULT NULL,
  `BLOOD_SUGAR` float(4,2) DEFAULT NULL,
  `RECORD_TIME` datetime DEFAULT NULL COMMENT '用户选择的录入时间',
  `CREATOR` int(11) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  `BLOOD_SUGAR_PHASE` tinyint(4) DEFAULT NULL COMMENT '早餐前-1，早餐后2，午餐前-3，午餐后-4，晚餐前-5，晚餐后-6',
  PRIMARY KEY (`ID`),
  KEY `BED_ID` (`BED_ID`),
  KEY `MEMBER_ID` (`MEMBER_ID`),
  KEY `CREATOR` (`CREATOR`),
  CONSTRAINT `his_vital_signs_ibfk_1` FOREIGN KEY (`BED_ID`) REFERENCES `his_bed` (`ID`),
  CONSTRAINT `his_vital_signs_ibfk_2` FOREIGN KEY (`MEMBER_ID`) REFERENCES `his_member` (`ID`),
  CONSTRAINT `his_vital_signs_ibfk_3` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of his_vital_signs
-- ----------------------------
INSERT INTO `his_vital_signs` VALUES ('261', '206', '432', '36.7', '74', '24', '134', '87', '0.12', '2017-04-29 14:11:31', '1021', '2018-03-13 14:12:59', null, '1');
INSERT INTO `his_vital_signs` VALUES ('262', '207', '433', '36.0', '77', '26', '133', '88', '1.00', '2018-03-13 15:05:41', '1021', '2018-03-13 15:06:34', null, '1');
INSERT INTO `his_vital_signs` VALUES ('263', '208', '434', '36.6', '88', '32', '134', '78', '2.00', '2018-03-13 15:28:06', '1021', '2018-03-13 15:28:46', null, '4');
INSERT INTO `his_vital_signs` VALUES ('264', '209', '435', '36.6', '78', '34', '141', '79', '1.00', '2018-03-13 15:49:43', '1021', '2018-03-13 15:50:23', null, '4');
INSERT INTO `his_vital_signs` VALUES ('265', '210', '436', '36.6', '79', '25', '141', '78', '1.00', '2017-05-11 16:25:36', '1021', '2018-03-13 16:26:12', null, '6');
INSERT INTO `his_vital_signs` VALUES ('266', '211', '438', '36.0', '88', '32', '133', '88', '1.00', '2018-03-13 17:02:42', '1021', '2018-03-13 17:03:05', null, '6');
INSERT INTO `his_vital_signs` VALUES ('267', '212', '437', '36.6', '77', '26', '133', '78', '1.40', '2018-03-13 17:03:09', '1021', '2018-03-13 17:03:38', null, '7');
INSERT INTO `his_vital_signs` VALUES ('268', '208', '434', '36.4', null, null, null, null, null, '2018-03-13 18:37:54', '1029', '2018-03-13 18:38:02', '2018-03-13 18:38:27', '1');
INSERT INTO `his_vital_signs` VALUES ('269', '207', '433', '1.0', null, null, null, null, null, '2018-04-08 12:02:02', '1021', '2018-04-08 12:02:00', null, '1');

-- ----------------------------
-- Table structure for uums_log
-- ----------------------------
DROP TABLE IF EXISTS `uums_log`;
CREATE TABLE `uums_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录标识，自增',
  `LOG_TYPE` tinyint(4) NOT NULL COMMENT '日志类型',
  `SOURCE` int(1) NOT NULL COMMENT '日志来源',
  `CONTENT` varchar(500) DEFAULT NULL COMMENT '日志内容',
  `LOGIN_IP` varchar(20) DEFAULT NULL COMMENT '登录用户IP',
  `CREATE_USER` int(11) NOT NULL COMMENT '创建用户',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建类型',
  `REMARK` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`ID`),
  KEY `FK_LOG_USER` (`CREATE_USER`),
  KEY `FK_LOG_LOGTYPE` (`LOG_TYPE`),
  CONSTRAINT `FK_LOG_USER` FOREIGN KEY (`CREATE_USER`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_log
-- ----------------------------

-- ----------------------------
-- Table structure for uums_org
-- ----------------------------
DROP TABLE IF EXISTS `uums_org`;
CREATE TABLE `uums_org` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '机构唯一标识，自增',
  `ORG_CODE` varchar(32) NOT NULL DEFAULT '' COMMENT '机构编码',
  `ORG_NAME` varchar(100) NOT NULL DEFAULT '' COMMENT '机构名称',
  `PARENT_ID` int(11) DEFAULT '0' COMMENT '上一级单位ID',
  `IS_LEAF` tinyint(1) DEFAULT '0' COMMENT '是否叶子节点，1.是0.否',
  `FLAG` tinyint(1) DEFAULT '1' COMMENT '机构状态,0.停用1.正常',
  `CREATE_TIME` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `SEQ_NO` int(11) DEFAULT NULL COMMENT '用于主动排序',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_org
-- ----------------------------
INSERT INTO `uums_org` VALUES ('0', 'G', '云颐养', null, '0', '1', '2017-08-08 17:22:42', '0');
INSERT INTO `uums_org` VALUES ('1', 'Y', '昌平区养老院', '0', '0', '1', '2017-05-04 18:32:38', '0');
INSERT INTO `uums_org` VALUES ('2', 'S', '西城区养老院', '0', '0', '1', '2017-05-04 18:32:44', '0');
INSERT INTO `uums_org` VALUES ('71', '62d08ee31277497d81dbd5a2589ae232', '丰台区养老照料中心', '0', '0', '1', '2017-08-08 17:24:06', '0');
INSERT INTO `uums_org` VALUES ('125', 'a6096eed36f7443099df89a61d8a290e', '财务部', '1', '1', '1', '2017-12-28 10:44:00', '0');
INSERT INTO `uums_org` VALUES ('126', '1e80bb8aa5cf47b9b00b88b027ba283f', '护理部', '1', '1', '1', '2017-12-28 10:44:08', '0');

-- ----------------------------
-- Table structure for uums_org_res
-- ----------------------------
DROP TABLE IF EXISTS `uums_org_res`;
CREATE TABLE `uums_org_res` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORG_ID` int(11) DEFAULT NULL COMMENT '外键表：UUMS_ORG，外键字段：ID',
  `RES_ID` int(11) DEFAULT NULL COMMENT '外键表：UUMS_RES，外键字段：ID',
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  KEY `RES_ID` (`RES_ID`),
  CONSTRAINT `uums_org_res_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`),
  CONSTRAINT `uums_org_res_ibfk_2` FOREIGN KEY (`RES_ID`) REFERENCES `uums_res` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2645 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_org_res
-- ----------------------------
INSERT INTO `uums_org_res` VALUES ('152', '71', '298');
INSERT INTO `uums_org_res` VALUES ('153', '71', '207');
INSERT INTO `uums_org_res` VALUES ('154', '71', '254');
INSERT INTO `uums_org_res` VALUES ('155', '71', '299');
INSERT INTO `uums_org_res` VALUES ('156', '71', '275');
INSERT INTO `uums_org_res` VALUES ('157', '71', '206');
INSERT INTO `uums_org_res` VALUES ('158', '71', '272');
INSERT INTO `uums_org_res` VALUES ('159', '71', '265');
INSERT INTO `uums_org_res` VALUES ('160', '71', '293');
INSERT INTO `uums_org_res` VALUES ('161', '71', '436');
INSERT INTO `uums_org_res` VALUES ('162', '71', '440');
INSERT INTO `uums_org_res` VALUES ('163', '71', '203');
INSERT INTO `uums_org_res` VALUES ('164', '71', '204');
INSERT INTO `uums_org_res` VALUES ('165', '71', '284');
INSERT INTO `uums_org_res` VALUES ('166', '71', '435');
INSERT INTO `uums_org_res` VALUES ('167', '71', '434');
INSERT INTO `uums_org_res` VALUES ('168', '71', '257');
INSERT INTO `uums_org_res` VALUES ('169', '71', '270');
INSERT INTO `uums_org_res` VALUES ('170', '71', '274');
INSERT INTO `uums_org_res` VALUES ('171', '71', '437');
INSERT INTO `uums_org_res` VALUES ('172', '71', '283');
INSERT INTO `uums_org_res` VALUES ('173', '71', '281');
INSERT INTO `uums_org_res` VALUES ('174', '71', '438');
INSERT INTO `uums_org_res` VALUES ('175', '71', '304');
INSERT INTO `uums_org_res` VALUES ('176', '71', '261');
INSERT INTO `uums_org_res` VALUES ('177', '71', '264');
INSERT INTO `uums_org_res` VALUES ('178', '71', '439');
INSERT INTO `uums_org_res` VALUES ('179', '71', '205');
INSERT INTO `uums_org_res` VALUES ('180', '71', '282');
INSERT INTO `uums_org_res` VALUES ('181', '71', '441');
INSERT INTO `uums_org_res` VALUES ('182', '71', '279');
INSERT INTO `uums_org_res` VALUES ('2593', '0', '288');
INSERT INTO `uums_org_res` VALUES ('2594', '0', '579');
INSERT INTO `uums_org_res` VALUES ('2595', '0', '362');
INSERT INTO `uums_org_res` VALUES ('2596', '0', '441');
INSERT INTO `uums_org_res` VALUES ('2597', '0', '83');
INSERT INTO `uums_org_res` VALUES ('2598', '0', '215');
INSERT INTO `uums_org_res` VALUES ('2599', '0', '435');
INSERT INTO `uums_org_res` VALUES ('2600', '0', '192');
INSERT INTO `uums_org_res` VALUES ('2601', '0', '367');
INSERT INTO `uums_org_res` VALUES ('2602', '0', '369');
INSERT INTO `uums_org_res` VALUES ('2603', '0', '438');
INSERT INTO `uums_org_res` VALUES ('2604', '0', '366');
INSERT INTO `uums_org_res` VALUES ('2605', '0', '293');
INSERT INTO `uums_org_res` VALUES ('2606', '0', '360');
INSERT INTO `uums_org_res` VALUES ('2607', '0', '229');
INSERT INTO `uums_org_res` VALUES ('2608', '0', '296');
INSERT INTO `uums_org_res` VALUES ('2609', '0', '405');
INSERT INTO `uums_org_res` VALUES ('2610', '0', '304');
INSERT INTO `uums_org_res` VALUES ('2611', '0', '208');
INSERT INTO `uums_org_res` VALUES ('2612', '0', '492');
INSERT INTO `uums_org_res` VALUES ('2613', '0', '210');
INSERT INTO `uums_org_res` VALUES ('2614', '0', '402');
INSERT INTO `uums_org_res` VALUES ('2615', '0', '361');
INSERT INTO `uums_org_res` VALUES ('2616', '0', '368');
INSERT INTO `uums_org_res` VALUES ('2617', '0', '437');
INSERT INTO `uums_org_res` VALUES ('2618', '0', '205');
INSERT INTO `uums_org_res` VALUES ('2619', '0', '440');
INSERT INTO `uums_org_res` VALUES ('2620', '0', '294');
INSERT INTO `uums_org_res` VALUES ('2621', '0', '203');
INSERT INTO `uums_org_res` VALUES ('2622', '0', '580');
INSERT INTO `uums_org_res` VALUES ('2623', '0', '292');
INSERT INTO `uums_org_res` VALUES ('2624', '0', '406');
INSERT INTO `uums_org_res` VALUES ('2625', '0', '506');
INSERT INTO `uums_org_res` VALUES ('2626', '0', '475');
INSERT INTO `uums_org_res` VALUES ('2627', '0', '439');
INSERT INTO `uums_org_res` VALUES ('2628', '0', '365');
INSERT INTO `uums_org_res` VALUES ('2629', '0', '434');
INSERT INTO `uums_org_res` VALUES ('2630', '0', '442');
INSERT INTO `uums_org_res` VALUES ('2631', '0', '407');
INSERT INTO `uums_org_res` VALUES ('2632', '0', '363');
INSERT INTO `uums_org_res` VALUES ('2633', '0', '408');
INSERT INTO `uums_org_res` VALUES ('2634', '0', '298');
INSERT INTO `uums_org_res` VALUES ('2635', '0', '364');
INSERT INTO `uums_org_res` VALUES ('2636', '0', '436');
INSERT INTO `uums_org_res` VALUES ('2637', '0', '299');
INSERT INTO `uums_org_res` VALUES ('2638', '0', '297');
INSERT INTO `uums_org_res` VALUES ('2639', '0', '359');
INSERT INTO `uums_org_res` VALUES ('2640', '0', '204');
INSERT INTO `uums_org_res` VALUES ('2641', '0', '417');
INSERT INTO `uums_org_res` VALUES ('2642', '0', '413');
INSERT INTO `uums_org_res` VALUES ('2643', '0', '542');
INSERT INTO `uums_org_res` VALUES ('2644', '0', '295');

-- ----------------------------
-- Table structure for uums_org_role
-- ----------------------------
DROP TABLE IF EXISTS `uums_org_role`;
CREATE TABLE `uums_org_role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORG_ID` int(11) DEFAULT NULL,
  `ROLE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ORG_ID` (`ORG_ID`),
  KEY `ROLE_ID` (`ROLE_ID`),
  CONSTRAINT `uums_org_role_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`),
  CONSTRAINT `uums_org_role_ibfk_2` FOREIGN KEY (`ROLE_ID`) REFERENCES `uums_role` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_org_role
-- ----------------------------
INSERT INTO `uums_org_role` VALUES ('1', '0', '42');
INSERT INTO `uums_org_role` VALUES ('2', '0', '53');
INSERT INTO `uums_org_role` VALUES ('3', '0', '54');
INSERT INTO `uums_org_role` VALUES ('4', '0', '55');
INSERT INTO `uums_org_role` VALUES ('5', '0', '56');
INSERT INTO `uums_org_role` VALUES ('6', '0', '57');
INSERT INTO `uums_org_role` VALUES ('7', '0', '58');
INSERT INTO `uums_org_role` VALUES ('8', '0', '59');
INSERT INTO `uums_org_role` VALUES ('9', '0', '60');
INSERT INTO `uums_org_role` VALUES ('17', '0', '99');

-- ----------------------------
-- Table structure for uums_res
-- ----------------------------
DROP TABLE IF EXISTS `uums_res`;
CREATE TABLE `uums_res` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '资源唯一标识，自增',
  `IS_MENU` tinyint(4) DEFAULT '1' COMMENT '是否系统菜单，1-是，0-不是，默认1',
  `PARENT_ID` int(11) DEFAULT NULL COMMENT '父级资源标识',
  `RES_CODE` varchar(100) NOT NULL COMMENT '资源代码:资源全局唯一标识',
  `RES_NAME` varchar(50) NOT NULL DEFAULT '' COMMENT '资源名称',
  `RES_URL` varchar(100) DEFAULT NULL COMMENT '资源地址',
  `FLAG` int(1) NOT NULL DEFAULT '1' COMMENT '资源状态：资源当前状态：1-正常，0-停用，默认1',
  `SEQ_NO` int(11) DEFAULT '0' COMMENT '顺序号',
  `RES_ICON` varchar(100) DEFAULT NULL,
  `CREATE_TIME` datetime NOT NULL COMMENT '创建日期',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=581 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_res
-- ----------------------------
INSERT INTO `uums_res` VALUES ('81', '1', '83', 'ORG', '组织机构管理', '/org/orgList', '1', '0', 'iconfont icon-zuzhijigou', '2017-06-23 18:51:13');
INSERT INTO `uums_res` VALUES ('83', '1', null, 'MANAGE', '系统管理', '#', '1', '100', 'iconfont icon-peizhi', '2017-06-23 18:51:25');
INSERT INTO `uums_res` VALUES ('84', '1', '83', 'role', '角色管理', '/role/listPage', '1', '6', 'iconfont icon-role', '2017-06-23 18:51:46');
INSERT INTO `uums_res` VALUES ('85', '1', '83', 'RESOURCE', '资源管理', '/res/listPage', '1', '2', 'iconfont icon-ziyuanguanli', '2017-06-23 18:52:02');
INSERT INTO `uums_res` VALUES ('100', '1', '83', 'USER', '用户管理', '/user/userListUI', '1', '4', '', '2017-06-23 18:58:12');
INSERT INTO `uums_res` VALUES ('119', '0', '100', 'USER_VIEW', '查看用户信息', '/findAllById', '1', '0', '', '2017-06-28 19:07:25');
INSERT INTO `uums_res` VALUES ('120', '0', '100', 'USER_EDIT', '编辑用户', '/user/findUserById', '1', '0', '', '2017-06-28 19:13:23');
INSERT INTO `uums_res` VALUES ('121', '0', '100', 'USER_GRANT_ROLE', '分配角色', '/toAdd', '1', '0', '', '2017-06-28 19:15:00');
INSERT INTO `uums_res` VALUES ('122', '0', '100', 'USER_LOGOUT', '注销用户', '/user/deleteUser', '1', '0', '', '2017-06-28 19:17:14');
INSERT INTO `uums_res` VALUES ('123', '0', '100', 'USER_ADD', '新增用户', '/user/toAddUser', '1', '0', '', '2017-06-28 19:19:45');
INSERT INTO `uums_res` VALUES ('190', '1', '402', 'MODIFY_PWD', '修改密码', '/user/toSetPwd', '1', '3', '', '2017-07-07 15:20:52');
INSERT INTO `uums_res` VALUES ('192', '1', null, 'app', 'APP', '#', '1', '99', 'iconfont icon-app', '2017-07-12 10:17:13');
INSERT INTO `uums_res` VALUES ('193', '1', '402', 'DATA_STATS', '数据统计', '/count/toList', '1', '0', 'iconfont icon-tongji', '2017-07-12 10:39:23');
INSERT INTO `uums_res` VALUES ('195', '1', '192', 'vitalSigns', '生命体征记录表', '/app/views/nursingManage/vitalSigns/muiList.html', '1', '2', '', '2017-07-12 14:44:58');
INSERT INTO `uums_res` VALUES ('196', '1', '192', 'lifeCare', '日常照料记录表', '/app/views/nursingManage/lifeCare/muiList.html', '1', '3', '', '2017-07-12 14:46:30');
INSERT INTO `uums_res` VALUES ('197', '1', '192', 'nursingRecord', '护理记录APP', '/app/views/nursingManage/nursingRecord/listMove.html', '1', '4', '', '2017-07-12 14:56:49');
INSERT INTO `uums_res` VALUES ('198', '1', '192', 'turnOverRecord', '翻身记录表', '/app/views/nursingManage/turnOverRecord/listMove.html', '1', '5', '', '2017-07-12 14:58:02');
INSERT INTO `uums_res` VALUES ('199', '1', '192', 'dailylog', '日常交班表', '/app/views/nursingManage/dailylog/listMove.html', '1', '6', '', '2017-07-12 14:59:26');
INSERT INTO `uums_res` VALUES ('200', '1', '192', 'app/nurselog', '护理交班簿', '/app/views/nursingManage/nurselog/listMove.html', '1', '7', '', '2017-07-12 15:13:09');
INSERT INTO `uums_res` VALUES ('201', '1', '192', 'app/evaluate', '评估', '/app/views/evaluate/brains/index.html', '1', '1', '', '2017-07-12 15:26:30');
INSERT INTO `uums_res` VALUES ('203', '1', null, 'MEMBER', '档案管理', '#', '1', '2', 'iconfont icon-dangan-copy', '2017-07-12 17:59:48');
INSERT INTO `uums_res` VALUES ('204', '1', '203', 'MEMBER_LIST', '客户档案', '/member/list.action', '1', '0', '', '2017-07-12 18:05:16');
INSERT INTO `uums_res` VALUES ('205', '1', null, 'consult', '接待管理', '#', '1', '3', 'iconfont icon-jiedai', '2017-07-12 18:06:18');
INSERT INTO `uums_res` VALUES ('206', '1', '205', 'CONSULT', '咨询回访', '/consult/toList', '1', '1', '', '2017-07-12 18:08:38');
INSERT INTO `uums_res` VALUES ('207', '1', '205', 'RESERVE', '储备客户', '/reserve/reserveList', '1', '2', '', '2017-07-12 18:13:41');
INSERT INTO `uums_res` VALUES ('208', '1', '407', 'EVA_RECORD', '评估记录', '/composite/indexList', '1', '1', '', '2017-07-12 18:15:24');
INSERT INTO `uums_res` VALUES ('210', '1', null, 'CHECKUP', '体检管理', '#', '1', '5', 'iconfont icon-tijian', '2017-07-12 18:20:46');
INSERT INTO `uums_res` VALUES ('212', '1', '413', 'dutyArea_index_toList', '责任区域管理', '/dutyArea/toList', '1', '0', 'iconfont icon-area', '2017-07-12 18:27:35');
INSERT INTO `uums_res` VALUES ('213', '1', '413', 'employe_index_toList', '员工列表', '/employe/toList', '1', '0', 'iconfont icon-yuangong', '2017-07-12 18:22:22');
INSERT INTO `uums_res` VALUES ('214', '1', '413', 'EMPLOYE_DUTY_AREA', '员工责任区', '/empDutyArea/toList', '1', '0', '', '2017-07-12 18:28:44');
INSERT INTO `uums_res` VALUES ('215', '1', null, 'NURSE', '护理管理', '#', '1', '7', 'iconfont icon-huli', '2017-07-12 18:30:04');
INSERT INTO `uums_res` VALUES ('217', '1', '215', 'SHIFT_RECORD', '交班记录', '/nurse/toNurseList', '1', '1', '', '2017-07-12 18:33:20');
INSERT INTO `uums_res` VALUES ('219', '1', '215', 'NURSING_RECORD', '护理记录表', '/nursingRecord/toList', '1', '2', '', '2017-07-12 18:34:17');
INSERT INTO `uums_res` VALUES ('220', '1', '215', 'TURN_OVER_RECORD', '翻身记录表', '/turnOverRecord/toList', '1', '3', '', '2017-07-12 18:35:07');
INSERT INTO `uums_res` VALUES ('221', '1', '215', 'LIFE_CARE_RECORD', '日常生活照料表', '/lifeCare/toList', '1', '4', '', '2017-07-12 18:35:54');
INSERT INTO `uums_res` VALUES ('222', '1', '413', 'SCHEDULE', '班次管理', '/schedule/toList', '1', '0', '', '2017-07-12 18:31:03');
INSERT INTO `uums_res` VALUES ('223', '1', '215', 'vitalSigns_index_toList', '生命体征记录表', '/vitalSigns/toList', '1', '0', '', '2017-07-12 18:36:38');
INSERT INTO `uums_res` VALUES ('224', '1', '413', 'SCHEDULE_RECORD', '排班管理', '/scheduleDetail/toList', '1', '0', '', '2017-07-12 18:32:52');
INSERT INTO `uums_res` VALUES ('225', '1', '406', 'CHARGE_CHECKIN', '入住缴费', '/chargeNew/toList', '1', '3', '', '2017-07-12 18:38:32');
INSERT INTO `uums_res` VALUES ('227', '1', '215', 'MEDICATION_RECORD', '用药管理', '/pharmacy/pharmacyList', '1', '6', 'iconfont icon-yongyao', '2017-07-12 18:34:54');
INSERT INTO `uums_res` VALUES ('229', '1', null, 'NOTICE', '通知管理', '#', '1', '9', 'iconfont icon-tubiaozhizuomoban', '2017-07-12 18:36:05');
INSERT INTO `uums_res` VALUES ('230', '1', '442', 'BED_LIST', '床位列表', '/bed/toBedList', '1', '0', '', '2017-07-12 18:41:34');
INSERT INTO `uums_res` VALUES ('232', '1', '229', 'NOTICE_LIST', '通知列表', '/notice/toList', '1', '1', '', '2017-07-12 18:37:35');
INSERT INTO `uums_res` VALUES ('233', '1', '406', 'CHARGE_ITEM', '费用管理', '/cost/toList', '1', '0', '', '2017-07-12 18:43:53');
INSERT INTO `uums_res` VALUES ('234', '0', '302', 'NOTICE_ADD', '新建通知', '/notice/toEdit.action', '1', '1', '', '2017-07-12 18:39:09');
INSERT INTO `uums_res` VALUES ('235', '1', '406', 'CHARGE_SUNDRY', '杂费管理', '/incidental/toList', '1', '0', '', '2017-07-12 18:44:55');
INSERT INTO `uums_res` VALUES ('237', '1', '417', 'DOC_LIST', '文档列表', '/document/toList', '1', '0', 'iconfont icon-wendang', '2017-07-12 18:40:40');
INSERT INTO `uums_res` VALUES ('238', '1', '83', 'DIC', '字典管理', '/dictCheck/toList', '1', '5', '', '2017-07-12 18:46:38');
INSERT INTO `uums_res` VALUES ('241', '0', '219', 'NURSING_ADD', '新建护理记录', '/nursingRecord/toEdit.action', '1', '1', '', '2017-07-13 11:08:50');
INSERT INTO `uums_res` VALUES ('242', '0', '219', 'NURSING_VIEW', '查看护理记录', '/nursingRecord/toEdit.action', '1', '2', '', '2017-07-13 11:11:00');
INSERT INTO `uums_res` VALUES ('243', '0', '219', 'NURSING_EDIT', '编辑护理记录', '/nursingRecord/toEdit.action', '1', '3', '', '2017-07-13 11:11:52');
INSERT INTO `uums_res` VALUES ('244', '0', '219', 'NURSING_DEL', '删除护理记录', '/nursingRecord/delete.action', '1', '4', '', '2017-07-13 11:12:50');
INSERT INTO `uums_res` VALUES ('249', '0', '220', 'TURN_OVER_ADD', '新增翻身记录', '/turnOverRecord/toEdit.action', '1', '1', '', '2017-07-13 11:52:57');
INSERT INTO `uums_res` VALUES ('250', '0', '220', 'TURN_OVER_VIEW', '查看翻身记录', '/turnOverRecord/toEdit.action', '1', '2', '', '2017-07-13 12:08:55');
INSERT INTO `uums_res` VALUES ('251', '0', '220', 'TURN_OVER_EDIT', '编辑翻身记录', '/turnOverRecord/toEdit.action', '1', '3', '', '2017-07-13 12:10:15');
INSERT INTO `uums_res` VALUES ('252', '0', '220', 'TURN_OVER_DEL', '删除翻身记录', '/turnOverRecord/delete.action', '1', '4', '', '2017-07-13 12:11:29');
INSERT INTO `uums_res` VALUES ('254', '0', '206', 'CONSULT_LIST', '咨询列表', '/consult/toConsultList', '1', '1', '', '2017-07-13 14:01:41');
INSERT INTO `uums_res` VALUES ('257', '0', '206', 'CALLBACK_LIST', '回访列表', '/callback/callBackList', '1', '2', '', '2017-07-13 14:06:48');
INSERT INTO `uums_res` VALUES ('258', '0', '223', 'VITAL_SIGNS_ADD', '新建生命体征记录', '/vitalSigns/toEdit.action', '1', '1', '', '2017-07-13 14:26:15');
INSERT INTO `uums_res` VALUES ('261', '0', '257', 'CALLBACK_VIEW', '查看回访信息', '/callback/goInfo', '1', '1', '', '2017-07-13 14:29:38');
INSERT INTO `uums_res` VALUES ('264', '0', '257', 'CALLBACK_DEL', '删除回访', '/callback/delCallBack', '1', '2', '', '2017-07-13 14:37:41');
INSERT INTO `uums_res` VALUES ('265', '0', '254', 'CONSULT_ADD', '新增咨询', '/consult/add', '1', '1', '', '2017-07-13 14:40:58');
INSERT INTO `uums_res` VALUES ('266', '0', '223', 'VITAL_SIGNS_VIEW', '查看生命体征记录', '/vitalSigns/toEdit.action', '1', '2', '', '2017-07-13 14:47:27');
INSERT INTO `uums_res` VALUES ('268', '0', '223', 'VITAL_SIGNS_EDIT', '编辑生命体征记录', '/vitalSigns/toEdit.action', '1', '3', '', '2017-07-13 14:49:07');
INSERT INTO `uums_res` VALUES ('269', '0', '223', 'VITAL_SIGNS_DEL', '删除生命体征记录', '/vitalSigns/delete.action', '1', '4', '', '2017-07-13 14:50:11');
INSERT INTO `uums_res` VALUES ('270', '0', '254', 'CONSULT_VIEW', '查看咨询信息', '/consult/consultInfo', '1', '2', '', '2017-07-13 14:45:03');
INSERT INTO `uums_res` VALUES ('272', '0', '254', 'CONSULT_EDIT', '编辑咨询', '/consult/goUpdate', '1', '3', '', '2017-07-13 14:46:45');
INSERT INTO `uums_res` VALUES ('274', '0', '254', 'CONSULT_CALLBACK', '咨询回访', '/callback/goAdd', '1', '5', '', '2017-07-13 14:47:29');
INSERT INTO `uums_res` VALUES ('275', '0', '254', 'CONSULT_DEL', '删除咨询', '/consult/delConsult', '1', '4', '', '2017-07-13 14:48:25');
INSERT INTO `uums_res` VALUES ('277', '0', '221', 'LIFE_CARE_ADD', '新建日常生活照料记录', '/lifeCare/toEdit.action', '1', '1', '', '2017-07-13 15:52:11');
INSERT INTO `uums_res` VALUES ('279', '0', '207', 'RESERVE_CHECKIN', '入住申请', '/reserve/toAddMember', '1', '1', '', '2017-07-13 15:56:21');
INSERT INTO `uums_res` VALUES ('280', '0', '221', 'LIFE_CARE_VIEW', '查看日常生活照料记录', '/lifeCare/toEdit.action', '1', '2', '', '2017-07-13 16:05:58');
INSERT INTO `uums_res` VALUES ('281', '0', '207', 'RESERVE_VIEW', '查看客户信息', '/reserve/reserveDetails', '1', '2', '', '2017-07-13 16:00:45');
INSERT INTO `uums_res` VALUES ('282', '0', '207', 'RESERVE_EDIT', '编辑客户', '/reserve/updateView', '1', '3', '', '2017-07-13 16:01:53');
INSERT INTO `uums_res` VALUES ('283', '0', '207', 'RESERVE_CALLBACK', '客户回访', '/callback/goAdd', '1', '4', '', '2017-07-13 16:04:07');
INSERT INTO `uums_res` VALUES ('284', '0', '207', 'RESERVE_DEL', '删除客户', '/reserve/delete', '1', '5', '', '2017-07-13 16:05:40');
INSERT INTO `uums_res` VALUES ('285', '0', '221', 'LIFE_CARE_EDIT', '编辑日常生活照料记录', '/lifeCare/toEdit.action', '1', '3', '', '2017-07-13 16:13:51');
INSERT INTO `uums_res` VALUES ('286', '0', '221', 'LIFE_CARE_DEL', '删除日常生活照料记录', '/lifeCare/delete.action', '1', '4', '', '2017-07-13 16:14:43');
INSERT INTO `uums_res` VALUES ('288', '1', '210', 'CHECKUP_RECORD', '体检记录', '/checkUp/checkUpList', '1', '1', '', '2017-07-13 16:13:30');
INSERT INTO `uums_res` VALUES ('292', '0', '288', 'CHECKUP_ADD', '新增体检记录', '/checkUp/toAddCheckUp', '1', '1', '', '2017-07-13 16:19:43');
INSERT INTO `uums_res` VALUES ('293', '0', '204', 'MEMBER_RECORD', '档案信息', '/member/findAllById.action', '1', '0', '', '2017-07-13 16:31:33');
INSERT INTO `uums_res` VALUES ('294', '0', '288', 'CHECKUP_AUDIT', '体检记录审批', '/checkUp/pass', '1', '2', '', '2017-07-13 16:27:53');
INSERT INTO `uums_res` VALUES ('295', '0', '288', 'CHECKUP_VIEW', '查看体检信息', '/checkUp/checkUpDetails', '1', '3', '', '2017-07-13 16:34:31');
INSERT INTO `uums_res` VALUES ('296', '0', '288', 'CHECKUP_EDIT', '编辑体检记录', '/checkUp/updateView', '1', '4', '', '2017-07-13 16:37:23');
INSERT INTO `uums_res` VALUES ('297', '0', '288', 'CHECKUP_DEL', '删除体检记录', '/checkUp/delete', '1', '5', '', '2017-07-13 16:38:19');
INSERT INTO `uums_res` VALUES ('298', '0', '204', 'MEMBER_EDIT', '档案编辑', '/member/findById.action', '1', '0', '', '2017-07-13 16:45:27');
INSERT INTO `uums_res` VALUES ('299', '0', '204', 'MEMBER_LOGOUT', '注销档案', '/member/delete.action', '1', '0', '', '2017-07-13 16:46:21');
INSERT INTO `uums_res` VALUES ('301', '0', '217', 'SHIFT_LIST', '日常交班表', '/nurse/toDailyLogList', '1', '1', '', '2017-07-13 16:47:44');
INSERT INTO `uums_res` VALUES ('302', '0', '232', 'NOTICE_MINE', '我发出的通知', '/notice/freshList.action', '1', '2', '', '2017-07-13 16:54:32');
INSERT INTO `uums_res` VALUES ('303', '0', '217', 'SHIFT_BOOK_LIST', '护理交班薄', '/nurse/toNurseLogList', '1', '2', '', '2017-07-13 16:49:17');
INSERT INTO `uums_res` VALUES ('304', '0', '204', 'MEMBER_ADD', '档案登记', '/member/toAdd.action', '1', '0', '', '2017-07-13 16:54:46');
INSERT INTO `uums_res` VALUES ('305', '0', '232', 'NOTICE_RECEIVED', '我收到的通知', '/notice/freshList.action', '1', '1', '', '2017-07-13 16:57:04');
INSERT INTO `uums_res` VALUES ('307', '0', '301', 'SHIFT_ADD', '新建交班表', '/nurse/createDailyLog', '1', '1', '', '2017-07-13 17:00:51');
INSERT INTO `uums_res` VALUES ('308', '0', '301', 'SHIFT_VIEW', '查看交班表', 'dailyLog/detailDailyLog', '1', '2', '', '2017-07-13 17:15:34');
INSERT INTO `uums_res` VALUES ('310', '0', '301', 'SHIFT_EDIT', '编辑交班表', 'dailyLog/updateDailyLog', '1', '3', '', '2017-07-13 17:18:05');
INSERT INTO `uums_res` VALUES ('311', '0', '301', 'SHIFT_DEL', '删除交班表', '/nurse/delDailyLog', '1', '4', '', '2017-07-13 17:18:56');
INSERT INTO `uums_res` VALUES ('312', '0', '302', 'NOTICE_EDIT', '编辑通知', '/notice/toEdit.action', '1', '3', '', '2017-07-13 17:24:32');
INSERT INTO `uums_res` VALUES ('313', '0', '212', 'DUTY_AREA_EDIT', '编辑区域', '/dutyArea/toUpdate', '1', '0', '', '2017-07-13 17:25:37');
INSERT INTO `uums_res` VALUES ('314', '0', '302', 'NOTICE_DEL', '删除通知', '/notice/delete.action', '1', '4', '', '2017-07-13 17:26:08');
INSERT INTO `uums_res` VALUES ('315', '0', '212', 'DUTY_AREA_DEL', '删除区域', '/dutyArea/del.action', '1', '0', '', '2017-07-13 17:30:53');
INSERT INTO `uums_res` VALUES ('316', '0', '212', 'DUTY_AREA_ADD', '新增区域', '/dutyArea/toAdd', '1', '0', '', '2017-07-13 17:34:52');
INSERT INTO `uums_res` VALUES ('318', '0', '302', 'NOTICE_SEND', '发送通知', '/notice/send.action', '1', '5', '', '2017-07-13 17:37:02');
INSERT INTO `uums_res` VALUES ('319', '0', '303', 'SHIFT_BOOK_ADD', '新建交班簿', '/nurse/toAddNurseLog', '1', '1', '', '2017-07-13 17:31:35');
INSERT INTO `uums_res` VALUES ('320', '0', '214', 'EMPLOYE_DUTY_AREA_VIEW', '查看员工责任区', '/empDutyArea/details', '1', '0', '', '2017-07-13 17:38:26');
INSERT INTO `uums_res` VALUES ('321', '0', '214', 'EMPLOYE_DUTY_AREA_EDIT', '编辑员工责任区', '/empDutyArea/toUpdate', '1', '0', '', '2017-07-13 17:44:22');
INSERT INTO `uums_res` VALUES ('322', '0', '302', 'NOTICE_VIEW', '查看通知', '/notice/toEdit.action', '1', '2', '', '2017-07-13 17:44:37');
INSERT INTO `uums_res` VALUES ('323', '0', '214', 'EMPLOYE_DUTY_AREA_DEL', '删除员工责任区', '/empDutyArea/del', '1', '0', '', '2017-07-13 17:47:43');
INSERT INTO `uums_res` VALUES ('324', '0', '303', 'SHIFT_BOOK_VIEW', '查看交班簿', '/nurse/toDetailNurseLog', '1', '2', '', '2017-07-13 17:43:49');
INSERT INTO `uums_res` VALUES ('325', '0', '303', 'SHIFT_BOOK_EDIT', '编辑交班簿', '/nurse/toUpdateNurseLog', '1', '3', '', '2017-07-13 17:45:10');
INSERT INTO `uums_res` VALUES ('326', '0', '303', 'SHIFT_BOOK_DEL', '删除交班簿', '/nurse/delNurseLog', '1', '4', '', '2017-07-13 17:46:20');
INSERT INTO `uums_res` VALUES ('327', '0', '305', 'NOTICE_RECEIVED_VIEW', '查看收到的通知', '/notice/toEdit.action', '1', '1', '', '2017-07-13 17:52:28');
INSERT INTO `uums_res` VALUES ('330', '0', '227', 'MEDICATION_NOTIFICATION', '用药告知单', '/pharmacy/notifyList', '1', '1', '', '2017-07-13 18:02:36');
INSERT INTO `uums_res` VALUES ('331', '0', '227', 'MEDICATION_CHECK', '对药单', '/pharmacy/checkList', '1', '2', '', '2017-07-13 18:04:36');
INSERT INTO `uums_res` VALUES ('332', '0', '227', 'MEDICATION_MISTAKE_OMISSION', '错漏摆记录', '/pharmacy/errorsRecordList', '1', '3', '', '2017-07-13 18:05:39');
INSERT INTO `uums_res` VALUES ('335', '0', '225', 'CHARGE_CHECKIN_ADD', '入住收款', '/charge/toPayNormal.action', '1', '3', '', '2017-07-13 18:22:32');
INSERT INTO `uums_res` VALUES ('338', '0', '330', 'MEDICATION_NOTIFICATION_ADD', '新建用药告知单', '/pharmacy/toAddPharmacy', '1', '1', '', '2017-07-13 18:18:34');
INSERT INTO `uums_res` VALUES ('339', '0', '225', 'CHARGE_CHECKOUT', '退住', '/charge/toCheckOut.action', '1', '4', '', '2017-07-13 18:25:40');
INSERT INTO `uums_res` VALUES ('340', '0', '330', 'MEDICATION_NOTIFICATION_VIEW', '查看用药告知单', '/pharmacy/toUpdatePharmacy', '1', '2', '', '2017-07-13 18:23:02');
INSERT INTO `uums_res` VALUES ('342', '0', '330', 'MEDICATION_NOTIFICATION_EDIT', '编辑用药告知单', '/pharmacy/toUpdatePharmacy', '1', '3', '', '2017-07-13 18:24:29');
INSERT INTO `uums_res` VALUES ('343', '0', '330', 'MEDICATION_NOTIFICATION_DEL', '删除用药告知单', '/pharmacy/deleteNotify', '1', '4', '', '2017-07-13 18:27:08');
INSERT INTO `uums_res` VALUES ('345', '0', '331', 'MEDICATION_CHECK_ADD', '新建对药单', '/pharmacy/toAddCheck', '1', '1', '', '2017-07-13 18:39:41');
INSERT INTO `uums_res` VALUES ('346', '0', '331', 'MEDICATION_CHECK_VIEW', '查看对药单', '/pharmacy/findCheckDetailList', '1', '2', '', '2017-07-13 18:45:02');
INSERT INTO `uums_res` VALUES ('347', '0', '331', 'MEDICATION_CHECK_EDIT', '编辑对药单', '/pharmacy/findCheckDetailList', '1', '3', '', '2017-07-13 18:45:57');
INSERT INTO `uums_res` VALUES ('348', '0', '331', 'MEDICATION_CHECK_DEL', '删除对药单', '/pharmacy/deleteCheck', '1', '4', '', '2017-07-13 18:46:43');
INSERT INTO `uums_res` VALUES ('350', '0', '547', 'MEDICATION_MISTAKE_OMISSION_ADD', '新建错漏摆记录', '/pharmacy/toAddErrorsRecord', '1', '1', '', '2017-07-13 18:57:32');
INSERT INTO `uums_res` VALUES ('351', '0', '547', 'MEDICATION_MISTAKE_OMISSION_VIEW', '查看错漏摆记录', '/pharmacy/errorsRecordDetail', '1', '2', '', '2017-07-13 18:58:44');
INSERT INTO `uums_res` VALUES ('352', '0', '547', 'MEDICATION_MISTAKE_OMISSION_EDIT', '编辑错漏摆记录', '/pharmacy/errorsRecordUpdate', '1', '3', '', '2017-07-13 19:03:58');
INSERT INTO `uums_res` VALUES ('354', '0', '213', 'EMPLOYE_VIEW', '查看员工信息', '/employe/details', '1', '0', '', '2017-07-13 19:42:05');
INSERT INTO `uums_res` VALUES ('355', '0', '213', 'EMPLOYE_EDIT', '编辑员工', '/employe/toUpdate', '1', '0', '', '2017-07-13 19:43:01');
INSERT INTO `uums_res` VALUES ('356', '0', '213', 'EMPLOYE_DEL', '删除员工', '/employe/del', '1', '0', '', '2017-07-13 19:43:35');
INSERT INTO `uums_res` VALUES ('357', '0', '213', 'EMPLOYE_ADD', '新增员工', '/employe/toAdd', '1', '0', '', '2017-07-13 19:45:13');
INSERT INTO `uums_res` VALUES ('359', '0', '208', 'EVA_ADD', '新增评估', '/memberEvaluate/newMemberEvaluate.action', '1', '1', '', '2017-07-14 09:56:39');
INSERT INTO `uums_res` VALUES ('360', '0', '208', 'EVA_NERSING_GRADE_VIEW', '查看护理等级评估', '/nursingGrade/findDetails.action', '1', '8', '', '2017-07-14 10:27:45');
INSERT INTO `uums_res` VALUES ('361', '0', '208', 'EVA_NERSING_GRADE_EDIT', '编辑护理等级评估', '/nursingGrade/toEdit.action', '1', '9', '', '2017-07-14 10:42:24');
INSERT INTO `uums_res` VALUES ('362', '0', '208', 'EVA_NERSING_GRADE_ADD', '新增护理等级评估', '/nursingGrade/toNursingGradeEvaluate', '1', '7', '', '2017-07-14 10:46:31');
INSERT INTO `uums_res` VALUES ('363', '0', '208', 'EVA_SUMMARY', '总结评估', '/memberEvaluate/saveResult.action', '1', '10', '', '2017-07-14 10:58:06');
INSERT INTO `uums_res` VALUES ('364', '0', '208', 'EVA_NERSING_PLAN_VIEW', '查看护理计划', '/nersing/details.action', '1', '12', '', '2017-07-14 10:59:36');
INSERT INTO `uums_res` VALUES ('365', '0', '208', 'EVA_NERSING_PLAN_ADD', '制定护理计划', '/nersing/nersingPlan.action', '1', '11', '', '2017-07-14 11:01:18');
INSERT INTO `uums_res` VALUES ('366', '0', '208', 'EVA_INTELLIGENCE_EDIT', '编辑简易智力评估', '/brains/evaluation.action', '1', '7', '', '2017-07-14 11:09:07');
INSERT INTO `uums_res` VALUES ('367', '0', '208', 'EVA_INTELLIGENCE_VIEW', '查看简易智力评估', '/nursingGrade/findDetails.action', '1', '6', '', '2017-07-14 11:12:29');
INSERT INTO `uums_res` VALUES ('368', '0', '208', 'EVA_GENERAL_EDIT', '编辑综合健康评估', '/composite/reportView.action', '1', '4', '', '2017-07-14 11:29:57');
INSERT INTO `uums_res` VALUES ('369', '0', '208', 'EVA_GENERAL_VIEW', '查看综合健康评估', '/composite/evaluateDetails.action', '1', '12', '', '2017-07-14 11:32:45');
INSERT INTO `uums_res` VALUES ('371', '0', '222', 'SCHEDULE_EDIT', '编辑班次', '/schedule/toUpdate', '1', '0', '', '2017-07-14 14:43:34');
INSERT INTO `uums_res` VALUES ('372', '0', '222', 'SCHEDULE_DEL', '删除班次', '/schedule/del', '1', '0', '', '2017-07-14 14:48:01');
INSERT INTO `uums_res` VALUES ('373', '0', '222', 'SCHEDULE_ADD', '新增班次', '/schedule/toAdd', '1', '0', '', '2017-07-14 14:54:49');
INSERT INTO `uums_res` VALUES ('374', '0', '224', 'SCHEDULE_CALENDAR', '排班日历', '/scheduleDetail/calendar', '1', '0', '', '2017-07-14 15:18:50');
INSERT INTO `uums_res` VALUES ('377', '0', '230', 'BED_EDIT', '编辑床位', '/bed/toUpdate', '1', '0', '', '2017-07-14 16:23:48');
INSERT INTO `uums_res` VALUES ('378', '0', '230', 'BED_ADD', '新增床位', '/bed/toAdd', '1', '0', '', '2017-07-14 16:24:57');
INSERT INTO `uums_res` VALUES ('379', '0', '237', 'DOC_VIEW', '查看文档信息', '/document/details', '1', '0', '', '2017-07-14 16:34:00');
INSERT INTO `uums_res` VALUES ('380', '0', '237', 'DOC_DEL', '删除文档', '/document/del', '1', '0', '', '2017-07-14 16:34:48');
INSERT INTO `uums_res` VALUES ('381', '0', '237', 'DOC_EDIT', '编辑文档', '/document/toUpdate', '1', '0', '', '2017-07-14 16:36:31');
INSERT INTO `uums_res` VALUES ('382', '0', '237', 'DOC_ADD', '新增文档', '/document/toAdd', '1', '0', '', '2017-07-14 16:37:33');
INSERT INTO `uums_res` VALUES ('383', '0', '233', 'CHARGE_ITEM_EDIT', '编辑收费项目', '/cost/toUpdate', '1', '0', '', '2017-07-14 16:41:35');
INSERT INTO `uums_res` VALUES ('384', '0', '233', 'CHARGE_ITEM_DEL', '删除收费项目', '/cost/del', '1', '0', '', '2017-07-14 16:43:13');
INSERT INTO `uums_res` VALUES ('385', '0', '233', 'CHARGE_ITEM_ADD', '新增收费项目', '/cost/toAdd', '1', '0', '', '2017-07-14 16:44:02');
INSERT INTO `uums_res` VALUES ('386', '0', '235', 'CHARGE_SUNDRY_EDIT', '编辑收费记录', '/incidental/toUpdate', '1', '0', '', '2017-07-14 16:54:30');
INSERT INTO `uums_res` VALUES ('387', '0', '235', 'CHARGE_SUNDRY_DEL', '删除收费记录', '/incidental/del', '1', '0', '', '2017-07-14 16:55:00');
INSERT INTO `uums_res` VALUES ('388', '0', '235', 'CHARGE_SUNDRY_VIEW', '查看收费记录', '/incidental/details', '1', '0', '', '2017-07-14 16:55:58');
INSERT INTO `uums_res` VALUES ('389', '0', '235', 'CHARGE_SUNDRY_ADD', '新增收费记录', '/incidental/toAdd', '1', '0', '', '2017-07-14 16:56:50');
INSERT INTO `uums_res` VALUES ('390', '0', '547', 'MEDICATION_MISTAKE_OMISSION_DEL', '删除错漏摆记录', '/pharmacy/deleteErrors', '1', '4', '', '2017-07-14 18:02:30');
INSERT INTO `uums_res` VALUES ('395', '0', '230', 'BED_DEL', '删除床位', '/bed/del', '1', '0', '', '2017-07-23 15:16:48');
INSERT INTO `uums_res` VALUES ('402', '1', null, 'INDEX', '首页', '#', '1', '1', 'iconfont icon-shouye', '2017-07-27 14:06:27');
INSERT INTO `uums_res` VALUES ('405', '0', '208', 'EVA_GENERAL_ADD', '新增综合健康评估', '/composite/reportView', '1', '2', '', '2017-07-28 08:50:41');
INSERT INTO `uums_res` VALUES ('406', '1', null, 'CHARGE', '收费管理', '#', '1', '6', 'iconfont icon-jiaofei', '2017-07-28 10:05:03');
INSERT INTO `uums_res` VALUES ('407', '1', null, 'EVA', '评估管理', '#', '1', '4', 'iconfont icon-pinggu', '2017-07-28 10:15:07');
INSERT INTO `uums_res` VALUES ('408', '0', '208', 'EVA_INTELLIGENCE_ADD', '新增简易智力评估', '/brains/evaluation.action', '1', '5', '', '2017-07-28 10:45:21');
INSERT INTO `uums_res` VALUES ('410', '0', '235', 'CHARGE_SUNDRY_CHECK_EXPORT', '导出月账单', '/incidental/educe', '1', '0', '', '2017-07-28 14:40:04');
INSERT INTO `uums_res` VALUES ('412', '1', '406', 'BED_USE', '床位记录', '/bed/toList', '1', '0', '', '2017-07-28 14:49:45');
INSERT INTO `uums_res` VALUES ('413', '1', null, 'EMPLOYE', '员工管理', '#', '1', '8', 'iconfont icon-yuangong', '2017-07-28 15:04:28');
INSERT INTO `uums_res` VALUES ('414', '0', '84', 'ROLE_ADD', '新增角色', '/role/save', '1', '1', '', '2017-07-28 16:56:56');
INSERT INTO `uums_res` VALUES ('415', '0', '224', 'SCHEDULE_RECORD_EXPORT', '导出排班记录', '/scheduleDetail/educe', '1', '0', '', '2017-07-28 16:59:30');
INSERT INTO `uums_res` VALUES ('416', '0', '84', 'ROLE_EDIT', '编辑角色', '/role/update', '1', '2', '', '2017-07-28 17:00:01');
INSERT INTO `uums_res` VALUES ('417', '1', null, 'DOC', '文档管理', '#', '1', '10', 'iconfont icon-wendang', '2017-07-28 17:02:14');
INSERT INTO `uums_res` VALUES ('418', '0', '84', 'ROLE_GRANT_RESOURCE', '分配资源权限', '/role/findResByRoleId', '1', '4', '', '2017-07-28 17:02:25');
INSERT INTO `uums_res` VALUES ('419', '0', '84', 'ROLE_DEL', '删除角色', '/role/delete', '1', '3', '', '2017-07-28 17:05:58');
INSERT INTO `uums_res` VALUES ('420', '1', '402', 'TODO_LIST', '待办事项', '#', '1', '1', '', '2017-07-28 17:11:33');
INSERT INTO `uums_res` VALUES ('421', '0', '238', 'DIC_CONSULT_CATEGORY', '咨询分类', '#', '1', '1', '', '2017-07-28 17:20:35');
INSERT INTO `uums_res` VALUES ('422', '0', '238', 'DIC_RATE_CATEGORY', '评级分类', '#', '1', '2', '', '2017-07-28 17:24:55');
INSERT INTO `uums_res` VALUES ('423', '0', '238', 'DIC_CERTIFICATE_CLASS', '证件分类', '#', '1', '3', '', '2017-07-28 17:26:53');
INSERT INTO `uums_res` VALUES ('424', '0', '238', 'DIC_DISTRICT', '行政区划', '#', '1', '4', '', '2017-07-28 17:28:32');
INSERT INTO `uums_res` VALUES ('425', '0', '238', 'DIC_REGION', '商圈区域', '#', '1', '5', '', '2017-07-28 17:29:31');
INSERT INTO `uums_res` VALUES ('426', '0', '238', 'DIC_TAG', '客户标签', '#', '1', '6', '', '2017-07-28 17:32:01');
INSERT INTO `uums_res` VALUES ('427', '0', '238', 'DIC_BED_REGION', '床位区域', '#', '1', '7', '', '2017-07-28 17:34:46');
INSERT INTO `uums_res` VALUES ('428', '0', '81', 'ORG_ADD', '创建机构', '#', '1', '0', '', '2017-07-28 17:35:13');
INSERT INTO `uums_res` VALUES ('429', '0', '81', 'ORG_EDIT', '修改机构', '#', '1', '0', '', '2017-07-28 17:35:37');
INSERT INTO `uums_res` VALUES ('430', '0', '81', 'ORG_DEL', '删除机构', '#', '1', '0', '', '2017-07-28 17:36:02');
INSERT INTO `uums_res` VALUES ('431', '0', '238', 'DIC_COST_CATEGORY', '费用类别', '#', '1', '8', '', '2017-07-28 17:37:06');
INSERT INTO `uums_res` VALUES ('432', '0', '238', 'DIC_MATERIAL_CATEGORY', '物资分类', '#', '1', '9', '', '2017-07-28 17:38:36');
INSERT INTO `uums_res` VALUES ('433', '0', '238', 'DIC_JOB_CATEGORY', '工作岗位', '#', '1', '10', '', '2017-07-28 17:39:42');
INSERT INTO `uums_res` VALUES ('434', '0', '298', 'MEMBER_INFO', '客户信息', '/member/findById', '1', '0', '', '2017-07-28 18:41:24');
INSERT INTO `uums_res` VALUES ('435', '0', '298', 'CALLBACK_INFO', '回访信息', '/callback/goAdd', '1', '0', '', '2017-07-28 18:43:14');
INSERT INTO `uums_res` VALUES ('436', '0', '298', 'EVA_INFO', '评估信息', '/memberEvaluate/toList', '1', '0', '', '2017-07-28 18:44:06');
INSERT INTO `uums_res` VALUES ('437', '0', '298', 'CHECKUP_INFO', '体检信息', '/checkUp/toCheckUpList', '1', '0', '', '2017-07-28 18:45:15');
INSERT INTO `uums_res` VALUES ('438', '0', '298', 'BED_INFO', '缴费信息', '/charge/toList', '1', '0', '', '2017-07-28 18:46:10');
INSERT INTO `uums_res` VALUES ('439', '0', '298', 'DRUG_INFO', '用药信息', '/pharmacy/pharmacyList', '1', '0', '', '2017-07-28 18:46:40');
INSERT INTO `uums_res` VALUES ('440', '0', '298', 'VITAL_SIGNS_INFO', '生命体征记录', '/vitalSigns/toList', '1', '0', '', '2017-07-28 18:47:10');
INSERT INTO `uums_res` VALUES ('441', '0', '298', 'NURSING_INFO', '护理记录', '/nursingRecord/toList', '1', '0', '', '2017-07-28 18:48:18');
INSERT INTO `uums_res` VALUES ('442', '1', null, 'BED', '床位管理', '#', '1', '6', 'iconfont icon-chuangwei', '2017-07-28 18:48:18');
INSERT INTO `uums_res` VALUES ('475', '1', null, 'EGRESS', '外出管理', '#', '1', '11', 'iconfont icon-waichu', '2017-09-11 15:58:21');
INSERT INTO `uums_res` VALUES ('476', '1', '475', 'LEAVE_LIST', '请假列表', '/egress/leaveRecordList', '1', '0', '', '2017-09-11 15:59:06');
INSERT INTO `uums_res` VALUES ('477', '0', '476', 'LEAVE_BACK', '销假', '/egress/passRemove', '1', '3', '', '2017-09-11 15:59:59');
INSERT INTO `uums_res` VALUES ('478', '0', '476', 'LEAVE_ADD', '新增请假记录', '/egress/toAddLeaveRecord', '1', '0', '', '2017-09-11 16:00:44');
INSERT INTO `uums_res` VALUES ('479', '0', '476', 'LEAVE_AUDIT', '请假审核', '/egress/pass', '1', '0', '', '2017-09-11 16:01:21');
INSERT INTO `uums_res` VALUES ('480', '0', '476', 'LEAVE_UPDATE', '请假修改', '/egress/updateLeaveRecord', '1', '2', '', '2017-09-11 16:11:35');
INSERT INTO `uums_res` VALUES ('481', '0', '476', 'LEAVE_DEL', '请假记录删除', '/egress/deleteEgressRecord', '1', '0', '', '2017-09-11 16:12:14');
INSERT INTO `uums_res` VALUES ('482', '1', '475', 'LEAVE_COST', '请假退费配置单', '/egress/leaveCostList', '1', '1', '', '2017-09-11 16:12:58');
INSERT INTO `uums_res` VALUES ('483', '0', '482', 'LEAVE_COST_DEL', '删除配置', '/egress/deleteLeaveCost', '1', '1', '', '2017-09-11 16:13:37');
INSERT INTO `uums_res` VALUES ('484', '0', '482', 'LEAVE_COST_ADD', '新增配置', '/egress/saveLeaveCord', '1', '0', '', '2017-09-11 16:14:12');
INSERT INTO `uums_res` VALUES ('485', '0', '238', 'DIC_LEAVE_TYPE', '请假类型', '#', '1', '0', '', '2017-09-11 19:36:55');
INSERT INTO `uums_res` VALUES ('492', '1', null, 'ACTIVITY', '活动管理', '#', '1', '13', 'fa fa-group', '2017-09-22 16:43:43');
INSERT INTO `uums_res` VALUES ('493', '1', '492', 'ACTIVITY_LIST', '活动列表', '/activity/goList', '1', '1', '', '2017-09-22 16:44:59');
INSERT INTO `uums_res` VALUES ('494', '0', '493', 'ACTIVITY_LIST_ADD', '新增活动', '/activity/goAdd', '1', '0', '', '2017-09-22 16:45:55');
INSERT INTO `uums_res` VALUES ('495', '0', '493', 'ACTIVITY_PUSH', '发布', '/activity/changeFlag', '1', '0', '', '2017-09-22 16:47:03');
INSERT INTO `uums_res` VALUES ('496', '0', '493', 'ACTIVITY_CANCEL', '取消', '/activity/changeFlag', '1', '0', '', '2017-09-22 16:47:35');
INSERT INTO `uums_res` VALUES ('497', '0', '493', 'ACTIVITY_EDIT', '编辑', '/activity/goAdd', '1', '0', '', '2017-09-22 16:48:05');
INSERT INTO `uums_res` VALUES ('498', '0', '493', 'ACTIVITY_DEL', '删除', '/activity/del', '1', '0', '', '2017-09-22 16:48:36');
INSERT INTO `uums_res` VALUES ('499', '1', '492', 'ACTIVITY_CALENDAR', '活动日历', '/activityCalendar/goCalendar', '1', '3', '', '2017-09-22 16:49:43');
INSERT INTO `uums_res` VALUES ('500', '0', '499', 'ACTIVITY_CALENDAR_ADD', '安排活动', '#', '1', '0', '', '2017-09-22 16:50:35');
INSERT INTO `uums_res` VALUES ('501', '1', '492', 'ACTIVITY_SUMMARIZE', '活动总结', '/activityCalendar/summarize', '1', '4', '', '2017-09-22 16:51:23');
INSERT INTO `uums_res` VALUES ('502', '0', '501', 'ACTIVITY_SUMMARIZE_EDIT', '编辑查看', '/activityCalendar/goAdd', '1', '0', '', '2017-09-22 16:51:54');
INSERT INTO `uums_res` VALUES ('503', '1', '492', 'ACTIVITY_SIGN', '活动签到', '/sign/goSign', '1', '0', '', '2017-09-22 16:53:13');
INSERT INTO `uums_res` VALUES ('504', '0', '503', 'ACTIVITY_SIGN_EDIT', '查看签到', '/sign/goSignAdd', '1', '0', '', '2017-09-22 16:53:49');
INSERT INTO `uums_res` VALUES ('505', '0', '503', 'ACTIVITY_SIGN_ADD', '新增签到', '#', '1', '0', '', '2017-09-22 16:54:39');
INSERT INTO `uums_res` VALUES ('506', '1', null, 'STOCKHOUSE', '出入库管理', '#', '1', '12', 'iconfont icon-cangku', '2017-09-22 20:57:13');
INSERT INTO `uums_res` VALUES ('507', '1', '506', 'STOCKHOUSE_MANAGE', '仓库管理', '/stockHouse/toStockHouseList', '1', '5', null, '2017-09-13 09:46:26');
INSERT INTO `uums_res` VALUES ('508', '1', '506', 'STOCKHOUSE_IN', '入库列表', '/stockHouse/toInStockHouseList', '1', '2', null, '2017-09-18 09:47:03');
INSERT INTO `uums_res` VALUES ('509', '1', '506', 'STOCKHOUSE_OUT', '出库列表', '/stockHouse/toOutStockHouseList', '1', '3', null, '2017-09-19 16:18:46');
INSERT INTO `uums_res` VALUES ('510', '1', '506', 'STOCKMATERIAL', '库存概览', '/stockMaterial/toStockHouseList', '1', '1', null, '2017-09-19 16:18:46');
INSERT INTO `uums_res` VALUES ('511', '1', '506', 'STOCKCHECK', '盘点管理', '/stockCheck/toStockCheckList', '1', '4', null, '2017-09-20 17:12:38');
INSERT INTO `uums_res` VALUES ('512', '0', '238', 'DIC_ACTIVITY_TYPE', '活动类型', '#', '1', '13', '', '2017-09-23 11:02:30');
INSERT INTO `uums_res` VALUES ('513', '0', '238', 'DIC_NURSE_GRADE', '护理等级', '#', '1', '12', '', '2017-09-23 11:03:33');
INSERT INTO `uums_res` VALUES ('514', '0', '507', 'STOCKHOUSE_ADD', '新增仓库', '/stockHouse/saveStockHouse', '1', '1', null, '2017-09-23 11:13:11');
INSERT INTO `uums_res` VALUES ('515', '0', '507', 'STOCKHOUSE_UPDATE', '编辑仓库', '/stockHouse/saveStockHouse', '1', '2', null, '2017-09-23 11:14:33');
INSERT INTO `uums_res` VALUES ('516', '0', '507', 'STOCKHOUSE_DEL', '删除仓库', '/stockHouse/deleteStockHouse', '1', '3', null, '2017-09-23 11:15:28');
INSERT INTO `uums_res` VALUES ('517', '0', '508', 'INSTOCKHOUSE_ADD', '新增入库', '/stockHouse/toInStockHouse', '1', '1', null, '2017-09-23 10:42:24');
INSERT INTO `uums_res` VALUES ('518', '0', '508', 'INSTOCKHOUSE_AUDIT', '入库审核', '/stockHouse/auditInStock', '1', '2', null, '2017-09-23 10:45:24');
INSERT INTO `uums_res` VALUES ('519', '0', '508', 'INSTOCKHOUSE_UPDATE', '入库编辑', '/stockHouse/toUpdateInStockHouse', '1', '3', null, '2017-09-23 10:45:24');
INSERT INTO `uums_res` VALUES ('520', '0', '509', 'OUTSTOCKHOUSE_ADD', '新增出库', '/stockHouse/toOutStockHouse', '1', '1', null, '2017-09-23 10:52:21');
INSERT INTO `uums_res` VALUES ('521', '0', '509', 'OUTSTOCKHOUSE_AUDIT', '出库审核', '/stockHouse/auditInStock', '1', '2', null, '2017-09-23 10:56:37');
INSERT INTO `uums_res` VALUES ('522', '0', '509', 'OUTSTOCKHOUSE_UPDATE', '出库编辑', '/stockHouse/toUpdateOutStockHouse', '1', '3', null, '2017-09-23 10:57:37');
INSERT INTO `uums_res` VALUES ('523', '0', '511', 'STOCKCHECK_ADD', '新增盘点', '/stockCheck/toStockCheckHouse', '1', '1', null, '2017-09-23 11:01:18');
INSERT INTO `uums_res` VALUES ('524', '0', '511', 'STOCKCHECK_AUDIT', '审核盘点', '/stockCheck/auditInStock', '1', '2', null, '2017-09-23 11:03:59');
INSERT INTO `uums_res` VALUES ('525', '0', '511', 'STOCKCHECK_UPDATE', '编辑盘点', '/stockHouse/toUpdateOutStockHouse', '1', '3', null, '2017-09-23 11:06:45');
INSERT INTO `uums_res` VALUES ('526', '0', '511', 'STOCKCHECK_DEL', '删除盘点', '/stockCheck/deleteStockCheck', '1', '4', null, '2017-09-23 11:07:57');
INSERT INTO `uums_res` VALUES ('527', '0', '503', 'ACTIVITY_SIGN_DEL', '删除签到', '/sign/del', '1', '0', '', '2017-09-28 17:33:18');
INSERT INTO `uums_res` VALUES ('528', '0', '499', 'ACTIVITY_CALENDAR_DEL', '删除活动', '/activityCalendar/deleteActivityCalendar', '1', '0', '', '2017-09-28 17:34:45');
INSERT INTO `uums_res` VALUES ('540', '0', '238', 'DIC_NURSE_RECORD_TEMPLATE', '护理内容模板', '#', '1', '14', '', '2017-11-15 10:31:07');
INSERT INTO `uums_res` VALUES ('542', '1', null, 'MEDICATION', '用药管理', '#', '1', '15', 'iconfont icon-yongyao', '2017-11-10 11:59:01');
INSERT INTO `uums_res` VALUES ('543', '1', '542', 'MEMBER_MEDICATION_LIST', '自备药品管理', '/memberMedication/toList', '1', '1', '', '2017-11-10 12:16:44');
INSERT INTO `uums_res` VALUES ('544', '1', '542', 'MEDICATION_STORE_LIST', '存药管理', '/medicationStore/toList', '1', '2', '', '2017-11-10 12:18:31');
INSERT INTO `uums_res` VALUES ('545', '1', '542', 'MEMBER_CHECK_LIST', '分药单管理', '/medication/toMemberCheckList', '1', '3', '', '2017-11-10 12:20:00');
INSERT INTO `uums_res` VALUES ('546', '1', '542', 'MEDICATION_USING_LIST', '用药记录', '/medicationUsing/toList', '1', '4', '', '2017-11-10 12:21:04');
INSERT INTO `uums_res` VALUES ('547', '1', '542', 'MEDICATION_MISTAKE_OMISSION_LIST', '错漏摆记录', '/pharmacy/errorsRecordList', '1', '5', '', '2017-11-10 12:22:47');
INSERT INTO `uums_res` VALUES ('548', '0', '545', 'MEDICATION_CHECK_ADD', '新建分药单', '/medication/saveCheck', '1', '1', '', '2017-11-21 17:14:10');
INSERT INTO `uums_res` VALUES ('549', '0', '545', 'MEDICATION_CHECK_VIEW', '查看分药单详细', '/medication/findCheckDetail', '1', '0', '', '2017-11-21 17:15:03');
INSERT INTO `uums_res` VALUES ('550', '0', '545', 'MEDICATION_CHECK_EDIT', '编辑分药单详细', '/medication/findCheckDetail', '1', '3', '', '2017-11-21 17:16:09');
INSERT INTO `uums_res` VALUES ('551', '0', '545', 'MEDICATION_CHECK_STOP', ' 停/启用分药单', '/medication/changeCheckFlag', '1', '4', '', '2017-11-21 17:16:49');
INSERT INTO `uums_res` VALUES ('552', '0', '545', 'MEDICATION_CHECK_DEL', '删除分药单', '/medication/deleteCheck', '1', '5', '', '2017-11-21 17:17:36');
INSERT INTO `uums_res` VALUES ('553', '0', '543', 'MEMBER_MEDICATION_ADD', '添加', '/memberMedication/toEdit', '1', '1', '', '2017-11-21 17:50:36');
INSERT INTO `uums_res` VALUES ('554', '0', '543', 'MEMBER_MEDICATION_VIEW', '查看', '/memberMedication/toEdit', '1', '2', '', '2017-11-21 17:51:36');
INSERT INTO `uums_res` VALUES ('555', '0', '543', 'MEMBER_MEDICATION_EDIT', '编辑', '/memberMedication/toEdit', '1', '3', '', '2017-11-21 17:52:14');
INSERT INTO `uums_res` VALUES ('556', '0', '543', 'MEMBER_MEDICATION_DEL', '删除', '/memberMedication/delete', '1', '4', '', '2017-11-21 17:53:01');
INSERT INTO `uums_res` VALUES ('557', '0', '544', 'MEDICATION_STORE_ADD', '添加', '/medicationStore/toEdit', '1', '1', '', '2017-11-21 17:53:41');
INSERT INTO `uums_res` VALUES ('558', '0', '544', 'MEDICATION_STORE_VIEW', '查看', '/medicationStore/toEdit', '1', '2', '', '2017-11-21 17:54:22');
INSERT INTO `uums_res` VALUES ('559', '0', '544', 'MEDICATION_STORE_EDIT', '编辑', '/medicationStore/toEdit', '1', '3', '', '2017-11-21 17:54:55');
INSERT INTO `uums_res` VALUES ('560', '0', '544', 'MEDICATION_STORE_DEL', '删除', '/medicationStore/delete', '1', '4', '', '2017-11-21 17:55:27');
INSERT INTO `uums_res` VALUES ('561', '0', '546', 'MEDICATION_CHECK', '分药', '/medicationUsing/changeFlag', '1', '1', '', '2017-11-21 17:56:25');
INSERT INTO `uums_res` VALUES ('562', '0', '546', 'MEDICATION_PASS', '通过', '/medicationUsing/changeFlag', '1', '2', '', '2017-11-21 17:57:04');
INSERT INTO `uums_res` VALUES ('563', '0', '546', 'MEDICATION_REJECT', '驳回', '/medicationUsing/saveReason', '1', '3', '', '2017-11-21 17:57:41');
INSERT INTO `uums_res` VALUES ('564', '0', '546', 'MEDICATION_REJECT_REASON', '驳回原因', '#', '1', '4', '', '2017-11-21 17:58:49');
INSERT INTO `uums_res` VALUES ('565', '0', '546', 'MEDICATION_USE_OVER', '用药完成', '/medicationUsing/changeFlag', '1', '5', '', '2017-11-21 18:01:33');
INSERT INTO `uums_res` VALUES ('566', '0', '546', 'MEDICATION_CHECK_VIEW', '查看对药单', '/medicationUsing/findMedicationCheck', '1', '6', '', '2017-11-21 18:02:12');
INSERT INTO `uums_res` VALUES ('567', '0', '546', 'MEDICATION_MISTAKE_OMISSION_ADD', '记录错漏摆', '/pharmacy/toAddErrorsRecord', '1', '7', '', '2017-11-21 18:02:49');
INSERT INTO `uums_res` VALUES ('579', '1', '83', 'ORG_RES', '机构资源管理', '/org/orgResList', '1', '0', '', '2017-12-28 21:57:17');
INSERT INTO `uums_res` VALUES ('580', '1', '83', 'CLEAR_REDIS_CACHE', '一键清除缓存', '/user/clearRedisCache', '1', '7', '', '2017-12-29 11:28:41');

-- ----------------------------
-- Table structure for uums_role
-- ----------------------------
DROP TABLE IF EXISTS `uums_role`;
CREATE TABLE `uums_role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色唯一标识，自增',
  `ROLE_NAME` varchar(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `FLAG` int(1) NOT NULL DEFAULT '1' COMMENT '角色当前状态：1-正常，0-停用，默认1',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_role
-- ----------------------------
INSERT INTO `uums_role` VALUES ('42', '系统管理员', '1', '2017-06-27 16:26:29');
INSERT INTO `uums_role` VALUES ('53', '护理主任', '1', '2017-07-27 11:54:47');
INSERT INTO `uums_role` VALUES ('54', '办公室主任', '1', '2017-07-27 11:54:58');
INSERT INTO `uums_role` VALUES ('55', '护理组长', '1', '2017-07-27 11:55:41');
INSERT INTO `uums_role` VALUES ('56', '储备组长', '1', '2017-07-27 11:55:53');
INSERT INTO `uums_role` VALUES ('57', '护士', '1', '2017-07-27 11:56:01');
INSERT INTO `uums_role` VALUES ('58', '行政', '1', '2017-07-27 11:56:08');
INSERT INTO `uums_role` VALUES ('59', '护理员', '1', '2017-07-27 11:56:27');
INSERT INTO `uums_role` VALUES ('60', '护工', '1', '2017-07-27 11:56:45');
INSERT INTO `uums_role` VALUES ('99', '下级管理员', '1', '2018-01-22 19:01:17');

-- ----------------------------
-- Table structure for uums_role_res
-- ----------------------------
DROP TABLE IF EXISTS `uums_role_res`;
CREATE TABLE `uums_role_res` (
  `role_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  PRIMARY KEY (`role_id`,`res_id`),
  KEY `FK_lwerq3awan9yi5j2a7sd1bcnj` (`res_id`),
  CONSTRAINT `FK_ew1epq7y5hub2509jo1bnsa5r` FOREIGN KEY (`role_id`) REFERENCES `uums_role` (`ID`),
  CONSTRAINT `FK_lwerq3awan9yi5j2a7sd1bcnj` FOREIGN KEY (`res_id`) REFERENCES `uums_res` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_role_res
-- ----------------------------
INSERT INTO `uums_role_res` VALUES ('42', '81');
INSERT INTO `uums_role_res` VALUES ('99', '81');
INSERT INTO `uums_role_res` VALUES ('42', '83');
INSERT INTO `uums_role_res` VALUES ('99', '83');
INSERT INTO `uums_role_res` VALUES ('42', '84');
INSERT INTO `uums_role_res` VALUES ('99', '84');
INSERT INTO `uums_role_res` VALUES ('42', '85');
INSERT INTO `uums_role_res` VALUES ('99', '85');
INSERT INTO `uums_role_res` VALUES ('42', '100');
INSERT INTO `uums_role_res` VALUES ('99', '100');
INSERT INTO `uums_role_res` VALUES ('42', '119');
INSERT INTO `uums_role_res` VALUES ('99', '119');
INSERT INTO `uums_role_res` VALUES ('42', '120');
INSERT INTO `uums_role_res` VALUES ('99', '120');
INSERT INTO `uums_role_res` VALUES ('42', '121');
INSERT INTO `uums_role_res` VALUES ('99', '121');
INSERT INTO `uums_role_res` VALUES ('42', '122');
INSERT INTO `uums_role_res` VALUES ('99', '122');
INSERT INTO `uums_role_res` VALUES ('42', '123');
INSERT INTO `uums_role_res` VALUES ('99', '123');
INSERT INTO `uums_role_res` VALUES ('42', '190');
INSERT INTO `uums_role_res` VALUES ('53', '190');
INSERT INTO `uums_role_res` VALUES ('54', '190');
INSERT INTO `uums_role_res` VALUES ('42', '193');
INSERT INTO `uums_role_res` VALUES ('53', '193');
INSERT INTO `uums_role_res` VALUES ('54', '193');
INSERT INTO `uums_role_res` VALUES ('53', '203');
INSERT INTO `uums_role_res` VALUES ('54', '203');
INSERT INTO `uums_role_res` VALUES ('53', '204');
INSERT INTO `uums_role_res` VALUES ('54', '204');
INSERT INTO `uums_role_res` VALUES ('53', '205');
INSERT INTO `uums_role_res` VALUES ('54', '205');
INSERT INTO `uums_role_res` VALUES ('53', '206');
INSERT INTO `uums_role_res` VALUES ('54', '206');
INSERT INTO `uums_role_res` VALUES ('53', '207');
INSERT INTO `uums_role_res` VALUES ('54', '207');
INSERT INTO `uums_role_res` VALUES ('42', '208');
INSERT INTO `uums_role_res` VALUES ('53', '208');
INSERT INTO `uums_role_res` VALUES ('53', '210');
INSERT INTO `uums_role_res` VALUES ('42', '212');
INSERT INTO `uums_role_res` VALUES ('53', '212');
INSERT INTO `uums_role_res` VALUES ('42', '213');
INSERT INTO `uums_role_res` VALUES ('53', '213');
INSERT INTO `uums_role_res` VALUES ('42', '214');
INSERT INTO `uums_role_res` VALUES ('53', '214');
INSERT INTO `uums_role_res` VALUES ('53', '215');
INSERT INTO `uums_role_res` VALUES ('53', '217');
INSERT INTO `uums_role_res` VALUES ('53', '219');
INSERT INTO `uums_role_res` VALUES ('53', '220');
INSERT INTO `uums_role_res` VALUES ('53', '221');
INSERT INTO `uums_role_res` VALUES ('42', '222');
INSERT INTO `uums_role_res` VALUES ('53', '222');
INSERT INTO `uums_role_res` VALUES ('54', '222');
INSERT INTO `uums_role_res` VALUES ('53', '223');
INSERT INTO `uums_role_res` VALUES ('42', '224');
INSERT INTO `uums_role_res` VALUES ('53', '224');
INSERT INTO `uums_role_res` VALUES ('54', '224');
INSERT INTO `uums_role_res` VALUES ('42', '225');
INSERT INTO `uums_role_res` VALUES ('54', '225');
INSERT INTO `uums_role_res` VALUES ('53', '229');
INSERT INTO `uums_role_res` VALUES ('54', '229');
INSERT INTO `uums_role_res` VALUES ('42', '230');
INSERT INTO `uums_role_res` VALUES ('53', '230');
INSERT INTO `uums_role_res` VALUES ('54', '230');
INSERT INTO `uums_role_res` VALUES ('53', '232');
INSERT INTO `uums_role_res` VALUES ('54', '232');
INSERT INTO `uums_role_res` VALUES ('42', '233');
INSERT INTO `uums_role_res` VALUES ('54', '233');
INSERT INTO `uums_role_res` VALUES ('53', '234');
INSERT INTO `uums_role_res` VALUES ('54', '234');
INSERT INTO `uums_role_res` VALUES ('42', '235');
INSERT INTO `uums_role_res` VALUES ('54', '235');
INSERT INTO `uums_role_res` VALUES ('42', '237');
INSERT INTO `uums_role_res` VALUES ('53', '237');
INSERT INTO `uums_role_res` VALUES ('54', '237');
INSERT INTO `uums_role_res` VALUES ('42', '238');
INSERT INTO `uums_role_res` VALUES ('99', '238');
INSERT INTO `uums_role_res` VALUES ('53', '241');
INSERT INTO `uums_role_res` VALUES ('53', '242');
INSERT INTO `uums_role_res` VALUES ('53', '243');
INSERT INTO `uums_role_res` VALUES ('53', '244');
INSERT INTO `uums_role_res` VALUES ('53', '249');
INSERT INTO `uums_role_res` VALUES ('53', '250');
INSERT INTO `uums_role_res` VALUES ('53', '251');
INSERT INTO `uums_role_res` VALUES ('53', '252');
INSERT INTO `uums_role_res` VALUES ('53', '254');
INSERT INTO `uums_role_res` VALUES ('54', '254');
INSERT INTO `uums_role_res` VALUES ('53', '257');
INSERT INTO `uums_role_res` VALUES ('54', '257');
INSERT INTO `uums_role_res` VALUES ('53', '258');
INSERT INTO `uums_role_res` VALUES ('53', '261');
INSERT INTO `uums_role_res` VALUES ('54', '261');
INSERT INTO `uums_role_res` VALUES ('53', '264');
INSERT INTO `uums_role_res` VALUES ('54', '264');
INSERT INTO `uums_role_res` VALUES ('53', '265');
INSERT INTO `uums_role_res` VALUES ('54', '265');
INSERT INTO `uums_role_res` VALUES ('53', '266');
INSERT INTO `uums_role_res` VALUES ('53', '268');
INSERT INTO `uums_role_res` VALUES ('53', '269');
INSERT INTO `uums_role_res` VALUES ('53', '270');
INSERT INTO `uums_role_res` VALUES ('54', '270');
INSERT INTO `uums_role_res` VALUES ('53', '272');
INSERT INTO `uums_role_res` VALUES ('54', '272');
INSERT INTO `uums_role_res` VALUES ('53', '274');
INSERT INTO `uums_role_res` VALUES ('54', '274');
INSERT INTO `uums_role_res` VALUES ('53', '275');
INSERT INTO `uums_role_res` VALUES ('54', '275');
INSERT INTO `uums_role_res` VALUES ('53', '277');
INSERT INTO `uums_role_res` VALUES ('53', '279');
INSERT INTO `uums_role_res` VALUES ('54', '279');
INSERT INTO `uums_role_res` VALUES ('53', '280');
INSERT INTO `uums_role_res` VALUES ('53', '281');
INSERT INTO `uums_role_res` VALUES ('54', '281');
INSERT INTO `uums_role_res` VALUES ('53', '282');
INSERT INTO `uums_role_res` VALUES ('54', '282');
INSERT INTO `uums_role_res` VALUES ('53', '283');
INSERT INTO `uums_role_res` VALUES ('54', '283');
INSERT INTO `uums_role_res` VALUES ('53', '284');
INSERT INTO `uums_role_res` VALUES ('54', '284');
INSERT INTO `uums_role_res` VALUES ('53', '285');
INSERT INTO `uums_role_res` VALUES ('53', '286');
INSERT INTO `uums_role_res` VALUES ('53', '288');
INSERT INTO `uums_role_res` VALUES ('53', '292');
INSERT INTO `uums_role_res` VALUES ('53', '293');
INSERT INTO `uums_role_res` VALUES ('54', '293');
INSERT INTO `uums_role_res` VALUES ('53', '294');
INSERT INTO `uums_role_res` VALUES ('53', '295');
INSERT INTO `uums_role_res` VALUES ('53', '296');
INSERT INTO `uums_role_res` VALUES ('53', '297');
INSERT INTO `uums_role_res` VALUES ('53', '298');
INSERT INTO `uums_role_res` VALUES ('54', '298');
INSERT INTO `uums_role_res` VALUES ('53', '299');
INSERT INTO `uums_role_res` VALUES ('54', '299');
INSERT INTO `uums_role_res` VALUES ('53', '301');
INSERT INTO `uums_role_res` VALUES ('53', '302');
INSERT INTO `uums_role_res` VALUES ('54', '302');
INSERT INTO `uums_role_res` VALUES ('53', '303');
INSERT INTO `uums_role_res` VALUES ('53', '304');
INSERT INTO `uums_role_res` VALUES ('54', '304');
INSERT INTO `uums_role_res` VALUES ('53', '305');
INSERT INTO `uums_role_res` VALUES ('54', '305');
INSERT INTO `uums_role_res` VALUES ('53', '307');
INSERT INTO `uums_role_res` VALUES ('53', '308');
INSERT INTO `uums_role_res` VALUES ('53', '310');
INSERT INTO `uums_role_res` VALUES ('53', '311');
INSERT INTO `uums_role_res` VALUES ('53', '312');
INSERT INTO `uums_role_res` VALUES ('54', '312');
INSERT INTO `uums_role_res` VALUES ('42', '313');
INSERT INTO `uums_role_res` VALUES ('53', '313');
INSERT INTO `uums_role_res` VALUES ('53', '314');
INSERT INTO `uums_role_res` VALUES ('54', '314');
INSERT INTO `uums_role_res` VALUES ('42', '315');
INSERT INTO `uums_role_res` VALUES ('53', '315');
INSERT INTO `uums_role_res` VALUES ('42', '316');
INSERT INTO `uums_role_res` VALUES ('53', '316');
INSERT INTO `uums_role_res` VALUES ('53', '318');
INSERT INTO `uums_role_res` VALUES ('54', '318');
INSERT INTO `uums_role_res` VALUES ('53', '319');
INSERT INTO `uums_role_res` VALUES ('42', '320');
INSERT INTO `uums_role_res` VALUES ('53', '320');
INSERT INTO `uums_role_res` VALUES ('42', '321');
INSERT INTO `uums_role_res` VALUES ('53', '321');
INSERT INTO `uums_role_res` VALUES ('53', '322');
INSERT INTO `uums_role_res` VALUES ('54', '322');
INSERT INTO `uums_role_res` VALUES ('42', '323');
INSERT INTO `uums_role_res` VALUES ('53', '323');
INSERT INTO `uums_role_res` VALUES ('53', '324');
INSERT INTO `uums_role_res` VALUES ('53', '325');
INSERT INTO `uums_role_res` VALUES ('53', '326');
INSERT INTO `uums_role_res` VALUES ('53', '327');
INSERT INTO `uums_role_res` VALUES ('54', '327');
INSERT INTO `uums_role_res` VALUES ('42', '335');
INSERT INTO `uums_role_res` VALUES ('54', '335');
INSERT INTO `uums_role_res` VALUES ('42', '339');
INSERT INTO `uums_role_res` VALUES ('54', '339');
INSERT INTO `uums_role_res` VALUES ('53', '350');
INSERT INTO `uums_role_res` VALUES ('53', '351');
INSERT INTO `uums_role_res` VALUES ('53', '352');
INSERT INTO `uums_role_res` VALUES ('42', '354');
INSERT INTO `uums_role_res` VALUES ('53', '354');
INSERT INTO `uums_role_res` VALUES ('42', '355');
INSERT INTO `uums_role_res` VALUES ('53', '355');
INSERT INTO `uums_role_res` VALUES ('42', '356');
INSERT INTO `uums_role_res` VALUES ('53', '356');
INSERT INTO `uums_role_res` VALUES ('42', '357');
INSERT INTO `uums_role_res` VALUES ('53', '357');
INSERT INTO `uums_role_res` VALUES ('42', '359');
INSERT INTO `uums_role_res` VALUES ('53', '359');
INSERT INTO `uums_role_res` VALUES ('42', '360');
INSERT INTO `uums_role_res` VALUES ('53', '360');
INSERT INTO `uums_role_res` VALUES ('42', '361');
INSERT INTO `uums_role_res` VALUES ('53', '361');
INSERT INTO `uums_role_res` VALUES ('42', '362');
INSERT INTO `uums_role_res` VALUES ('53', '362');
INSERT INTO `uums_role_res` VALUES ('42', '363');
INSERT INTO `uums_role_res` VALUES ('53', '363');
INSERT INTO `uums_role_res` VALUES ('42', '364');
INSERT INTO `uums_role_res` VALUES ('53', '364');
INSERT INTO `uums_role_res` VALUES ('42', '365');
INSERT INTO `uums_role_res` VALUES ('53', '365');
INSERT INTO `uums_role_res` VALUES ('42', '366');
INSERT INTO `uums_role_res` VALUES ('53', '366');
INSERT INTO `uums_role_res` VALUES ('42', '367');
INSERT INTO `uums_role_res` VALUES ('53', '367');
INSERT INTO `uums_role_res` VALUES ('42', '368');
INSERT INTO `uums_role_res` VALUES ('53', '368');
INSERT INTO `uums_role_res` VALUES ('42', '369');
INSERT INTO `uums_role_res` VALUES ('53', '369');
INSERT INTO `uums_role_res` VALUES ('42', '371');
INSERT INTO `uums_role_res` VALUES ('53', '371');
INSERT INTO `uums_role_res` VALUES ('54', '371');
INSERT INTO `uums_role_res` VALUES ('42', '372');
INSERT INTO `uums_role_res` VALUES ('53', '372');
INSERT INTO `uums_role_res` VALUES ('54', '372');
INSERT INTO `uums_role_res` VALUES ('42', '373');
INSERT INTO `uums_role_res` VALUES ('53', '373');
INSERT INTO `uums_role_res` VALUES ('54', '373');
INSERT INTO `uums_role_res` VALUES ('42', '374');
INSERT INTO `uums_role_res` VALUES ('53', '374');
INSERT INTO `uums_role_res` VALUES ('54', '374');
INSERT INTO `uums_role_res` VALUES ('42', '377');
INSERT INTO `uums_role_res` VALUES ('53', '377');
INSERT INTO `uums_role_res` VALUES ('54', '377');
INSERT INTO `uums_role_res` VALUES ('42', '378');
INSERT INTO `uums_role_res` VALUES ('53', '378');
INSERT INTO `uums_role_res` VALUES ('54', '378');
INSERT INTO `uums_role_res` VALUES ('42', '379');
INSERT INTO `uums_role_res` VALUES ('53', '379');
INSERT INTO `uums_role_res` VALUES ('54', '379');
INSERT INTO `uums_role_res` VALUES ('42', '380');
INSERT INTO `uums_role_res` VALUES ('53', '380');
INSERT INTO `uums_role_res` VALUES ('54', '380');
INSERT INTO `uums_role_res` VALUES ('42', '381');
INSERT INTO `uums_role_res` VALUES ('53', '381');
INSERT INTO `uums_role_res` VALUES ('54', '381');
INSERT INTO `uums_role_res` VALUES ('42', '382');
INSERT INTO `uums_role_res` VALUES ('53', '382');
INSERT INTO `uums_role_res` VALUES ('54', '382');
INSERT INTO `uums_role_res` VALUES ('42', '383');
INSERT INTO `uums_role_res` VALUES ('54', '383');
INSERT INTO `uums_role_res` VALUES ('42', '384');
INSERT INTO `uums_role_res` VALUES ('54', '384');
INSERT INTO `uums_role_res` VALUES ('42', '385');
INSERT INTO `uums_role_res` VALUES ('54', '385');
INSERT INTO `uums_role_res` VALUES ('42', '386');
INSERT INTO `uums_role_res` VALUES ('54', '386');
INSERT INTO `uums_role_res` VALUES ('42', '387');
INSERT INTO `uums_role_res` VALUES ('54', '387');
INSERT INTO `uums_role_res` VALUES ('42', '388');
INSERT INTO `uums_role_res` VALUES ('54', '388');
INSERT INTO `uums_role_res` VALUES ('42', '389');
INSERT INTO `uums_role_res` VALUES ('54', '389');
INSERT INTO `uums_role_res` VALUES ('53', '390');
INSERT INTO `uums_role_res` VALUES ('53', '395');
INSERT INTO `uums_role_res` VALUES ('54', '395');
INSERT INTO `uums_role_res` VALUES ('53', '402');
INSERT INTO `uums_role_res` VALUES ('54', '402');
INSERT INTO `uums_role_res` VALUES ('53', '405');
INSERT INTO `uums_role_res` VALUES ('54', '406');
INSERT INTO `uums_role_res` VALUES ('53', '407');
INSERT INTO `uums_role_res` VALUES ('53', '408');
INSERT INTO `uums_role_res` VALUES ('54', '410');
INSERT INTO `uums_role_res` VALUES ('54', '412');
INSERT INTO `uums_role_res` VALUES ('53', '413');
INSERT INTO `uums_role_res` VALUES ('54', '413');
INSERT INTO `uums_role_res` VALUES ('42', '414');
INSERT INTO `uums_role_res` VALUES ('99', '414');
INSERT INTO `uums_role_res` VALUES ('53', '415');
INSERT INTO `uums_role_res` VALUES ('54', '415');
INSERT INTO `uums_role_res` VALUES ('42', '416');
INSERT INTO `uums_role_res` VALUES ('99', '416');
INSERT INTO `uums_role_res` VALUES ('53', '417');
INSERT INTO `uums_role_res` VALUES ('54', '417');
INSERT INTO `uums_role_res` VALUES ('42', '418');
INSERT INTO `uums_role_res` VALUES ('99', '418');
INSERT INTO `uums_role_res` VALUES ('42', '419');
INSERT INTO `uums_role_res` VALUES ('99', '419');
INSERT INTO `uums_role_res` VALUES ('42', '421');
INSERT INTO `uums_role_res` VALUES ('99', '421');
INSERT INTO `uums_role_res` VALUES ('42', '422');
INSERT INTO `uums_role_res` VALUES ('99', '422');
INSERT INTO `uums_role_res` VALUES ('42', '423');
INSERT INTO `uums_role_res` VALUES ('99', '423');
INSERT INTO `uums_role_res` VALUES ('42', '424');
INSERT INTO `uums_role_res` VALUES ('99', '424');
INSERT INTO `uums_role_res` VALUES ('42', '425');
INSERT INTO `uums_role_res` VALUES ('99', '425');
INSERT INTO `uums_role_res` VALUES ('42', '426');
INSERT INTO `uums_role_res` VALUES ('99', '426');
INSERT INTO `uums_role_res` VALUES ('42', '427');
INSERT INTO `uums_role_res` VALUES ('99', '427');
INSERT INTO `uums_role_res` VALUES ('42', '428');
INSERT INTO `uums_role_res` VALUES ('99', '428');
INSERT INTO `uums_role_res` VALUES ('42', '429');
INSERT INTO `uums_role_res` VALUES ('99', '429');
INSERT INTO `uums_role_res` VALUES ('42', '430');
INSERT INTO `uums_role_res` VALUES ('99', '430');
INSERT INTO `uums_role_res` VALUES ('42', '431');
INSERT INTO `uums_role_res` VALUES ('99', '431');
INSERT INTO `uums_role_res` VALUES ('42', '432');
INSERT INTO `uums_role_res` VALUES ('99', '432');
INSERT INTO `uums_role_res` VALUES ('42', '433');
INSERT INTO `uums_role_res` VALUES ('99', '433');
INSERT INTO `uums_role_res` VALUES ('53', '434');
INSERT INTO `uums_role_res` VALUES ('53', '435');
INSERT INTO `uums_role_res` VALUES ('53', '436');
INSERT INTO `uums_role_res` VALUES ('53', '437');
INSERT INTO `uums_role_res` VALUES ('54', '438');
INSERT INTO `uums_role_res` VALUES ('53', '439');
INSERT INTO `uums_role_res` VALUES ('53', '440');
INSERT INTO `uums_role_res` VALUES ('53', '441');
INSERT INTO `uums_role_res` VALUES ('54', '441');
INSERT INTO `uums_role_res` VALUES ('53', '442');
INSERT INTO `uums_role_res` VALUES ('54', '442');
INSERT INTO `uums_role_res` VALUES ('53', '475');
INSERT INTO `uums_role_res` VALUES ('53', '476');
INSERT INTO `uums_role_res` VALUES ('53', '477');
INSERT INTO `uums_role_res` VALUES ('53', '478');
INSERT INTO `uums_role_res` VALUES ('53', '479');
INSERT INTO `uums_role_res` VALUES ('53', '480');
INSERT INTO `uums_role_res` VALUES ('53', '481');
INSERT INTO `uums_role_res` VALUES ('53', '482');
INSERT INTO `uums_role_res` VALUES ('53', '483');
INSERT INTO `uums_role_res` VALUES ('53', '484');
INSERT INTO `uums_role_res` VALUES ('42', '485');
INSERT INTO `uums_role_res` VALUES ('99', '485');
INSERT INTO `uums_role_res` VALUES ('54', '492');
INSERT INTO `uums_role_res` VALUES ('54', '493');
INSERT INTO `uums_role_res` VALUES ('54', '494');
INSERT INTO `uums_role_res` VALUES ('54', '495');
INSERT INTO `uums_role_res` VALUES ('54', '496');
INSERT INTO `uums_role_res` VALUES ('54', '497');
INSERT INTO `uums_role_res` VALUES ('54', '498');
INSERT INTO `uums_role_res` VALUES ('54', '499');
INSERT INTO `uums_role_res` VALUES ('54', '500');
INSERT INTO `uums_role_res` VALUES ('54', '501');
INSERT INTO `uums_role_res` VALUES ('54', '502');
INSERT INTO `uums_role_res` VALUES ('54', '503');
INSERT INTO `uums_role_res` VALUES ('54', '504');
INSERT INTO `uums_role_res` VALUES ('54', '505');
INSERT INTO `uums_role_res` VALUES ('54', '506');
INSERT INTO `uums_role_res` VALUES ('54', '507');
INSERT INTO `uums_role_res` VALUES ('54', '508');
INSERT INTO `uums_role_res` VALUES ('54', '509');
INSERT INTO `uums_role_res` VALUES ('54', '510');
INSERT INTO `uums_role_res` VALUES ('54', '511');
INSERT INTO `uums_role_res` VALUES ('42', '512');
INSERT INTO `uums_role_res` VALUES ('99', '512');
INSERT INTO `uums_role_res` VALUES ('42', '513');
INSERT INTO `uums_role_res` VALUES ('99', '513');
INSERT INTO `uums_role_res` VALUES ('54', '514');
INSERT INTO `uums_role_res` VALUES ('54', '515');
INSERT INTO `uums_role_res` VALUES ('54', '516');
INSERT INTO `uums_role_res` VALUES ('54', '517');
INSERT INTO `uums_role_res` VALUES ('54', '518');
INSERT INTO `uums_role_res` VALUES ('54', '519');
INSERT INTO `uums_role_res` VALUES ('54', '520');
INSERT INTO `uums_role_res` VALUES ('54', '521');
INSERT INTO `uums_role_res` VALUES ('54', '522');
INSERT INTO `uums_role_res` VALUES ('54', '523');
INSERT INTO `uums_role_res` VALUES ('54', '524');
INSERT INTO `uums_role_res` VALUES ('54', '525');
INSERT INTO `uums_role_res` VALUES ('54', '526');
INSERT INTO `uums_role_res` VALUES ('54', '527');
INSERT INTO `uums_role_res` VALUES ('54', '528');
INSERT INTO `uums_role_res` VALUES ('42', '540');
INSERT INTO `uums_role_res` VALUES ('99', '540');
INSERT INTO `uums_role_res` VALUES ('53', '542');
INSERT INTO `uums_role_res` VALUES ('53', '543');
INSERT INTO `uums_role_res` VALUES ('53', '544');
INSERT INTO `uums_role_res` VALUES ('53', '545');
INSERT INTO `uums_role_res` VALUES ('53', '546');
INSERT INTO `uums_role_res` VALUES ('53', '547');
INSERT INTO `uums_role_res` VALUES ('53', '548');
INSERT INTO `uums_role_res` VALUES ('53', '549');
INSERT INTO `uums_role_res` VALUES ('53', '550');
INSERT INTO `uums_role_res` VALUES ('53', '551');
INSERT INTO `uums_role_res` VALUES ('53', '552');
INSERT INTO `uums_role_res` VALUES ('53', '553');
INSERT INTO `uums_role_res` VALUES ('53', '554');
INSERT INTO `uums_role_res` VALUES ('53', '555');
INSERT INTO `uums_role_res` VALUES ('53', '556');
INSERT INTO `uums_role_res` VALUES ('53', '557');
INSERT INTO `uums_role_res` VALUES ('53', '558');
INSERT INTO `uums_role_res` VALUES ('53', '559');
INSERT INTO `uums_role_res` VALUES ('53', '560');
INSERT INTO `uums_role_res` VALUES ('53', '561');
INSERT INTO `uums_role_res` VALUES ('53', '562');
INSERT INTO `uums_role_res` VALUES ('53', '563');
INSERT INTO `uums_role_res` VALUES ('53', '564');
INSERT INTO `uums_role_res` VALUES ('53', '565');
INSERT INTO `uums_role_res` VALUES ('53', '566');
INSERT INTO `uums_role_res` VALUES ('53', '567');
INSERT INTO `uums_role_res` VALUES ('42', '579');
INSERT INTO `uums_role_res` VALUES ('42', '580');
INSERT INTO `uums_role_res` VALUES ('99', '580');

-- ----------------------------
-- Table structure for uums_user
-- ----------------------------
DROP TABLE IF EXISTS `uums_user`;
CREATE TABLE `uums_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户唯一标识，自增',
  `ORG_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：UUMS_ORG，外键字段：ID',
  `USER_CODE` char(10) NOT NULL DEFAULT '' COMMENT '用户编码，按编码规则生成',
  `USER_NAME` varchar(15) DEFAULT NULL COMMENT '用户名',
  `USER_PWD` char(32) NOT NULL DEFAULT '000000' COMMENT '密码，加密值',
  `NICKNAME` varchar(10) DEFAULT NULL COMMENT '昵称',
  `AVATAR` varchar(5000) DEFAULT NULL COMMENT '头像，Base64',
  `NAME` varchar(10) DEFAULT NULL COMMENT '姓名',
  `SEX` tinyint(1) DEFAULT NULL COMMENT '性别',
  `BIRTHDAY` date DEFAULT NULL COMMENT '生日',
  `NATIVE_PLACE` varchar(50) DEFAULT NULL COMMENT '籍贯',
  `IDNO` char(18) DEFAULT NULL COMMENT '身份证号',
  `ADDRESS` varchar(50) DEFAULT NULL COMMENT '住址',
  `MOBILE` char(15) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮箱，唯一',
  `WECHAT` varchar(30) DEFAULT NULL COMMENT '微信号，唯一，关联登录',
  `QQ` varchar(15) DEFAULT NULL COMMENT 'QQ号，唯一，关联登录',
  `SOURCE` tinyint(1) NOT NULL DEFAULT '0' COMMENT '来源，1-运营管理系统，2-门户，3-微信，4-APP，5-其他',
  `FLAG` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户状态，1-正常，0-停用',
  `IS_DEL` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，1-删除，0-不删除',
  `CREATE_TIME` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '注册时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ID`),
  KEY `FK_USER_ORG` (`ORG_ID`),
  CONSTRAINT `FK_USER_ORG` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1041 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_user
-- ----------------------------
INSERT INTO `uums_user` VALUES ('1', '0', 'G000000037', 'admin', '72bada123e5189df7bb1080bb264300b', 'ad', '1', 'ad', '1', '2017-07-14', '2134', '131102199809087089', '家庭地址不能少于10个字符', '15539328198', '132132132@qq.com', 'weixingdfadjkflej', '132132132', '1', '1', '0', '2017-07-14 16:05:18', '2017-07-19 10:05:44');
INSERT INTO `uums_user` VALUES ('1006', '2', 'Y000000126', 'YLYSHLZG', '72bada123e5189df7bb1080bb264300b', '主管', null, '主管', '1', '2018-03-07', '北京市昌平区霍营1号楼', '311111111111111111', '北京市昌平区霍营1号楼', '18111111111', '123123123@QQ.COM', 'weixin1', '123123123', '1', '1', '1', '2018-03-07 11:25:06', '2018-05-03 11:37:33');
INSERT INTO `uums_user` VALUES ('1007', '2', 'Y000000127', 'YLYSADMIN', '72bada123e5189df7bb1080bb264300b', 'SADMIN', null, '三三', '1', '2018-03-07', '北京市昌平区霍营1号楼', '311111111111111112', '北京市昌平区霍营1号楼', '18111111112', '123123123@QQ.COM', 'weixin1', '123123123', '1', '1', '1', '2018-03-07 11:26:09', '2018-03-07 11:45:42');
INSERT INTO `uums_user` VALUES ('1008', '2', 'Y000000128', 'YLYSBGSZR', '72bada123e5189df7bb1080bb264300b', 'SBGSZR', null, '三办', '1', '2018-03-07', '北京市昌平区霍营1号楼', '311111111111111113', '北京市昌平区霍营1号楼', '18111111113', '123123123@QQ.COM', 'weixin1', '123123123', '1', '1', '1', '2018-03-07 11:27:03', '2018-05-03 11:37:41');
INSERT INTO `uums_user` VALUES ('1021', '1', 'Y000000131', 'chenlei', '72bada123e5189df7bb1080bb264300b', '', null, '陈磊', '1', '1989-03-13', '北京市昌平区', '220301198903130018', '', '13473458706', '', '', '', '1', '1', '0', '2018-03-13 09:38:12', '2018-03-13 09:38:19');
INSERT INTO `uums_user` VALUES ('1022', '1', 'Y000000132', 'zhujie', '72bada123e5189df7bb1080bb264300b', '', null, '朱杰', '1', '1991-08-23', '北京市昌平区', '13010119910823002X', '', '18631892217', '', '', '', '1', '1', '0', '2018-03-13 09:39:35', '2018-03-13 09:40:19');
INSERT INTO `uums_user` VALUES ('1023', '1', 'C000000585', 'sxr585', '72bada123e5189df7bb1080bb264300b', null, null, '宋欣荣', '2', null, '北京 市辖区 东城区 ', '110101196205014831', '北京 市辖区 东城区 ', '17600060666', null, null, null, '1', '1', '0', '2018-03-13 10:02:03', '2018-03-13 14:53:30');
INSERT INTO `uums_user` VALUES ('1024', '1', 'C000000586', 'wwg586', '72bada123e5189df7bb1080bb264300b', null, null, '王卫国', '1', '1950-05-05', '北京', '110106195005058618', '北京市昌平区北七家镇平西王府村', '15632251252', null, null, null, '1', '1', '0', '2018-03-13 14:48:46', '2018-03-13 14:53:17');
INSERT INTO `uums_user` VALUES ('1025', '125', 'E000000077', '15101023001', '72bada123e5189df7bb1080bb264300b', null, null, '王鹏飞', '0', null, null, null, null, '15101023001', null, null, null, '1', '1', '0', '2018-03-13 15:00:37', '2018-03-13 15:00:37');
INSERT INTO `uums_user` VALUES ('1026', '126', 'E000000078', '15201023002', '72bada123e5189df7bb1080bb264300b', null, null, '邢世莹', '0', null, null, null, null, '15201023002', null, null, null, '1', '1', '0', '2018-03-13 15:01:13', '2018-03-13 15:01:13');
INSERT INTO `uums_user` VALUES ('1027', '126', 'E000000079', '15101023003', '72bada123e5189df7bb1080bb264300b', null, null, '马睿', '0', null, null, null, null, '15101023003', null, null, null, '1', '1', '0', '2018-03-13 15:03:15', '2018-03-13 15:03:15');
INSERT INTO `uums_user` VALUES ('1028', '126', 'E000000080', '15201023004', '72bada123e5189df7bb1080bb264300b', null, null, '师兴文', '0', null, null, null, null, '15201023004', null, null, null, '1', '1', '0', '2018-03-13 15:04:36', '2018-03-13 15:04:36');
INSERT INTO `uums_user` VALUES ('1029', '126', 'E000000081', '15201023005', '72bada123e5189df7bb1080bb264300b', null, null, '吉兴贤', '0', null, null, null, null, '15201023005', null, null, null, '1', '1', '0', '2018-03-13 15:05:25', '2018-03-13 15:05:25');
INSERT INTO `uums_user` VALUES ('1030', '126', 'E000000082', '15201023006', '72bada123e5189df7bb1080bb264300b', null, null, '祖秋白', '0', null, null, null, null, '15201023006', null, null, null, '1', '1', '0', '2018-03-13 15:06:11', '2018-03-13 15:06:11');
INSERT INTO `uums_user` VALUES ('1031', '126', 'E000000083', '15101023007', '72bada123e5189df7bb1080bb264300b', null, null, '元天睿', '0', null, null, null, null, '15101023007', null, null, null, '1', '1', '0', '2018-03-13 15:07:43', '2018-03-13 15:07:43');
INSERT INTO `uums_user` VALUES ('1032', '1', 'C000000587', '587', '72bada123e5189df7bb1080bb264300b', null, null, '石光荣', '1', null, '河北', '110106193007062494', '北京市西城区', '18922231643', null, null, null, '1', '1', '0', '2018-03-13 15:14:23', '2018-03-13 15:17:37');
INSERT INTO `uums_user` VALUES ('1033', '1', 'C000000588', '褚q588', '72bada123e5189df7bb1080bb264300b', null, null, '褚琴', '2', null, '', '110102195801019366', '北京市昌平区沙河镇于辛庄村', '15912135431', null, null, null, '1', '1', '0', '2018-03-13 15:40:50', '2018-03-13 15:41:44');
INSERT INTO `uums_user` VALUES ('1034', '1', 'C000000589', 'ydh589', '72bada123e5189df7bb1080bb264300b', null, null, '杨大海', '1', null, '', '110102195301011903', '北京市海淀区', '13313455463', null, null, null, '1', '1', '0', '2018-03-13 16:17:16', '2018-03-13 16:18:03');
INSERT INTO `uums_user` VALUES ('1035', '1', 'C000000590', 'cj590', '72bada123e5189df7bb1080bb264300b', null, null, '陈健', '1', null, '', '110102195801011823', '北京市昌平区', '15632255435', null, null, null, '1', '1', '0', '2018-03-13 16:53:16', '2018-03-13 16:54:04');
INSERT INTO `uums_user` VALUES ('1036', '1', 'C000000591', 'jt591', '72bada123e5189df7bb1080bb264300b', null, null, '江涛', '1', null, '', '110102195104052367', '北京市', '15632252315', null, null, null, '1', '1', '0', '2018-03-13 16:55:30', '2018-03-13 16:56:17');
INSERT INTO `uums_user` VALUES ('1037', '125', 'Y000000133', 'yangguo', '72bada123e5189df7bb1080bb264300b', '', null, '杨过', '1', null, '', '', '', '15101033008', '', '', '', '1', '1', '0', '2018-03-13 20:18:41', '2018-04-04 17:41:22');
INSERT INTO `uums_user` VALUES ('1038', '1', 'C000000592', 'fjj592', '72bada123e5189df7bb1080bb264300b', null, null, '冯建军', '1', null, '北京市昌平区', '110114196303140040', '北京市昌平区', '13673687689', null, null, null, '1', '1', '0', '2018-03-14 15:37:27', '2018-05-23 18:45:38');
INSERT INTO `uums_user` VALUES ('1039', '2', 'Y000000134', 'hlzg', '72bada123e5189df7bb1080bb264300b', '护理主管', null, '护理主管', '1', '2018-05-03', '北京', '', '', '15100000001', '', '', '', '1', '1', '0', '2018-05-03 11:39:41', null);
INSERT INTO `uums_user` VALUES ('1040', '1', 'C000000593', 'lyp593', '72bada123e5189df7bb1080bb264300b', null, null, '李亚鹏', '1', null, '', '110224198105111578', '北京市昌平区', '13044678971', null, null, null, '1', '1', '0', '2018-05-23 18:54:56', '2018-05-23 18:55:25');

-- ----------------------------
-- Table structure for uums_user_code
-- ----------------------------
DROP TABLE IF EXISTS `uums_user_code`;
CREATE TABLE `uums_user_code` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_TYPE` char(1) DEFAULT NULL,
  `USER_CODE` int(9) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_user_code
-- ----------------------------
INSERT INTO `uums_user_code` VALUES ('1', 'C', '594');
INSERT INTO `uums_user_code` VALUES ('2', 'Y', '135');
INSERT INTO `uums_user_code` VALUES ('3', 'S', '94');
INSERT INTO `uums_user_code` VALUES ('4', 'W', '19');
INSERT INTO `uums_user_code` VALUES ('5', 'P', '46');
INSERT INTO `uums_user_code` VALUES ('6', 'G', '4');
INSERT INTO `uums_user_code` VALUES ('7', 'Z', '1');
INSERT INTO `uums_user_code` VALUES ('8', 'E', '84');

-- ----------------------------
-- Table structure for uums_user_role
-- ----------------------------
DROP TABLE IF EXISTS `uums_user_role`;
CREATE TABLE `uums_user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FK_ju2nns9b2kdmm2c8gvsf1l50a` (`role_id`),
  CONSTRAINT `FK_ju2nns9b2kdmm2c8gvsf1l50a` FOREIGN KEY (`role_id`) REFERENCES `uums_role` (`ID`),
  CONSTRAINT `FK_s3smem1xmms3m388dg8qdm62p` FOREIGN KEY (`user_id`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_user_role
-- ----------------------------
INSERT INTO `uums_user_role` VALUES ('1', '42');
INSERT INTO `uums_user_role` VALUES ('1006', '53');
INSERT INTO `uums_user_role` VALUES ('1021', '53');
INSERT INTO `uums_user_role` VALUES ('1037', '53');
INSERT INTO `uums_user_role` VALUES ('1008', '54');
INSERT INTO `uums_user_role` VALUES ('1022', '54');

-- ----------------------------
-- View structure for his_bed_use_info_view
-- ----------------------------
DROP VIEW IF EXISTS `his_bed_use_info_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_bed_use_info_view` AS (select `hb`.`ID` AS `ID`,`hb`.`BED_NO` AS `BED_NO`,`hb`.`FLAG` AS `FLAG`,`hb`.`REGION_ID` AS `REGION_ID`,`hm`.`ID` AS `MEMBER_ID`,`hm`.`NAME` AS `NAME`,`hm`.`SEX` AS `SEX`,`hm`.`AGE` AS `AGE`,`hvs`.`BLOOD_PRESSURE_HIGH` AS `BLOOD_PRESSURE_HIGH`,`hvs`.`BLOOD_PRESSURE_LOW` AS `BLOOD_PRESSURE_LOW`,`hvs`.`BLOOD_SUGAR` AS `BLOOD_SUGAR`,`hvs`.`BODY_POSITION` AS `BODY_POSITION`,`hvs`.`BREATHE` AS `BREATHE`,`hvs`.`PULSE` AS `PULSE`,`hc`.`CHECKIN_DATE` AS `CHECKIN_DATE`,`huu`.`ORG_ID` AS `ORG_ID` from (((((((`his_bed` `hb` left join `his_bed_use` `hbu` on((`hb`.`ID` = `hbu`.`BED_ID`))) left join `his_member` `hm` on((`hbu`.`MEMBER_ID` = `hm`.`ID`))) left join `his_select_maxid_vital_signs_baseview` `hsmvsb` on((`hsmvsb`.`MEMBER_ID` = `hm`.`ID`))) left join `his_vital_signs` `hvs` on((`hvs`.`ID` = `hsmvsb`.`ID`))) left join `his_maxid_charge_view` `hmcv` on((`hmcv`.`MEMBER_ID` = `hm`.`ID`))) left join `his_charge` `hc` on((`hc`.`ID` = `hmcv`.`ID`))) left join `uums_user` `huu` on((`huu`.`ID` = `hb`.`CREATOR`)))) ;

-- ----------------------------
-- View structure for his_blood_pressure_warning_view
-- ----------------------------
DROP VIEW IF EXISTS `his_blood_pressure_warning_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_blood_pressure_warning_view` AS (select `hvs2`.`ID` AS `ID`,`hvs2`.`MEMBER_ID` AS `MEMBER_ID`,`uu`.`ORG_ID` AS `ORG_ID` from ((`his_vital_signs` `hvs2` left join `uums_user` `uu` on((`uu`.`ID` = `hvs2`.`CREATOR`))) join `his_select_maxid_vital_signs_baseview` `a` on(((`hvs2`.`ID` = `a`.`ID`) and ((`hvs2`.`BLOOD_PRESSURE_HIGH` < 100) or (`hvs2`.`BLOOD_PRESSURE_HIGH` > 160) or (`hvs2`.`BLOOD_PRESSURE_LOW` < 60) or (`hvs2`.`BLOOD_PRESSURE_LOW` > 100)))))) ;

-- ----------------------------
-- View structure for his_body_position_warning_view
-- ----------------------------
DROP VIEW IF EXISTS `his_body_position_warning_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_body_position_warning_view` AS (select `hvs2`.`ID` AS `ID`,`hvs2`.`MEMBER_ID` AS `MEMBER_ID`,`uu`.`ORG_ID` AS `ORG_ID` from ((`his_vital_signs` `hvs2` left join `uums_user` `uu` on((`uu`.`ID` = `hvs2`.`CREATOR`))) join `his_select_maxid_vital_signs_baseview` `a` on(((`hvs2`.`ID` = `a`.`ID`) and ((`hvs2`.`BODY_POSITION` < 35) or (`hvs2`.`BODY_POSITION` > 37.5)))))) ;

-- ----------------------------
-- View structure for his_consult_view
-- ----------------------------
DROP VIEW IF EXISTS `his_consult_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_consult_view` AS (select `hc`.`ID` AS `ID`,`hc`.`NAME` AS `NAME`,`hc`.`MOBILE` AS `MOBILE`,`hc`.`RECEIVER` AS `RECEIVER`,`hc`.`CHECK_INTENTION` AS `CHECK_INTENTION`,`hc`.`FLAG` AS `FLAG`,`hc`.`CREATE_TIME` AS `CREATE_TIME`,`uu`.`ORG_ID` AS `ORG_ID` from (`his_consult` `hc` left join `uums_user` `uu` on((`hc`.`CREATOR` = `uu`.`ID`)))) ;

-- ----------------------------
-- View structure for his_employe_duty_area_view
-- ----------------------------
DROP VIEW IF EXISTS `his_employe_duty_area_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_employe_duty_area_view` AS (select `a`.`ID` AS `EID`,`a`.`USER_ID` AS `USER_ID`,`uu2`.`NAME` AS `EMPNAME`,`a`.`EMPNO` AS `EMPNO`,`a`.`FLAG` AS `FLAG`,`b`.`ID` AS `ID`,`b`.`EMPLOYE_ID` AS `EMPLOYE_ID`,`b`.`DUTY_AREA_ID` AS `DUTY_AREA_ID`,`b`.`BEDS` AS `BEDS`,`b`.`CREATOR` AS `CREATOR`,`uu2`.`ORG_ID` AS `ORG_ID`,`b`.`CREATE_TIME` AS `CREATE_TIME`,`b`.`UPDATE_TIME` AS `UPDATE_TIME`,`c`.`AREA_NAME` AS `AREA_NAME`,`c`.`REGIONS` AS `REGIONS` from ((((`his_employe` `a` left join `uums_user` `uu2` on((`a`.`USER_ID` = `uu2`.`ID`))) left join `his_employe_duty_area` `b` on((`a`.`ID` = `b`.`EMPLOYE_ID`))) left join `dic_duty_area` `c` on((`b`.`DUTY_AREA_ID` = `c`.`ID`))) left join `uums_user` `uu` on((`b`.`CREATOR` = `uu`.`ID`)))) ;

-- ----------------------------
-- View structure for his_excretion_warning_view
-- ----------------------------
DROP VIEW IF EXISTS `his_excretion_warning_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_excretion_warning_view` AS (select `hlc2`.`ID` AS `ID`,`hlc2`.`MEMBER_ID` AS `MEMBER_ID`,`uu`.`ORG_ID` AS `ORG_ID` from ((`his_life_care` `hlc2` left join `uums_user` `uu` on((`uu`.`ID` = `hlc2`.`CREATOR`))) join `his_select_maxid_life_care_baseview` `a` on(((`hlc2`.`ID` = `a`.`ID`) and (`hlc2`.`EXCRETION_COUNT` <= -(3)))))) ;

-- ----------------------------
-- View structure for his_incidental_view
-- ----------------------------
DROP VIEW IF EXISTS `his_incidental_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_incidental_view` AS (select `hi`.`ID` AS `ID`,`hi`.`MEMBER_ID` AS `MEMBER_ID`,`hi`.`TITLE` AS `TITLE`,`hi`.`CHARGE` AS `CHARGE`,`hi`.`SERVICE_STAFF` AS `SERVICE_STAFF`,`hi`.`REMARK` AS `REMARK`,`hi`.`SERVICE_DATE` AS `SERVICE_DATE`,`hi`.`CREATOR` AS `CREATOR`,`hi`.`CREATE_TIME` AS `CREATE_TIME`,`hi`.`UPDATE_TIME` AS `UPDATE_TIME`,`hb`.`BED_NO` AS `BED_NO`,`hm`.`NAME` AS `MEMBER_NAME`,`uu`.`ORG_ID` AS `ORG_ID`,`uu`.`NAME` AS `USER_NAME`,`hb`.`ID` AS `BED_ID`,`hb`.`REGION_ID` AS `REGION_ID` from (((((`his_incidental` `hi` left join `his_member` `hm` on((`hi`.`MEMBER_ID` = `hm`.`ID`))) left join `his_bed_use` `hbu` on((`hi`.`MEMBER_ID` = `hbu`.`MEMBER_ID`))) left join `his_bed` `hb` on((`hbu`.`BED_ID` = `hb`.`ID`))) left join `uums_user` `uu` on((`hi`.`CREATOR` = `uu`.`ID`))) left join `dic_bed_region` `dbr` on((`hb`.`REGION_ID` = `dbr`.`id`)))) ;

-- ----------------------------
-- View structure for his_life_care_view
-- ----------------------------
DROP VIEW IF EXISTS `his_life_care_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_life_care_view` AS (select `hlc`.`ID` AS `ID`,`hlc`.`WATER_INTAKE_SUM` AS `WATER_INTAKE_SUM`,`hlc`.`EXCRETION_COUNT` AS `EXCRETION_COUNT`,`hlc`.`BATH_COUNT` AS `BATH_COUNT`,`hlc`.`FLAG` AS `FLAG`,`hlc`.`CREATE_TIME` AS `CREATE_TIME`,`hlc`.`UPDATE_TIME` AS `UPDATE_TIME`,`hlc`.`RECORD_TIME` AS `RECORD_TIME`,`hlc`.`BED_ID` AS `BED_ID`,`hb`.`BED_NO` AS `BED_NO`,`hb`.`REGION_ID` AS `REGION_ID`,`dbr`.`FULLNAME` AS `FULLNAME`,`hlc`.`MEMBER_ID` AS `MEMBER_ID`,`hm`.`NAME` AS `NAME`,`hlc`.`CREATOR` AS `CREATOR_ID`,`uu`.`NAME` AS `CREATOR`,`uu`.`ORG_ID` AS `ORG_ID` from ((((`his_life_care` `hlc` left join `his_bed` `hb` on((`hlc`.`BED_ID` = `hb`.`ID`))) left join `his_member` `hm` on((`hlc`.`MEMBER_ID` = `hm`.`ID`))) left join `uums_user` `uu` on((`hlc`.`CREATOR` = `uu`.`ID`))) left join `dic_bed_region` `dbr` on((`hb`.`REGION_ID` = `dbr`.`id`)))) ;

-- ----------------------------
-- View structure for his_maxid_charge_view
-- ----------------------------
DROP VIEW IF EXISTS `his_maxid_charge_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_maxid_charge_view` AS (select max(`hc`.`ID`) AS `ID`,`hc`.`MEMBER_ID` AS `MEMBER_ID` from `his_charge` `hc` group by `hc`.`MEMBER_ID`) ;

-- ----------------------------
-- View structure for his_medication_check_detail_view
-- ----------------------------
DROP VIEW IF EXISTS `his_medication_check_detail_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_medication_check_detail_view` AS (select `his_medication_check_detail`.`Id` AS `ID`,`his_medication_check_detail`.`MEDICATION_CHECK_ID` AS `MEDICATION_CHECK_ID`,`his_medication_check_detail`.`DRUG_NAME` AS `DRUG_NAME`,`his_medication_check_detail`.`DOSAGE` AS `DOSAGE`,`his_medication_check_detail`.`DRUG_QUANTITY` AS `DRUG_QUANTITY`,`his_medication_check_detail`.`QUANTITY_UNIT` AS `QUANTITY_UNIT`,`his_medication_check_detail`.`DRUG_FUNCTION` AS `DRUG_FUNCTION`,`his_medication_check_detail`.`DRUG_COLOR` AS `DRUG_COLOR`,`his_medication_check_detail`.`flag` AS `FLAG` from `his_medication_check_detail`) ;

-- ----------------------------
-- View structure for his_member_bed_region_view
-- ----------------------------
DROP VIEW IF EXISTS `his_member_bed_region_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_bed_region_view` AS (select `hm`.`ID` AS `ID`,`hm`.`NAME` AS `NAME`,`hb`.`ID` AS `BED_ID`,`hb`.`BED_NO` AS `BED_NO`,`uu`.`ORG_ID` AS `ORG_ID`,`dbr`.`id` AS `REGION_ID`,`dbr`.`FULLNAME` AS `FULLNAME` from ((((`his_bed_use` `hbu` left join `his_member` `hm` on((`hbu`.`MEMBER_ID` = `hm`.`ID`))) left join `his_bed` `hb` on((`hbu`.`BED_ID` = `hb`.`ID`))) left join `dic_bed_region` `dbr` on((`hb`.`REGION_ID` = `dbr`.`id`))) left join `uums_user` `uu` on((`hb`.`CREATOR` = `uu`.`ID`))) order by `hm`.`ID` desc) ;

-- ----------------------------
-- View structure for his_member_charge_baseview
-- ----------------------------
DROP VIEW IF EXISTS `his_member_charge_baseview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_charge_baseview` AS (select `hm`.`ID` AS `ID`,`hm`.`NAME` AS `NAME`,`hm`.`MOBILE` AS `MOBILE`,`hm`.`FLAG` AS `FLAG`,`hm`.`HAVE_CONTRACT` AS `HAVE_CONTRACT`,max(`hc`.`ID`) AS `CHARGE_ID` from (`his_member` `hm` left join `his_charge` `hc` on((`hm`.`ID` = `hc`.`MEMBER_ID`))) where (`hm`.`FLAG` in (8,9,10,11,1)) group by `hm`.`ID` order by `CHARGE_ID`) ;

-- ----------------------------
-- View structure for his_member_charge_view
-- ----------------------------
DROP VIEW IF EXISTS `his_member_charge_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_charge_view` AS (select distinct `hm`.`ID` AS `ID`,`hm`.`NAME` AS `NAME`,`hm`.`MOBILE` AS `MOBILE`,`hm`.`FLAG` AS `FLAG`,`hm`.`HAVE_CONTRACT` AS `HAVE_CONTRACT`,`hb`.`ID` AS `BED_ID`,`hb`.`BED_NO` AS `BED_NO`,`uu`.`ORG_ID` AS `ORG_ID` from (((`his_member` `hm` left join `his_bed_use` `hbu` on((`hm`.`ID` = `hbu`.`MEMBER_ID`))) left join `his_bed` `hb` on((`hbu`.`BED_ID` = `hb`.`ID`))) left join `uums_user` `uu` on((`hm`.`USER_ID` = `uu`.`ID`))) where (`hm`.`FLAG` in (8,9,10,11,1))) ;

-- ----------------------------
-- View structure for his_member_checkup_view
-- ----------------------------
DROP VIEW IF EXISTS `his_member_checkup_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_checkup_view` AS (select `his_member_checkup`.`ID` AS `ID`,`his_member_checkup`.`MEMBER_ID` AS `MEMBER_ID`,`his_member_checkup`.`FLAG` AS `FLAG` from `his_member_checkup`) ;

-- ----------------------------
-- View structure for his_member_user_org_view
-- ----------------------------
DROP VIEW IF EXISTS `his_member_user_org_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_user_org_view` AS (select `hm`.`ID` AS `ID`,`hm`.`NAME` AS `NAME`,`hm`.`FLAG` AS `FLAG`,`uu`.`ID` AS `USER_ID`,`uo`.`ID` AS `ORG_ID` from ((`his_member` `hm` left join `uums_user` `uu` on((`hm`.`USER_ID` = `uu`.`ID`))) left join `uums_org` `uo` on((`uu`.`ORG_ID` = `uo`.`ID`)))) ;

-- ----------------------------
-- View structure for his_member_view
-- ----------------------------
DROP VIEW IF EXISTS `his_member_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_member_view` AS (select `hm`.`ID` AS `ID`,`hm`.`NAME` AS `NAME`,`hm`.`SEX` AS `SEX`,`hm`.`AGE` AS `AGE`,`hm`.`ADDRESS` AS `ADDRESS`,`hm`.`MOBILE` AS `MOBILE`,`hm`.`CERTIFICATE_CLASS` AS `CERTIFICATE_CLASS`,`hm`.`CERTIFICATE_NUMBER` AS `CERTIFICATE_NUMBER`,`hm`.`FLAG` AS `FLAG`,`hm`.`EVALUATE_TIME` AS `EVALUATE_TIME`,`hm`.`CREATE_TIME` AS `CREATE_TIME`,`uu`.`ORG_ID` AS `ORG_ID` from (`his_member` `hm` left join `uums_user` `uu` on((`hm`.`USER_ID` = `uu`.`ID`)))) ;

-- ----------------------------
-- View structure for his_notice_attachment_view
-- ----------------------------
DROP VIEW IF EXISTS `his_notice_attachment_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_notice_attachment_view` AS (select distinct `hna`.`ID` AS `ID`,`hna`.`NOTICE_ID` AS `NOTICE_ID`,`hna`.`ATTACHMENT_ID` AS `ATTACHMENT_ID`,`ha`.`FILE_NAME` AS `FILE_NAME`,`ha`.`FILE_PATH` AS `FILE_PATH`,`ha`.`FILE_SIZE` AS `FILE_SIZE`,`ha`.`FILE_TYPE` AS `FILE_TYPE` from (`his_notice_attachment` `hna` left join `his_attachment` `ha` on((`hna`.`ATTACHMENT_ID` = `ha`.`Id`)))) ;

-- ----------------------------
-- View structure for his_notice_receiver_view
-- ----------------------------
DROP VIEW IF EXISTS `his_notice_receiver_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_notice_receiver_view` AS (select distinct `hn`.`ID` AS `ID`,`hn`.`TITLE` AS `TITLE`,`hn`.`NOTICE_WAY` AS `NOTICE_WAY`,`hn`.`FLAG` AS `FLAG`,`hnp`.`ID` AS `PROCESS_ID`,`hnp`.`RECEIVER` AS `RECEIVER_ID`,`hnp`.`RECEIVE_TIME` AS `RECEIVE_TIME`,`hnp`.`SENDER` AS `SENDER_ID`,`hnp`.`SEND_TIME` AS `SEND_TIME` from (((`his_notice` `hn` left join `his_notice_process` `hnp` on((`hn`.`ID` = `hnp`.`NOTICE_ID`))) left join `uums_user` `uu1` on((`hnp`.`SENDER` = `uu1`.`ID`))) left join `uums_user` `uu2` on((`hnp`.`RECEIVER` = `uu2`.`ID`)))) ;

-- ----------------------------
-- View structure for his_notice_sender_view
-- ----------------------------
DROP VIEW IF EXISTS `his_notice_sender_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_notice_sender_view` AS (select distinct `hn`.`ID` AS `ID`,`hn`.`TITLE` AS `TITLE`,`hn`.`NOTICE_WAY` AS `NOTICE_WAY`,`hn`.`FLAG` AS `FLAG`,`hnp`.`SENDER` AS `SENDER_ID`,`hnp`.`SEND_TIME` AS `SEND_TIME`,`hnp`.`RECEIVE_TIME` AS `RECEIVE_TIME` from ((`his_notice` `hn` left join `his_notice_process` `hnp` on((`hn`.`ID` = `hnp`.`NOTICE_ID`))) left join `uums_user` `uu1` on((`hnp`.`SENDER` = `uu1`.`ID`)))) ;

-- ----------------------------
-- View structure for his_nursing_record_view
-- ----------------------------
DROP VIEW IF EXISTS `his_nursing_record_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_nursing_record_view` AS (select `hncr`.`ID` AS `ID`,`hncr`.`BED_ID` AS `BED_ID`,`hncr`.`MEMBER_ID` AS `MEMBER_ID`,`hncr`.`REMARK` AS `REMARK`,`hncr`.`CREATOR` AS `CREATOR`,`hncr`.`CREATE_TIME` AS `CREATE_TIME`,`hncr`.`UPDATE_TIME` AS `UPDATE_TIME`,`hncr`.`RECORD_TIME` AS `RECORD_TIME`,`hb`.`BED_NO` AS `BED_NO`,`hm`.`NAME` AS `NAME`,`uu`.`NAME` AS `USERNAME`,`uu`.`ORG_ID` AS `ORG_ID` from (((`his_nursing_care_record` `hncr` left join `his_bed` `hb` on((`hncr`.`BED_ID` = `hb`.`ID`))) left join `his_member` `hm` on((`hncr`.`MEMBER_ID` = `hm`.`ID`))) left join `uums_user` `uu` on((`hncr`.`CREATOR` = `uu`.`ID`)))) ;

-- ----------------------------
-- View structure for his_select_maxid_life_care_baseview
-- ----------------------------
DROP VIEW IF EXISTS `his_select_maxid_life_care_baseview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_select_maxid_life_care_baseview` AS (select max(`hlc1`.`ID`) AS `ID` from `his_life_care` `hlc1` group by `hlc1`.`MEMBER_ID`) ;

-- ----------------------------
-- View structure for his_select_maxid_vital_signs_baseview
-- ----------------------------
DROP VIEW IF EXISTS `his_select_maxid_vital_signs_baseview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_select_maxid_vital_signs_baseview` AS (select max(`hvs1`.`ID`) AS `ID`,`hvs1`.`MEMBER_ID` AS `MEMBER_ID` from `his_vital_signs` `hvs1` group by `hvs1`.`MEMBER_ID`) ;

-- ----------------------------
-- View structure for his_shift_book_count_view
-- ----------------------------
DROP VIEW IF EXISTS `his_shift_book_count_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_shift_book_count_view` AS (select `dbr`.`id` AS `ID`,`dbr`.`REGION_NAME` AS `REGION_NAME`,`hsb`.`create_time` AS `CREATE_TIME` from ((`his_shift_book` `hsb` left join `his_bed` `hb` on((`hsb`.`bed_id` = `hb`.`ID`))) left join `dic_bed_region` `dbr` on((`hb`.`REGION_ID` = `dbr`.`id`)))) ;

-- ----------------------------
-- View structure for his_turn_over_record_view
-- ----------------------------
DROP VIEW IF EXISTS `his_turn_over_record_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_turn_over_record_view` AS (select `ht`.`ID` AS `ID`,`ht`.`IS_TURN_OVER` AS `IS_TURN_OVER`,`ht`.`TURN_OVER_TIME` AS `TURN_OVER_TIME`,`ht`.`FLAG` AS `FLAG`,`ht`.`CREATE_TIME` AS `CREATE_TIME`,`ht`.`UPDATE_TIME` AS `UPDATE_TIME`,`ht`.`BED_ID` AS `BED_ID`,`hb`.`BED_NO` AS `BED_NO`,`ht`.`MEMBER_ID` AS `MEMBER_ID`,`hm`.`NAME` AS `NAME`,`ht`.`PRINCIPAL` AS `PRINCIPAL_ID`,`uu1`.`NAME` AS `PRINCIPAL`,`ht`.`CREATOR` AS `CREATOR_ID`,`uu2`.`NAME` AS `CREATOR`,`uu2`.`ORG_ID` AS `ORG_ID` from ((((`his_turn_over_record` `ht` left join `his_bed` `hb` on((`ht`.`BED_ID` = `hb`.`ID`))) left join `his_member` `hm` on((`ht`.`MEMBER_ID` = `hm`.`ID`))) left join `uums_user` `uu1` on((`ht`.`PRINCIPAL` = `uu1`.`ID`))) left join `uums_user` `uu2` on((`ht`.`CREATOR` = `uu2`.`ID`)))) ;

-- ----------------------------
-- View structure for his_user_res_view
-- ----------------------------
DROP VIEW IF EXISTS `his_user_res_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_user_res_view` AS (select distinct `ur`.`ID` AS `ID`,`ur`.`IS_MENU` AS `IS_MENU`,`ur`.`PARENT_ID` AS `PARENT_ID`,`ur`.`RES_CODE` AS `RES_CODE`,`ur`.`RES_NAME` AS `RES_NAME`,`ur`.`RES_URL` AS `RES_URL`,`ur`.`FLAG` AS `FLAG`,`ur`.`SEQ_NO` AS `SEQ_NO`,`ur`.`RES_ICON` AS `RES_ICON`,`uur`.`user_id` AS `USER_ID` from ((`uums_res` `ur` left join `uums_role_res` `urr` on((`ur`.`ID` = `urr`.`res_id`))) left join `uums_user_role` `uur` on((`urr`.`role_id` = `uur`.`role_id`)))) ;

-- ----------------------------
-- View structure for his_user_view
-- ----------------------------
DROP VIEW IF EXISTS `his_user_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_user_view` AS (select `uums_user`.`ID` AS `ID`,`uums_user`.`ORG_ID` AS `ORG_ID`,`uums_user`.`NAME` AS `NAME`,`uums_user`.`USER_NAME` AS `USER_NAME`,`uums_user`.`USER_PWD` AS `USER_PWD`,`uums_user`.`MOBILE` AS `MOBILE`,`uums_user`.`SOURCE` AS `SOURCE`,`uums_user`.`FLAG` AS `FLAG` from `uums_user`) ;

-- ----------------------------
-- View structure for his_water_intake_warning_view
-- ----------------------------
DROP VIEW IF EXISTS `his_water_intake_warning_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`health`@`%` SQL SECURITY DEFINER VIEW `his_water_intake_warning_view` AS (select `hlc2`.`ID` AS `ID`,`hlc2`.`MEMBER_ID` AS `MEMBER_ID`,`uu`.`ORG_ID` AS `ORG_ID` from ((`his_life_care` `hlc2` left join `uums_user` `uu` on((`uu`.`ID` = `hlc2`.`CREATOR`))) join `his_select_maxid_life_care_baseview` `a` on(((`hlc2`.`ID` = `a`.`ID`) and (`hlc2`.`WATER_INTAKE_SUM` < 800))))) ;
