/*
Navicat MySQL Data Transfer

Source Server         : testtest
Source Server Version : 50616
Source Host           : rm-2ze9w425lsmc2bf34o.mysql.rds.aliyuncs.com:3306
Source Database       : hms-test

Target Server Type    : MYSQL
Target Server Version : 50616
File Encoding         : 65001

Date: 2019-08-16 18:03:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dic_district
-- ----------------------------
DROP TABLE IF EXISTS `dic_district`;
CREATE TABLE `dic_district` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PARENT_ID` int(11) DEFAULT NULL,
  `DISTRICT_NAME` varchar(15) DEFAULT NULL COMMENT '省、市、区（县）、街道（乡镇）',
  `FLAG` tinyint(4) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  `DISTRICT_CODE` char(9) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='行政区划数据';

-- ----------------------------
-- Records of dic_district
-- ----------------------------

-- ----------------------------
-- Table structure for dic_log_type
-- ----------------------------
DROP TABLE IF EXISTS `dic_log_type`;
CREATE TABLE `dic_log_type` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `LOG_TYPE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dic_log_type
-- ----------------------------
INSERT INTO `dic_log_type` VALUES ('1', '新增机构');
INSERT INTO `dic_log_type` VALUES ('2', '删除机构');

-- ----------------------------
-- Table structure for dic_region
-- ----------------------------
DROP TABLE IF EXISTS `dic_region`;
CREATE TABLE `dic_region` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISTRICT_ID` int(11) DEFAULT NULL,
  `REGION_NAME` varchar(15) DEFAULT NULL COMMENT '商圈、地名、地标',
  `PINYIN` varchar(15) DEFAULT NULL,
  `FLAG` tinyint(4) DEFAULT '1' COMMENT '1-可用，0-不可用，默认1',
  PRIMARY KEY (`ID`),
  KEY `FK_REGION_DISTRICT` (`DISTRICT_ID`),
  CONSTRAINT `FK_REGION_DISTRICT` FOREIGN KEY (`DISTRICT_ID`) REFERENCES `dic_district` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='区域数据';

-- ----------------------------
-- Records of dic_region
-- ----------------------------

-- ----------------------------
-- Table structure for hms_card
-- ----------------------------
DROP TABLE IF EXISTS `hms_card`;
CREATE TABLE `hms_card` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORG_ID` int(11) NOT NULL COMMENT '制卡单位',
  `CARD_TYPE` tinyint(4) DEFAULT NULL COMMENT '磁卡-1，IC卡-2，条码卡-3，射频卡-4',
  `CARD_ID` varchar(50) DEFAULT NULL COMMENT '写入卡片内部的卡片物理标识号',
  `CARD_NO` varchar(50) DEFAULT NULL COMMENT '印刷在卡面的卡编号',
  `FLAG` tinyint(4) DEFAULT NULL COMMENT '正常-1，停用-0，-1-删除，默认1',
  `ISSUING_ORG` int(11) DEFAULT NULL COMMENT '发卡单位',
  `ISSUING_TIME` datetime DEFAULT NULL COMMENT '发卡时间',
  `CREATOR` int(11) NOT NULL COMMENT '创建人',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`),
  KEY `FK_CARD_ORG` (`ORG_ID`),
  KEY `FK_CARD_ISSUING_ORG` (`ISSUING_ORG`),
  KEY `FK_CARD_CREATOR` (`CREATOR`),
  CONSTRAINT `hms_card_ibfk_1` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `hms_card_ibfk_2` FOREIGN KEY (`ISSUING_ORG`) REFERENCES `uums_org` (`ID`),
  CONSTRAINT `hms_card_ibfk_3` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_card
-- ----------------------------

-- ----------------------------
-- Table structure for hms_device
-- ----------------------------
DROP TABLE IF EXISTS `hms_device`;
CREATE TABLE `hms_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORG_ID` int(11) NOT NULL COMMENT '所属单位',
  `DEVICE_TYPE` tinyint(3) DEFAULT NULL COMMENT '设备类型（1-刷卡机，2-打印机）',
  `SERIAL_NUMBER` varchar(50) DEFAULT NULL COMMENT '序列号',
  `DEVICE_MODEL` varchar(50) DEFAULT NULL COMMENT '型号',
  `MANUFACTURER` varchar(100) DEFAULT NULL COMMENT '生产厂家',
  `FLAG` tinyint(3) DEFAULT '1' COMMENT '1-正常，0-停用，-1-删除',
  PRIMARY KEY (`ID`),
  KEY `FK_DEVICE_ORG` (`ORG_ID`),
  CONSTRAINT `hms_device_ibfk_1` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_device
-- ----------------------------
INSERT INTO `hms_device` VALUES ('36', '2', '2', '2', '2', '2', '-1');
INSERT INTO `hms_device` VALUES ('37', '1', '2', '2', '2', '2', '-1');

-- ----------------------------
-- Table structure for hms_member
-- ----------------------------
DROP TABLE IF EXISTS `hms_member`;
CREATE TABLE `hms_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `USER_ID` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `NAME` varchar(10) DEFAULT '',
  `SEX` tinyint(3) DEFAULT '0' COMMENT '男-1，女-2',
  `NATIVE_PLACE` varchar(20) DEFAULT NULL,
  `AGE` tinyint(4) DEFAULT NULL,
  `HEIGHT` int(11) DEFAULT NULL COMMENT '单位 cm',
  `BIRTHDAY` date DEFAULT NULL,
  `NATION` varchar(15) DEFAULT NULL,
  `MOBILE` char(15) NOT NULL,
  `TEL` varchar(15) DEFAULT NULL,
  `ADDRESS` varchar(50) DEFAULT NULL COMMENT '完整居住地址，到门牌号',
  `IDNO` char(18) DEFAULT NULL,
  `CARD_NO` varchar(20) DEFAULT NULL,
  `WATCH_SIM` varchar(20) DEFAULT NULL COMMENT '智能手表SIM卡号',
  `DATA_GATEWAY` varchar(20) DEFAULT NULL COMMENT '上传数据的网关标识号',
  `DATA_GATEWAY_SIM` varchar(20) DEFAULT NULL COMMENT '数据网关SIM卡号',
  `EMERGENCY_CONTACT` varchar(10) DEFAULT NULL,
  `EMERGENCY_MOBILE` char(20) DEFAULT NULL,
  `RELATIONSHIP_WITH` tinyint(4) DEFAULT NULL COMMENT '本人-1，子女-2，亲属-3，其他-4',
  `REMARK` varchar(500) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  `FLAG` tinyint(4) NOT NULL COMMENT '正常-1，停用-0，注销-2',
  PRIMARY KEY (`ID`),
  KEY `HMS_MEMBER_USER` (`USER_ID`),
  KEY `HMS_MEMBER_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_MEMBER_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_MEMBER_USER` FOREIGN KEY (`USER_ID`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_member
-- ----------------------------
INSERT INTO `hms_member` VALUES ('1', '1', '测试', '1', '1', '118', '1111111', '1899-12-30', '汉', '18613561458', '0101111111', '北京市昌平区霍营1号楼', '111111111111111111', '1', null, '1', '1', '备用', '13111111111', '2', '1', '1', '2017-11-21 12:20:06', '2017-12-06 15:39:52', '1');
INSERT INTO `hms_member` VALUES ('2', '8', '朱杰', '2', '河北衡水', '26', '163', '1991-08-23', '汉', '18631891111', '01050976332', '北京市昌平区霍营华龙苑中里2号楼1单元103', '131122199108233223', '2', null, '11', '1', 'lx', '13111111111', '1', '2', '8', '2017-11-27 14:24:59', '2017-12-18 09:32:08', '2');
INSERT INTO `hms_member` VALUES ('4', '11', null, null, null, null, null, null, null, '13111111112', null, null, null, null, null, null, null, null, null, null, null, '11', '2017-11-27 15:09:31', null, '2');
INSERT INTO `hms_member` VALUES ('5', '12', '会员三', '2', '', '0', null, '2017-11-28', '', '13111111113', '', '', '', '3', '', '', '', '', '', '1', '', '12', '2017-11-28 09:34:59', '2017-11-28 10:45:50', '1');
INSERT INTO `hms_member` VALUES ('6', '13', '会员四', '1', '', '1', null, '2017-11-28', '', '13111111114', '', '', '', '4', null, '', '', '', '', '1', '', '8', '2017-11-28 09:38:15', '2018-01-29 10:02:16', '1');
INSERT INTO `hms_member` VALUES ('7', '14', '会员五', '1', '', '6', null, '2011-11-28', '', '13111111115', '', '', '', '5', '', '', '', '', '', '1', '', '8', '2017-11-28 09:41:04', '2017-11-28 09:53:10', '1');
INSERT INTO `hms_member` VALUES ('8', '15', '会员六', '1', '', '7', null, '2010-11-23', '', '13111111116', '', '', '', '6', '', '', '', '', '', '1', '', '8', '2017-11-28 09:41:53', '2017-11-29 09:13:55', '1');
INSERT INTO `hms_member` VALUES ('9', '16', null, null, null, null, null, null, null, '13111111117', null, null, null, null, null, null, null, null, null, null, null, '16', '2017-11-29 09:12:37', null, '2');
INSERT INTO `hms_member` VALUES ('10', '17', '会员八啊', '2', '北京市昌平区2号楼', '7', null, '2010-11-29', '汉', '13111111118', '1111112', '北京市昌平区霍营2号楼', '111111111111111118', '8', null, '8', '8', '8', '8', '1', '88', '17', '2017-11-30 09:07:38', '2017-11-30 09:15:25', '0');
INSERT INTO `hms_member` VALUES ('11', '18', '会员九', '1', '', '0', null, '2017-11-30', '', '13111111119', '', '', '', '9', null, '9', '9', '9', '9', '1', '9', '18', '2017-11-30 09:17:11', '2017-11-30 09:18:38', '1');
INSERT INTO `hms_member` VALUES ('12', '20', '会员二三啊', '1', '北京市昌平区2号楼', '8', '167', '2010-12-01', '汉', '0101111112', '0101111112', '北京市昌平区霍营2号楼', '111111111111111123', '', null, '2', '2', '备用二', '13111111112', '2', '备注二', '20', '2017-12-01 10:29:10', '2018-01-29 10:01:50', '1');
INSERT INTO `hms_member` VALUES ('13', '21', '会员二四', '1', '', '0', null, '2017-12-01', '', '13111111124', '', '', '', '', '', '', '', '', '', '1', '', '20', '2017-12-01 10:54:19', '2017-12-01 10:54:19', '2');
INSERT INTO `hms_member` VALUES ('14', '22', null, null, null, null, null, null, null, '13545676789', null, null, null, null, null, null, null, null, null, null, null, '22', '2017-12-01 18:59:34', null, '2');
INSERT INTO `hms_member` VALUES ('15', '23', null, null, null, null, null, null, null, '18911111111', null, null, null, null, null, null, null, null, null, null, null, '23', '2017-12-05 16:51:33', null, '2');
INSERT INTO `hms_member` VALUES ('16', '24', '唐唐啊', '1', '北京市昌平区2号楼', '7', '166', '2010-12-04', '汉', '18911111122', '0101111112', '北京市昌平区霍营2号楼', '111111111111111112', '2', null, '2', '2', 'BYe', '13111111112', '2', '2', '24', '2017-12-05 16:52:16', '2017-12-05 16:55:30', '2');
INSERT INTO `hms_member` VALUES ('17', '25', '会员二五啊', '2', '北京市昌平区2号楼', '7', '222', '2010-12-06', '汉', '13111111125', '0101111112', '北京市昌平区霍营2号楼', '111111111111111125', '2222222222222222222', '22222222222222222', '222222222222222222', '222222222222222', '备用二', '13111111112', '2', '2', '1', '2017-12-06 09:21:32', '2017-12-06 15:40:25', '0');
INSERT INTO `hms_member` VALUES ('18', '27', null, null, null, null, null, null, null, '13111111126', null, null, null, null, null, null, null, null, null, null, null, '27', '2018-01-26 11:14:40', null, '2');
INSERT INTO `hms_member` VALUES ('19', '9', '会员一', '1', '北京', '0', null, '2017-11-27', '无', '13111111111', '1111111', '无', '111111111111111111', '90A4A45D', null, '1', '1', '1', '1', '1', '1', '8', '2017-11-27 14:46:02', '2017-11-27 14:46:52', '2');
INSERT INTO `hms_member` VALUES ('20', '29', '会员二七', '1', '', '0', '163', '2018-01-26', '', '13111111127', '', '', '', '9006a55d', '865946021012131', '', '', '', '', '1', '', '29', '2018-01-26 11:34:00', '2018-01-29 10:36:34', '1');
INSERT INTO `hms_member` VALUES ('21', '30', '030小怪兽', '1', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, '', null, null, null, null, null, null, null, '30', '2018-01-26 12:37:11', null, '1');
INSERT INTO `hms_member` VALUES ('22', '31', 'Mr.person', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同1', null, null, null, null, null, null, null, null, null, '31', '2018-01-26 12:39:27', null, '1');
INSERT INTO `hms_member` VALUES ('23', '32', 'Mrperson', '1', '', '0', '178', '2018-01-09', '', '17600978869', '', '北京市昌平区文庙胡同1', '', '', '12342335', '', '', '', '', '1', '', '32', '2018-01-26 12:39:54', '2018-01-29 09:38:07', '1');
INSERT INTO `hms_member` VALUES ('24', '33', '', '1', '', null, null, null, '', '18612345678', '', '', '', '', '1231341', '', '', '', '', '1', '', '33', '2018-01-29 09:35:16', '2018-01-29 09:36:46', '1');
INSERT INTO `hms_member` VALUES ('25', '34', '王鹏飞', '1', '', '25', '180', '1993-02-01', '', '18613565122', '', '一个地址', '', 'C0A5A85D', '2', '', '', '', '', '1', '', '34', '2018-01-29 11:43:13', '2018-02-01 10:23:17', '1');
INSERT INTO `hms_member` VALUES ('26', '35', 'Mr.person', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同1', null, null, null, null, null, null, null, null, null, '35', '2018-01-29 12:07:39', null, '1');
INSERT INTO `hms_member` VALUES ('27', '36', '马睿', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同', null, null, null, null, null, null, null, null, null, '36', '2018-01-29 16:50:35', null, '1');
INSERT INTO `hms_member` VALUES ('28', '37', '马睿', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同', null, null, null, null, null, null, null, null, null, '37', '2018-01-29 16:51:28', null, '1');
INSERT INTO `hms_member` VALUES ('29', '38', '', '1', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '38', '2018-01-29 16:52:11', null, '1');
INSERT INTO `hms_member` VALUES ('30', '39', '邢世莹', '2', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '39', '2018-01-29 16:57:05', null, '1');
INSERT INTO `hms_member` VALUES ('31', '40', '邢世莹', '2', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '40', '2018-01-29 17:32:52', null, '1');
INSERT INTO `hms_member` VALUES ('32', '41', '邢世莹', '2', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '41', '2018-01-29 17:56:30', null, '1');
INSERT INTO `hms_member` VALUES ('35', '44', '马睿', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同', null, null, null, null, null, null, null, null, null, '44', '2018-01-30 10:44:22', null, '1');
INSERT INTO `hms_member` VALUES ('36', '45', '马睿', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同', null, null, null, null, null, null, null, null, null, '45', '2018-01-30 10:45:14', null, '1');
INSERT INTO `hms_member` VALUES ('37', '46', '邢世莹', '2', null, null, null, null, null, '13121793032', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '46', '2018-01-30 10:49:21', null, '1');
INSERT INTO `hms_member` VALUES ('38', '47', '马睿', '1', null, null, null, null, null, '17600978869', null, '北京市昌平区文庙胡同', null, null, null, null, null, null, null, null, null, '47', '2018-01-30 10:52:34', null, '1');
INSERT INTO `hms_member` VALUES ('42', '52', '刘欣未', '1', null, null, null, null, null, '17600337542', null, '北京市昌平区龙跃街', null, null, null, null, null, null, null, null, null, '52', '2018-02-01 15:26:02', null, '1');
INSERT INTO `hms_member` VALUES ('43', '53', '马壮壮', '1', null, null, null, null, null, '13298323416', null, '北京市昌平区黄平路', null, null, null, null, null, null, null, null, null, '53', '2018-02-05 19:08:00', null, '1');
INSERT INTO `hms_member` VALUES ('44', '54', '代云瑞', '1', null, null, null, null, null, '15901170409', null, '北京市昌平区霍营1号楼', null, null, null, null, null, null, null, null, null, '54', '2018-02-06 10:11:51', null, '1');
INSERT INTO `hms_member` VALUES ('134', '50', '朱杰abc', '2', '', '27', '163', '1991-08-23', '', '18631892217', '', '北京市昌平区黄平路', '', '402DD95D', '1', '', '', '', '', '1', '', '50', '2018-01-30 15:19:01', '2018-02-01 09:43:30', '1');

-- ----------------------------
-- Table structure for hms_member_physical_setting
-- ----------------------------
DROP TABLE IF EXISTS `hms_member_physical_setting`;
CREATE TABLE `hms_member_physical_setting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL,
  `WATCH_ONLINE_STATUS` tinyint(4) DEFAULT NULL,
  `SOS_NUMBER1` char(15) DEFAULT NULL,
  `SOS_NUMBER2` char(15) DEFAULT NULL,
  `SOS_NUMBER3` char(15) DEFAULT NULL,
  `LOCATION_INTERVAL` int(11) DEFAULT NULL,
  `GEO_FENCE` text,
  `CREATOR` int(11) NOT NULL,
  `CREATE_TIME` datetime NOT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_MEMBER_PHYSICAL_SETTING` (`MEMBER_ID`),
  KEY `FK_PHYSICAL_SETTING_CREATOR` (`CREATOR`),
  CONSTRAINT `FK_MEMBER_PHYSICAL_SETTING` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`),
  CONSTRAINT `FK_PHYSICAL_SETTING_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_member_physical_setting
-- ----------------------------
INSERT INTO `hms_member_physical_setting` VALUES ('3', '20', '1', null, null, null, null, null, '29', '2018-01-29 09:34:42', '2018-01-29 09:34:42');
INSERT INTO `hms_member_physical_setting` VALUES ('4', '24', '0', null, null, null, null, null, '33', '2018-01-29 09:36:00', '2018-01-29 09:36:00');
INSERT INTO `hms_member_physical_setting` VALUES ('5', '23', '0', null, null, null, null, null, '32', '2018-01-29 09:38:07', '2018-01-29 09:38:07');
INSERT INTO `hms_member_physical_setting` VALUES ('6', '12', '0', null, null, null, null, null, '20', '2018-01-29 10:01:50', '2018-01-29 10:01:50');
INSERT INTO `hms_member_physical_setting` VALUES ('7', '6', '0', null, null, null, null, null, '13', '2018-01-29 10:02:16', '2018-01-29 10:02:16');
INSERT INTO `hms_member_physical_setting` VALUES ('8', '134', '0', null, null, null, null, null, '50', '2018-02-01 09:43:30', '2018-02-01 09:43:30');
INSERT INTO `hms_member_physical_setting` VALUES ('9', '25', '0', null, null, null, null, null, '34', '2018-02-01 10:23:17', '2018-02-01 10:23:17');

-- ----------------------------
-- Table structure for hms_physical_blood_oxygen
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_blood_oxygen`;
CREATE TABLE `hms_physical_blood_oxygen` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `BLOOD_OXYGEN` int(11) DEFAULT NULL,
  `PULSE` int(11) DEFAULT NULL,
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_BLOOD_OXYGEN_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_BLOOD_OXYGEN_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_OXYGEN_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_OXYGEN_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_blood_oxygen
-- ----------------------------
INSERT INTO `hms_physical_blood_oxygen` VALUES ('6', '1', '2017-11-21 10:30:08', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '1', '2017-11-21 10:30:11');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('7', '1', '2017-11-21 10:30:37', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '1', '2017-11-21 10:30:39');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('8', '1', '2017-11-21 10:31:06', '99', '80', null, '02000000003520015808010117032003410000000000009006a55d', '1', '2017-11-21 10:31:08');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('9', '1', '2017-11-21 10:31:37', '99', '83', null, '02000000003520015808010117032003410000000000009006a55d', '1', '2017-11-21 10:31:39');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('10', '1', '2017-11-21 10:32:07', '99', '83', null, '02000000003520015808010117032003410000000000009006a55d', '1', '2017-11-21 10:32:09');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('11', '134', '2017-11-28 09:48:37', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '15', '2017-11-28 09:48:39');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('12', '134', '2017-11-28 09:51:21', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '14', '2017-11-28 09:51:27');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('13', '134', '2017-11-28 09:53:39', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-28 09:53:40');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('14', '134', '2017-11-28 09:54:15', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '12', '2017-11-28 09:54:18');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('15', '2', '2017-11-28 09:54:56', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 09:54:59');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('16', '134', '2017-11-28 09:56:44', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 09:56:46');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('17', '2', '2017-11-28 09:57:02', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 09:57:04');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('18', '2', '2017-11-28 09:57:28', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 09:57:29');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('19', '2', '2017-11-28 10:01:16', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 10:01:18');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('20', '2', '2017-11-28 10:03:05', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '8', '2017-11-28 10:03:07');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('21', '134', '2017-11-28 13:33:43', '99', '71', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-28 13:33:45');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('22', '134', '2017-11-28 17:38:28', '99', '73', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-28 17:38:36');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('23', '134', '2017-11-28 17:40:20', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-28 17:40:23');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('24', '134', '2017-11-29 16:18:51', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-29 16:18:54');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('25', '134', '2017-11-30 09:26:21', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-30 09:26:24');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('26', '134', '2017-11-30 09:52:37', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '13', '2017-11-30 09:52:39');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('27', '134', '2017-12-01 11:00:58', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '20', '2017-12-01 11:01:00');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('28', '134', '2017-12-01 11:01:21', '98', '80', null, '02000000003520015808010117032003410000000000009006a55d', '20', '2017-12-01 11:01:23');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('29', '134', '2017-12-04 10:08:51', '98', '80', '正常指标', '02000000003520015808010117032003410000000000009006a55d', '20', '2017-12-04 10:08:54');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('30', '134', '2018-01-26 12:32:28', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 12:32:30');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('31', '134', '2018-01-26 12:32:43', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 12:32:46');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('32', '134', '2018-01-26 12:33:00', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 12:33:02');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('33', '134', '2018-01-26 12:37:31', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 12:37:33');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('34', '134', '2018-01-26 12:53:56', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 12:53:59');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('35', '134', '2018-01-26 13:04:59', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 13:05:01');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('36', '134', '2018-01-26 13:05:35', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 13:05:36');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('37', '134', '2018-01-26 13:06:35', '99', '53', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-26 13:06:37');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('38', '134', '2018-01-29 10:36:58', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-29 10:37:00');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('39', '134', '2018-01-29 10:37:13', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-29 10:37:15');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('40', '134', '2018-01-29 10:40:10', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-29 10:40:12');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('41', '134', '2018-01-29 10:47:31', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-29 10:47:33');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('42', '134', '2018-01-30 11:01:42', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-30 11:01:44');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('43', '134', '2018-01-30 11:04:51', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-30 11:04:53');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('44', '134', '2018-01-30 11:15:25', '99', '62', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-30 11:15:27');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('45', '134', '2018-01-29 11:15:48', '98', '80', '正常指标', '020000000035200158080101170320034100000000000090a4a45d', '29', '2018-01-29 11:15:49');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('46', '134', '2018-01-30 15:37:00', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-30 15:37:02');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('47', '134', '2018-01-30 15:38:33', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-30 15:38:35');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('48', '134', '2018-01-31 10:52:40', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 10:52:42');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('49', '134', '2018-01-31 14:17:20', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:17:22');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('50', '134', '2018-01-31 14:17:48', '96', '75', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:17:51');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('51', '134', '2018-01-31 14:22:45', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:22:47');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('52', '134', '2018-01-31 14:50:29', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:50:31');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('53', '134', '2018-01-31 14:50:57', '99', '68', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:51:00');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('54', '134', '2018-01-31 14:51:28', '99', '76', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:51:30');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('55', '134', '2018-01-31 14:51:59', '99', '75', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-01-31 14:52:01');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('56', '25', '2018-02-01 14:38:47', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000c0a5a85d', '34', '2018-02-01 14:38:49');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('57', '25', '2018-02-01 14:39:18', '99', '81', '正常指标', '0200000000352001580801011703200341000000000000c0a5a85d', '34', '2018-02-01 14:39:19');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('58', '134', '2018-02-01 15:07:42', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-01 15:07:44');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('59', '134', '2018-02-01 15:23:21', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-01 15:23:24');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('60', '134', '2018-02-01 16:06:20', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-01 16:06:22');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('61', '134', '2018-02-01 16:06:51', '99', '77', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-01 16:06:53');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('62', '134', '2018-02-02 09:13:59', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:14:02');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('63', '25', '2018-02-02 09:15:20', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000c0a5a85d', '34', '2018-02-02 09:15:22');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('64', '134', '2018-02-02 09:21:24', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:21:27');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('65', '134', '2018-02-02 09:26:37', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:26:37');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('66', '134', '2018-02-02 09:26:51', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:26:53');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('67', '134', '2018-02-02 09:27:04', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:27:06');
INSERT INTO `hms_physical_blood_oxygen` VALUES ('68', '134', '2018-02-02 09:27:19', '98', '80', '正常指标', '0200000000352001580801011703200341000000000000402dd95d', '50', '2018-02-02 09:27:21');

-- ----------------------------
-- Table structure for hms_physical_blood_pressure
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_blood_pressure`;
CREATE TABLE `hms_physical_blood_pressure` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `DIASTOLIC_PRESSURE` int(11) DEFAULT NULL COMMENT '低压，单位mmHg',
  `SYSTOLIC_PRESSURE` int(11) DEFAULT NULL COMMENT '高压，单位mmHg',
  `PULSE` int(11) DEFAULT NULL COMMENT '次/分钟',
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_BLOOD_PRESSURE_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_BLOOD_PRESSURE_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_PRESSURE_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_PRESSURE_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_blood_pressure
-- ----------------------------
INSERT INTO `hms_physical_blood_pressure` VALUES ('7', '1', '2017-11-24 14:58:13', '66', '113', '84', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 14:58:18');
INSERT INTO `hms_physical_blood_pressure` VALUES ('8', '1', '2017-11-24 14:58:13', '66', '113', '84', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_blood_pressure` VALUES ('9', '1', '2017-11-24 14:59:23', '60', '111', '85', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 14:59:26');
INSERT INTO `hms_physical_blood_pressure` VALUES ('10', '1', '2017-11-24 15:00:09', '57', '109', '86', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:00:11');
INSERT INTO `hms_physical_blood_pressure` VALUES ('11', '1', '2017-11-24 15:00:40', '57', '115', '82', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:00:43');
INSERT INTO `hms_physical_blood_pressure` VALUES ('12', '1', '2017-11-24 15:01:11', '52', '105', '84', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:01:14');
INSERT INTO `hms_physical_blood_pressure` VALUES ('13', '1', '2017-11-24 15:03:06', '49', '112', '85', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:03:09');
INSERT INTO `hms_physical_blood_pressure` VALUES ('14', '134', '2017-11-24 15:04:50', '81', '114', '101', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:04:53');
INSERT INTO `hms_physical_blood_pressure` VALUES ('15', '134', '2017-11-24 15:06:13', '63', '99', '74', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:06:14');
INSERT INTO `hms_physical_blood_pressure` VALUES ('16', '134', '2017-11-24 15:07:37', '90', '130', '97', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:07:39');
INSERT INTO `hms_physical_blood_pressure` VALUES ('17', '134', '2017-11-24 15:08:52', '80', '132', '96', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:08:54');
INSERT INTO `hms_physical_blood_pressure` VALUES ('18', '134', '2017-11-24 15:10:23', '72', '123', '77', null, '02000000003520015805021217342000160000000000009006a55d', '1', '2017-11-24 15:10:26');
INSERT INTO `hms_physical_blood_pressure` VALUES ('19', '134', '2017-11-28 10:09:55', '95', '155', '89', null, '02000000003520015805021217342000160000000000009006a55d', '8', '2017-11-28 10:09:56');
INSERT INTO `hms_physical_blood_pressure` VALUES ('20', '134', '2017-11-28 10:18:22', '90', '129', '95', null, '02000000003520015805021217342000160000000000009006a55d', '12', '2017-11-28 10:18:24');
INSERT INTO `hms_physical_blood_pressure` VALUES ('21', '134', '2017-11-30 09:53:57', '95', '133', '90', null, '02000000003520015805021217342000160000000000009006a55d', '13', '2017-11-30 09:54:00');
INSERT INTO `hms_physical_blood_pressure` VALUES ('22', '134', '2018-01-26 12:59:18', '93', '136', '86', '数值异常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-26 12:59:20');
INSERT INTO `hms_physical_blood_pressure` VALUES ('23', '134', '2018-01-29 10:48:53', '87', '135', '102', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-29 10:48:55');
INSERT INTO `hms_physical_blood_pressure` VALUES ('24', '134', '2018-01-29 10:58:13', '81', '125', '93', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-29 10:58:14');
INSERT INTO `hms_physical_blood_pressure` VALUES ('25', '134', '2018-01-29 11:01:26', '77', '141', '89', '数值异常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-29 11:01:28');
INSERT INTO `hms_physical_blood_pressure` VALUES ('26', '134', '2018-01-29 11:02:44', '68', '110', '66', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-29 11:02:45');
INSERT INTO `hms_physical_blood_pressure` VALUES ('27', '134', '2018-01-30 11:15:25', '76', '115', '91', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-30 11:15:25');
INSERT INTO `hms_physical_blood_pressure` VALUES ('28', '134', '2018-01-30 10:15:25', '85', '131', '100', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-30 10:15:25');
INSERT INTO `hms_physical_blood_pressure` VALUES ('29', '134', '2018-01-30 10:15:25', '90', '128', '82', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-30 10:15:25');
INSERT INTO `hms_physical_blood_pressure` VALUES ('30', '134', '2018-01-30 01:15:25', '79', '135', '77', '正常', '020000000035200158050212173420001600000000000090a4a45d', '29', '2018-01-30 01:15:25');
INSERT INTO `hms_physical_blood_pressure` VALUES ('31', '134', '2018-01-30 15:45:57', '80', '129', '93', '正常', '0200000000352001580502121734200016000000000000402dd95d', '50', '2018-01-30 15:45:58');
INSERT INTO `hms_physical_blood_pressure` VALUES ('32', '134', '2018-02-01 09:42:32', '97', '141', '100', '高血压', '0200000000352001580502121734200016000000000000402dd95d', '50', '2018-02-01 09:42:34');
INSERT INTO `hms_physical_blood_pressure` VALUES ('33', '25', '2018-02-01 10:24:11', '81', '124', '76', '正常', '0200000000352001580502121734200016000000000000c0a5a85d', '34', '2018-02-01 10:24:12');
INSERT INTO `hms_physical_blood_pressure` VALUES ('34', '25', '2018-02-01 18:21:48', '84', '134', '78', '正常', '0200000000352001580502121734200016000000000000c0a5a85d', '34', '2018-02-01 18:21:49');
INSERT INTO `hms_physical_blood_pressure` VALUES ('35', '25', '2018-02-01 18:30:58', '37', '112', '74', '数值异常', '0200000000352001580502121734200016000000000000c0a5a85d', '34', '2018-02-01 18:31:00');
INSERT INTO `hms_physical_blood_pressure` VALUES ('36', '25', '2018-02-02 09:19:24', '76', '124', '91', '正常', '0200000000352001580502121734200016000000000000c0a5a85d', '34', '2018-02-02 09:19:24');
INSERT INTO `hms_physical_blood_pressure` VALUES ('37', '134', '2018-02-02 09:23:49', '86', '131', '86', '正常', '0200000000352001580502121734200016000000000000402dd95d', '50', '2018-02-02 09:23:51');

-- ----------------------------
-- Table structure for hms_physical_blood_sugar
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_blood_sugar`;
CREATE TABLE `hms_physical_blood_sugar` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `BLOOD_SUGAR` float(4,2) DEFAULT NULL COMMENT '单位mmol',
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_BLOOD_SUGAR_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_BLOOD_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_BLOOD_SUGAR_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_blood_sugar
-- ----------------------------
INSERT INTO `hms_physical_blood_sugar` VALUES ('1', '1', '2017-11-23 11:17:08', '0.00', null, '02000000003520015806010417222005780000000000009006a55d', '1', '2017-11-23 11:17:12');
INSERT INTO `hms_physical_blood_sugar` VALUES ('2', '1', '2017-11-23 11:17:08', '0.00', null, '02000000003520015806010417222005780000000000009006a55d', '1', '2017-11-23 11:17:12');
INSERT INTO `hms_physical_blood_sugar` VALUES ('3', '1', '2017-11-23 11:19:38', '0.00', null, '02000000003520015806010417222005780000000000009006a55d', '1', '2017-11-23 11:19:40');
INSERT INTO `hms_physical_blood_sugar` VALUES ('4', '1', '2017-11-23 11:26:16', '33.40', null, '02000000003520015806010417222005780000000000009006a55d', '1', '2017-11-23 11:26:20');
INSERT INTO `hms_physical_blood_sugar` VALUES ('5', '6', '2017-11-30 09:40:00', '33.40', null, '02000000003520015806010417222005780000000000009006a55d', '13', '2017-11-30 09:40:02');
INSERT INTO `hms_physical_blood_sugar` VALUES ('6', '6', '2017-11-30 09:47:11', '0.00', null, '02000000003520015806010417222005780000000000009006a55d', '13', '2017-11-30 09:47:14');
INSERT INTO `hms_physical_blood_sugar` VALUES ('7', '20', '2018-01-26 13:01:12', '33.40', '血糖偏高', '020000000035200158060104172220057800000000000090a4a45d', '29', '2018-01-26 13:01:14');
INSERT INTO `hms_physical_blood_sugar` VALUES ('8', '20', '2018-01-29 11:11:03', '0.00', '血糖偏低', '020000000035200158060104172220057800000000000090a4a45d', '29', '2018-01-29 11:11:04');
INSERT INTO `hms_physical_blood_sugar` VALUES ('9', '20', '2018-01-29 11:29:39', '33.40', '血糖偏高', '020000000035200158060104172220057800000000000090a4a45d', '29', '2018-01-29 11:29:42');
INSERT INTO `hms_physical_blood_sugar` VALUES ('10', '25', '2018-02-01 11:31:51', '12.60', '血糖偏高', '020000000035200158060104172220057800000000000090a4a45d', '29', '2018-02-01 11:31:51');
INSERT INTO `hms_physical_blood_sugar` VALUES ('11', '25', '2018-02-01 11:35:05', '3.60', '血糖偏低', '020000000035200158060104172220057800000000000090a4a45d', '29', '2018-02-01 11:35:05');

-- ----------------------------
-- Table structure for hms_physical_pulse
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_pulse`;
CREATE TABLE `hms_physical_pulse` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `PULSE` int(11) DEFAULT NULL,
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_PULSE_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_PULSE_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_PULSE_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_PULSE_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_pulse
-- ----------------------------
INSERT INTO `hms_physical_pulse` VALUES ('1', '1', '2017-11-24 14:58:13', '84', null, null, '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_pulse` VALUES ('2', '1', '2017-11-24 14:58:13', '84', null, null, '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_pulse` VALUES ('3', '1', '2017-11-24 14:59:23', '85', null, null, '1', '2017-11-24 14:59:26');
INSERT INTO `hms_physical_pulse` VALUES ('4', '1', '2017-11-24 15:00:09', '86', null, null, '1', '2017-11-24 15:00:11');
INSERT INTO `hms_physical_pulse` VALUES ('5', '1', '2017-11-24 15:00:40', '82', null, null, '1', '2017-11-24 15:00:43');
INSERT INTO `hms_physical_pulse` VALUES ('6', '1', '2017-11-24 15:01:11', '84', null, null, '1', '2017-11-24 15:01:14');
INSERT INTO `hms_physical_pulse` VALUES ('7', '1', '2017-11-24 15:03:06', '85', null, null, '1', '2017-11-24 15:03:09');
INSERT INTO `hms_physical_pulse` VALUES ('8', '1', '2017-11-24 15:04:50', '101', null, null, '1', '2017-11-24 15:04:53');
INSERT INTO `hms_physical_pulse` VALUES ('9', '1', '2017-11-24 15:06:13', '74', null, null, '1', '2017-11-24 15:06:15');
INSERT INTO `hms_physical_pulse` VALUES ('10', '1', '2017-11-24 15:07:37', '97', null, null, '1', '2017-11-24 15:07:39');
INSERT INTO `hms_physical_pulse` VALUES ('11', '1', '2017-11-24 15:08:52', '96', null, null, '1', '2017-11-24 15:08:55');
INSERT INTO `hms_physical_pulse` VALUES ('12', '1', '2017-11-24 15:10:23', '77', null, null, '1', '2017-11-24 15:10:26');
INSERT INTO `hms_physical_pulse` VALUES ('13', '2', '2017-11-28 10:09:55', '89', null, null, '8', '2017-11-28 10:09:56');
INSERT INTO `hms_physical_pulse` VALUES ('14', '5', '2017-11-28 10:18:22', '95', null, null, '12', '2017-11-28 10:18:24');
INSERT INTO `hms_physical_pulse` VALUES ('15', '6', '2017-11-30 09:53:57', '90', null, null, '13', '2017-11-30 09:54:00');
INSERT INTO `hms_physical_pulse` VALUES ('16', '20', '2018-01-26 12:59:18', '86', '正常区间', null, '29', '2018-01-26 12:59:20');
INSERT INTO `hms_physical_pulse` VALUES ('17', '20', '2018-01-29 10:48:53', '102', '心动过速', null, '29', '2018-01-29 10:48:55');
INSERT INTO `hms_physical_pulse` VALUES ('18', '20', '2018-01-29 10:58:13', '93', '正常区间', null, '29', '2018-01-29 10:58:14');
INSERT INTO `hms_physical_pulse` VALUES ('19', '20', '2018-01-29 11:01:26', '89', '正常区间', null, '29', '2018-01-29 11:01:28');
INSERT INTO `hms_physical_pulse` VALUES ('20', '20', '2018-01-29 11:02:44', '66', '正常区间', null, '29', '2018-01-29 11:02:45');
INSERT INTO `hms_physical_pulse` VALUES ('21', '20', '2018-01-29 11:03:47', '91', '正常区间', null, '29', '2018-01-29 11:03:49');
INSERT INTO `hms_physical_pulse` VALUES ('22', '20', '2018-01-29 11:06:12', '100', '正常区间', null, '29', '2018-01-29 11:06:15');
INSERT INTO `hms_physical_pulse` VALUES ('23', '20', '2018-01-29 14:47:56', '82', '正常区间', null, '29', '2018-01-29 14:47:58');
INSERT INTO `hms_physical_pulse` VALUES ('24', '20', '2018-01-29 14:51:59', '77', '正常区间', null, '29', '2018-01-29 14:52:01');
INSERT INTO `hms_physical_pulse` VALUES ('25', '134', '2018-01-30 15:45:57', '93', '正常区间', null, '50', '2018-01-30 15:45:58');
INSERT INTO `hms_physical_pulse` VALUES ('26', '134', '2018-02-01 09:42:32', '100', '正常区间', null, '50', '2018-02-01 09:42:34');
INSERT INTO `hms_physical_pulse` VALUES ('27', '25', '2018-02-01 10:24:11', '76', '正常区间', null, '34', '2018-02-01 10:24:12');
INSERT INTO `hms_physical_pulse` VALUES ('28', '25', '2018-02-01 18:21:48', '78', '正常区间', null, '34', '2018-02-01 18:21:49');
INSERT INTO `hms_physical_pulse` VALUES ('29', '25', '2018-02-01 18:30:58', '74', '正常区间', null, '34', '2018-02-01 18:31:00');
INSERT INTO `hms_physical_pulse` VALUES ('30', '25', '2018-02-02 09:19:24', '91', '正常区间', null, '34', '2018-02-02 09:19:24');
INSERT INTO `hms_physical_pulse` VALUES ('31', '134', '2018-02-02 09:23:49', '86', '正常区间', null, '50', '2018-02-02 09:23:51');

-- ----------------------------
-- Table structure for hms_physical_record
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_record`;
CREATE TABLE `hms_physical_record` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_ITEM` tinyint(4) DEFAULT NULL COMMENT '体重-1，血压-2，血糖-3，血氧-4，脉搏-5',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `PHYSICAL_ID` int(11) DEFAULT NULL,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_RECORD_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_RECORD_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_RECORD_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_RECORD_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=788 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_record
-- ----------------------------
INSERT INTO `hms_physical_record` VALUES ('1', '1', '4', '2017-11-21 10:30:08', null, '6', '1', '2017-11-21 10:30:11');
INSERT INTO `hms_physical_record` VALUES ('2', '1', '4', '2017-11-21 10:30:37', null, '7', '1', '2017-11-21 10:30:39');
INSERT INTO `hms_physical_record` VALUES ('3', '1', '4', '2017-11-21 10:31:06', null, '8', '1', '2017-11-21 10:31:08');
INSERT INTO `hms_physical_record` VALUES ('4', '1', '4', '2017-11-21 10:31:37', null, '9', '1', '2017-11-21 10:31:39');
INSERT INTO `hms_physical_record` VALUES ('5', '1', '4', '2017-11-21 10:32:07', null, '10', '1', '2017-11-21 10:32:09');
INSERT INTO `hms_physical_record` VALUES ('13', '1', '3', '2017-11-23 11:17:08', null, '1', '1', '2017-11-23 11:17:12');
INSERT INTO `hms_physical_record` VALUES ('14', '1', '3', '2017-11-23 11:17:08', null, '2', '1', '2017-11-23 11:17:12');
INSERT INTO `hms_physical_record` VALUES ('15', '1', '3', '2017-11-23 11:19:38', null, '3', '1', '2017-11-23 11:19:40');
INSERT INTO `hms_physical_record` VALUES ('16', '1', '3', '2017-11-23 11:26:16', null, '4', '1', '2017-11-23 11:26:20');
INSERT INTO `hms_physical_record` VALUES ('17', '1', '1', '2017-11-24 09:45:56', null, '1', '1', '2017-11-24 09:46:03');
INSERT INTO `hms_physical_record` VALUES ('18', '1', '1', '2017-11-24 09:46:49', null, '2', '1', '2017-11-24 09:46:56');
INSERT INTO `hms_physical_record` VALUES ('19', '1', '1', '2017-11-24 09:46:59', null, '3', '1', '2017-11-24 09:47:07');
INSERT INTO `hms_physical_record` VALUES ('20', '1', '1', '2017-11-24 09:47:13', null, '4', '1', '2017-11-24 09:47:20');
INSERT INTO `hms_physical_record` VALUES ('21', '1', '1', '2017-11-24 09:47:24', null, '5', '1', '2017-11-24 09:47:31');
INSERT INTO `hms_physical_record` VALUES ('22', '1', '1', '2017-11-24 09:47:29', null, '6', '1', '2017-11-24 09:47:36');
INSERT INTO `hms_physical_record` VALUES ('23', '1', '1', '2017-11-24 09:48:12', null, '7', '1', '2017-11-24 09:48:19');
INSERT INTO `hms_physical_record` VALUES ('24', '1', '1', '2017-11-24 09:48:20', null, '8', '1', '2017-11-24 09:48:28');
INSERT INTO `hms_physical_record` VALUES ('25', '1', '2', '2017-11-24 14:58:13', null, '7', '1', '2017-11-24 14:58:18');
INSERT INTO `hms_physical_record` VALUES ('26', '1', '5', '2017-11-24 14:58:13', null, '1', '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_record` VALUES ('27', '1', '2', '2017-11-24 14:58:13', null, '8', '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_record` VALUES ('28', '1', '5', '2017-11-24 14:58:13', null, '2', '1', '2017-11-24 14:58:19');
INSERT INTO `hms_physical_record` VALUES ('29', '1', '2', '2017-11-24 14:59:23', null, '9', '1', '2017-11-24 14:59:26');
INSERT INTO `hms_physical_record` VALUES ('30', '1', '5', '2017-11-24 14:59:23', null, '3', '1', '2017-11-24 14:59:26');
INSERT INTO `hms_physical_record` VALUES ('31', '1', '2', '2017-11-24 15:00:09', null, '10', '1', '2017-11-24 15:00:11');
INSERT INTO `hms_physical_record` VALUES ('32', '1', '5', '2017-11-24 15:00:09', null, '4', '1', '2017-11-24 15:00:11');
INSERT INTO `hms_physical_record` VALUES ('33', '1', '2', '2017-11-24 15:00:40', null, '11', '1', '2017-11-24 15:00:43');
INSERT INTO `hms_physical_record` VALUES ('34', '1', '5', '2017-11-24 15:00:40', null, '5', '1', '2017-11-24 15:00:43');
INSERT INTO `hms_physical_record` VALUES ('35', '1', '2', '2017-11-24 15:01:11', null, '12', '1', '2017-11-24 15:01:14');
INSERT INTO `hms_physical_record` VALUES ('36', '1', '5', '2017-11-24 15:01:11', null, '6', '1', '2017-11-24 15:01:14');
INSERT INTO `hms_physical_record` VALUES ('37', '1', '2', '2017-11-24 15:03:06', null, '13', '1', '2017-11-24 15:03:09');
INSERT INTO `hms_physical_record` VALUES ('38', '1', '5', '2017-11-24 15:03:06', null, '7', '1', '2017-11-24 15:03:09');
INSERT INTO `hms_physical_record` VALUES ('39', '1', '2', '2017-11-24 15:04:50', null, '14', '1', '2017-11-24 15:04:53');
INSERT INTO `hms_physical_record` VALUES ('40', '1', '5', '2017-11-24 15:04:50', null, '8', '1', '2017-11-24 15:04:53');
INSERT INTO `hms_physical_record` VALUES ('41', '1', '2', '2017-11-24 15:06:13', null, '15', '1', '2017-11-24 15:06:14');
INSERT INTO `hms_physical_record` VALUES ('42', '1', '5', '2017-11-24 15:06:13', null, '9', '1', '2017-11-24 15:06:15');
INSERT INTO `hms_physical_record` VALUES ('43', '1', '2', '2017-11-24 15:07:37', null, '16', '1', '2017-11-24 15:07:39');
INSERT INTO `hms_physical_record` VALUES ('44', '1', '5', '2017-11-24 15:07:37', null, '10', '1', '2017-11-24 15:07:39');
INSERT INTO `hms_physical_record` VALUES ('45', '1', '2', '2017-11-24 15:08:52', null, '17', '1', '2017-11-24 15:08:54');
INSERT INTO `hms_physical_record` VALUES ('46', '1', '5', '2017-11-24 15:08:52', null, '11', '1', '2017-11-24 15:08:55');
INSERT INTO `hms_physical_record` VALUES ('47', '1', '2', '2017-11-24 15:10:23', null, '18', '1', '2017-11-24 15:10:26');
INSERT INTO `hms_physical_record` VALUES ('48', '1', '5', '2017-11-24 15:10:23', null, '12', '1', '2017-11-24 15:10:26');
INSERT INTO `hms_physical_record` VALUES ('49', '2', '1', '2017-11-28 09:32:54', null, '9', '8', '2017-11-28 09:32:57');
INSERT INTO `hms_physical_record` VALUES ('50', '5', '1', '2017-11-28 09:37:30', null, '10', '12', '2017-11-28 09:37:32');
INSERT INTO `hms_physical_record` VALUES ('51', '6', '1', '2017-11-28 09:39:27', null, '11', '13', '2017-11-28 09:39:29');
INSERT INTO `hms_physical_record` VALUES ('52', '7', '1', '2017-11-28 09:41:17', null, '12', '14', '2017-11-28 09:41:19');
INSERT INTO `hms_physical_record` VALUES ('53', '8', '1', '2017-11-28 09:42:05', null, '13', '15', '2017-11-28 09:42:07');
INSERT INTO `hms_physical_record` VALUES ('54', '8', '4', '2017-11-28 09:48:37', null, '11', '15', '2017-11-28 09:48:39');
INSERT INTO `hms_physical_record` VALUES ('55', '7', '4', '2017-11-28 09:51:21', null, '12', '14', '2017-11-28 09:51:27');
INSERT INTO `hms_physical_record` VALUES ('56', '6', '4', '2017-11-28 09:53:39', null, '13', '13', '2017-11-28 09:53:40');
INSERT INTO `hms_physical_record` VALUES ('57', '5', '4', '2017-11-28 09:54:15', null, '14', '12', '2017-11-28 09:54:18');
INSERT INTO `hms_physical_record` VALUES ('58', '2', '4', '2017-11-28 09:54:56', null, '15', '8', '2017-11-28 09:54:59');
INSERT INTO `hms_physical_record` VALUES ('59', '2', '4', '2017-11-28 09:56:44', null, '16', '8', '2017-11-28 09:56:46');
INSERT INTO `hms_physical_record` VALUES ('60', '2', '4', '2017-11-28 09:57:02', null, '17', '8', '2017-11-28 09:57:04');
INSERT INTO `hms_physical_record` VALUES ('61', '2', '4', '2017-11-28 09:57:28', null, '18', '8', '2017-11-28 09:57:29');
INSERT INTO `hms_physical_record` VALUES ('62', '2', '4', '2017-11-28 10:01:16', null, '19', '8', '2017-11-28 10:01:18');
INSERT INTO `hms_physical_record` VALUES ('63', '2', '4', '2017-11-28 10:03:05', null, '20', '8', '2017-11-28 10:03:07');
INSERT INTO `hms_physical_record` VALUES ('64', '2', '2', '2017-11-28 10:09:55', null, '19', '8', '2017-11-28 10:09:56');
INSERT INTO `hms_physical_record` VALUES ('65', '2', '5', '2017-11-28 10:09:55', null, '13', '8', '2017-11-28 10:09:56');
INSERT INTO `hms_physical_record` VALUES ('66', '5', '2', '2017-11-28 10:18:22', null, '20', '12', '2017-11-28 10:18:24');
INSERT INTO `hms_physical_record` VALUES ('67', '5', '5', '2017-11-28 10:18:22', null, '14', '12', '2017-11-28 10:18:24');
INSERT INTO `hms_physical_record` VALUES ('68', '6', '4', '2017-11-28 13:33:43', null, '21', '13', '2017-11-28 13:33:45');
INSERT INTO `hms_physical_record` VALUES ('69', '6', '4', '2017-11-28 17:38:28', null, '22', '13', '2017-11-28 17:38:36');
INSERT INTO `hms_physical_record` VALUES ('70', '6', '4', '2017-11-28 17:40:20', null, '23', '13', '2017-11-28 17:40:23');
INSERT INTO `hms_physical_record` VALUES ('71', '6', '4', '2017-11-29 16:18:51', null, '24', '13', '2017-11-29 16:18:54');
INSERT INTO `hms_physical_record` VALUES ('72', '6', '4', '2017-11-30 09:26:21', null, '25', '13', '2017-11-30 09:26:24');
INSERT INTO `hms_physical_record` VALUES ('73', '6', '1', '2017-11-30 09:30:47', null, '14', '13', '2017-11-30 09:30:49');
INSERT INTO `hms_physical_record` VALUES ('74', '6', '1', '2017-11-30 09:31:16', null, '15', '13', '2017-11-30 09:31:18');
INSERT INTO `hms_physical_record` VALUES ('75', '6', '3', '2017-11-30 09:40:00', null, '5', '13', '2017-11-30 09:40:02');
INSERT INTO `hms_physical_record` VALUES ('76', '6', '3', '2017-11-30 09:47:11', null, '6', '13', '2017-11-30 09:47:14');
INSERT INTO `hms_physical_record` VALUES ('77', '6', '4', '2017-11-30 09:52:37', null, '26', '13', '2017-11-30 09:52:39');
INSERT INTO `hms_physical_record` VALUES ('78', '6', '2', '2017-11-30 09:53:57', null, '21', '13', '2017-11-30 09:54:00');
INSERT INTO `hms_physical_record` VALUES ('79', '6', '5', '2017-11-30 09:53:57', null, '15', '13', '2017-11-30 09:54:00');
INSERT INTO `hms_physical_record` VALUES ('80', '6', '1', '2017-11-30 17:33:57', null, '16', '13', '2017-11-30 17:34:00');
INSERT INTO `hms_physical_record` VALUES ('81', '6', '1', '2017-12-01 10:30:02', null, '17', '13', '2017-12-01 10:30:05');
INSERT INTO `hms_physical_record` VALUES ('82', '12', '4', '2017-12-01 11:00:58', null, '27', '20', '2017-12-01 11:01:00');
INSERT INTO `hms_physical_record` VALUES ('83', '12', '4', '2017-12-01 11:01:21', null, '28', '20', '2017-12-01 11:01:23');
INSERT INTO `hms_physical_record` VALUES ('84', '12', '1', '2017-12-01 12:31:08', null, '18', '20', '2017-12-01 12:31:10');
INSERT INTO `hms_physical_record` VALUES ('85', '12', '1', '2017-12-01 12:32:03', null, '19', '20', '2017-12-01 12:32:05');
INSERT INTO `hms_physical_record` VALUES ('86', '12', '1', '2017-12-01 13:18:30', null, '20', '20', '2017-12-01 13:18:32');
INSERT INTO `hms_physical_record` VALUES ('87', '12', '1', '2017-12-01 13:23:34', null, '21', '20', '2017-12-01 13:23:36');
INSERT INTO `hms_physical_record` VALUES ('88', '12', '1', '2017-12-01 19:04:37', null, '22', '20', '2017-12-01 19:04:38');
INSERT INTO `hms_physical_record` VALUES ('89', '12', '1', '2017-12-01 19:08:06', null, '23', '20', '2017-12-01 19:08:08');
INSERT INTO `hms_physical_record` VALUES ('90', '12', '1', '2017-12-01 20:23:21', null, '24', '20', '2017-12-01 20:23:23');
INSERT INTO `hms_physical_record` VALUES ('91', '12', '4', '2017-12-04 10:08:51', '正常指标', '29', '20', '2017-12-04 10:08:54');
INSERT INTO `hms_physical_record` VALUES ('92', '12', '1', '2017-12-04 10:57:10', '', '27', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('93', '12', '1', '2017-12-04 10:57:10', '', '28', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('94', '12', '1', '2017-12-04 10:57:10', '', '26', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('95', '12', '1', '2017-12-04 10:57:10', '', '29', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('96', '12', '1', '2017-12-04 10:57:10', '', '25', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('97', '12', '1', '2017-12-04 10:57:10', '', '30', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('98', '12', '1', '2017-12-04 10:57:10', '', '31', '20', '2017-12-04 10:57:36');
INSERT INTO `hms_physical_record` VALUES ('99', '12', '1', '2017-12-04 10:57:10', '', '32', '20', '2017-12-04 10:58:34');
INSERT INTO `hms_physical_record` VALUES ('100', '12', '1', '2017-12-04 10:57:10', '', '33', '20', '2017-12-04 10:59:24');
INSERT INTO `hms_physical_record` VALUES ('101', '12', '1', '2017-12-04 10:57:10', '', '34', '20', '2017-12-04 10:59:28');
INSERT INTO `hms_physical_record` VALUES ('102', '12', '1', '2017-12-04 10:57:10', '', '35', '20', '2017-12-04 10:59:31');
INSERT INTO `hms_physical_record` VALUES ('103', '12', '1', '2017-12-04 10:57:10', '', '36', '20', '2017-12-04 10:59:31');
INSERT INTO `hms_physical_record` VALUES ('104', '12', '1', '2017-12-04 10:57:10', '', '37', '20', '2017-12-04 10:59:33');
INSERT INTO `hms_physical_record` VALUES ('105', '12', '1', '2017-12-04 10:57:10', '', '38', '20', '2017-12-04 10:59:36');
INSERT INTO `hms_physical_record` VALUES ('106', '12', '1', '2017-12-04 10:57:10', '', '39', '20', '2017-12-04 10:59:38');
INSERT INTO `hms_physical_record` VALUES ('107', '12', '1', '2017-12-04 10:57:10', '', '40', '20', '2017-12-04 10:59:58');
INSERT INTO `hms_physical_record` VALUES ('108', '12', '1', '2017-12-04 10:57:10', '', '41', '20', '2017-12-04 11:00:28');
INSERT INTO `hms_physical_record` VALUES ('109', '12', '1', '2017-12-04 10:57:10', '', '43', '20', '2017-12-04 11:00:43');
INSERT INTO `hms_physical_record` VALUES ('110', '12', '1', '2017-12-04 10:57:10', '', '42', '20', '2017-12-04 11:00:43');
INSERT INTO `hms_physical_record` VALUES ('111', '12', '1', '2017-12-04 10:57:10', '', '44', '20', '2017-12-04 11:01:20');
INSERT INTO `hms_physical_record` VALUES ('112', '12', '1', '2017-12-04 11:28:02', '偏瘦', '45', '20', '2017-12-04 11:28:54');
INSERT INTO `hms_physical_record` VALUES ('113', '12', '1', '2017-12-04 11:28:02', '偏瘦', '46', '20', '2017-12-04 11:29:00');
INSERT INTO `hms_physical_record` VALUES ('114', '12', '1', '2017-12-04 11:28:02', '偏瘦', '48', '20', '2017-12-04 11:29:01');
INSERT INTO `hms_physical_record` VALUES ('115', '12', '1', '2017-12-04 11:28:02', '偏瘦', '47', '20', '2017-12-04 11:29:01');
INSERT INTO `hms_physical_record` VALUES ('116', '12', '1', '2017-12-04 11:28:02', '偏瘦', '49', '20', '2017-12-04 11:29:01');
INSERT INTO `hms_physical_record` VALUES ('117', '12', '1', '2017-12-04 11:28:02', '偏瘦', '50', '20', '2017-12-04 11:29:01');
INSERT INTO `hms_physical_record` VALUES ('118', '12', '1', '2017-12-04 11:28:02', '偏瘦', '52', '20', '2017-12-04 11:29:02');
INSERT INTO `hms_physical_record` VALUES ('119', '12', '1', '2017-12-04 11:28:02', '偏瘦', '51', '20', '2017-12-04 11:29:01');
INSERT INTO `hms_physical_record` VALUES ('120', '12', '1', '2017-12-04 11:28:02', '偏瘦', '53', '20', '2017-12-04 11:29:04');
INSERT INTO `hms_physical_record` VALUES ('121', '12', '1', '2017-12-04 11:28:02', '偏瘦', '54', '20', '2017-12-04 11:29:05');
INSERT INTO `hms_physical_record` VALUES ('122', '12', '1', '2017-12-04 11:28:02', '偏瘦', '55', '20', '2017-12-04 11:29:06');
INSERT INTO `hms_physical_record` VALUES ('123', '12', '1', '2017-12-04 11:28:02', '偏瘦', '56', '20', '2017-12-04 11:29:06');
INSERT INTO `hms_physical_record` VALUES ('124', '12', '1', '2017-12-04 11:28:02', '偏瘦', '57', '20', '2017-12-04 11:29:06');
INSERT INTO `hms_physical_record` VALUES ('125', '12', '1', '2017-12-04 11:28:02', '偏瘦', '58', '20', '2017-12-04 11:29:06');
INSERT INTO `hms_physical_record` VALUES ('126', '12', '1', '2017-12-04 11:28:02', '偏瘦', '59', '20', '2017-12-04 11:29:06');
INSERT INTO `hms_physical_record` VALUES ('127', '12', '1', '2017-12-04 11:28:02', '偏瘦', '60', '20', '2017-12-04 11:29:07');
INSERT INTO `hms_physical_record` VALUES ('128', '12', '1', '2017-12-04 11:28:02', '偏瘦', '61', '20', '2017-12-04 11:29:09');
INSERT INTO `hms_physical_record` VALUES ('129', '12', '1', '2017-12-04 11:28:02', '偏瘦', '62', '20', '2017-12-04 11:29:10');
INSERT INTO `hms_physical_record` VALUES ('130', '12', '1', '2017-12-04 11:28:02', '偏瘦', '63', '20', '2017-12-04 11:29:10');
INSERT INTO `hms_physical_record` VALUES ('131', '12', '1', '2017-12-04 11:28:02', '偏瘦', '64', '20', '2017-12-04 11:29:12');
INSERT INTO `hms_physical_record` VALUES ('132', '12', '1', '2017-12-04 11:30:56', '肥胖', '65', '20', '2017-12-04 11:31:08');
INSERT INTO `hms_physical_record` VALUES ('133', '12', '1', '2017-12-04 11:30:56', '肥胖', '67', '20', '2017-12-04 11:31:21');
INSERT INTO `hms_physical_record` VALUES ('134', '12', '1', '2017-12-04 11:30:56', '肥胖', '66', '20', '2017-12-04 11:31:09');
INSERT INTO `hms_physical_record` VALUES ('135', '12', '1', '2017-12-04 11:30:56', '肥胖', '68', '20', '2017-12-04 11:31:22');
INSERT INTO `hms_physical_record` VALUES ('136', '12', '1', '2017-12-04 11:30:56', '肥胖', '69', '20', '2017-12-04 11:31:23');
INSERT INTO `hms_physical_record` VALUES ('137', '12', '1', '2017-12-04 11:30:56', '肥胖', '70', '20', '2017-12-04 11:31:23');
INSERT INTO `hms_physical_record` VALUES ('138', '12', '1', '2017-12-04 11:30:56', '肥胖', '71', '20', '2017-12-04 11:31:24');
INSERT INTO `hms_physical_record` VALUES ('139', '12', '1', '2017-12-04 11:30:56', '肥胖', '72', '20', '2017-12-04 11:31:23');
INSERT INTO `hms_physical_record` VALUES ('140', '12', '1', '2017-12-04 11:30:56', '肥胖', '73', '20', '2017-12-04 11:31:25');
INSERT INTO `hms_physical_record` VALUES ('141', '12', '1', '2017-12-04 11:30:56', '肥胖', '74', '20', '2017-12-04 11:31:26');
INSERT INTO `hms_physical_record` VALUES ('142', '12', '1', '2017-12-04 11:30:56', '肥胖', '75', '20', '2017-12-04 11:31:27');
INSERT INTO `hms_physical_record` VALUES ('143', '12', '1', '2017-12-04 11:30:56', '肥胖', '76', '20', '2017-12-04 11:31:28');
INSERT INTO `hms_physical_record` VALUES ('144', '12', '1', '2017-12-04 11:34:24', '肥胖', '77', '20', '2017-12-04 11:36:05');
INSERT INTO `hms_physical_record` VALUES ('145', '12', '1', '2017-12-04 11:34:24', '肥胖', '78', '20', '2017-12-04 11:36:07');
INSERT INTO `hms_physical_record` VALUES ('146', '12', '1', '2017-12-04 11:34:24', '肥胖', '80', '20', '2017-12-04 11:36:08');
INSERT INTO `hms_physical_record` VALUES ('147', '12', '1', '2017-12-04 11:34:24', '肥胖', '79', '20', '2017-12-04 11:36:07');
INSERT INTO `hms_physical_record` VALUES ('148', '12', '1', '2017-12-04 11:34:24', '肥胖', '84', '20', '2017-12-04 11:36:09');
INSERT INTO `hms_physical_record` VALUES ('149', '12', '1', '2017-12-04 11:34:24', '肥胖', '81', '20', '2017-12-04 11:36:08');
INSERT INTO `hms_physical_record` VALUES ('150', '12', '1', '2017-12-04 11:34:24', '肥胖', '82', '20', '2017-12-04 11:36:08');
INSERT INTO `hms_physical_record` VALUES ('151', '12', '1', '2017-12-04 11:34:24', '肥胖', '83', '20', '2017-12-04 11:36:08');
INSERT INTO `hms_physical_record` VALUES ('152', '12', '1', '2017-12-04 11:34:24', '肥胖', '85', '20', '2017-12-04 11:36:10');
INSERT INTO `hms_physical_record` VALUES ('153', '12', '1', '2017-12-04 11:34:24', '肥胖', '86', '20', '2017-12-04 11:36:11');
INSERT INTO `hms_physical_record` VALUES ('154', '12', '1', '2017-12-04 11:34:24', '肥胖', '87', '20', '2017-12-04 11:36:12');
INSERT INTO `hms_physical_record` VALUES ('155', '12', '1', '2017-12-04 11:34:24', '肥胖', '88', '20', '2017-12-04 11:36:12');
INSERT INTO `hms_physical_record` VALUES ('156', '12', '1', '2017-12-04 11:34:24', '肥胖', '89', '20', '2017-12-04 11:36:13');
INSERT INTO `hms_physical_record` VALUES ('157', '12', '1', '2017-12-04 11:34:24', '肥胖', '91', '20', '2017-12-04 11:36:12');
INSERT INTO `hms_physical_record` VALUES ('158', '12', '1', '2017-12-04 11:34:24', '肥胖', '90', '20', '2017-12-04 11:36:12');
INSERT INTO `hms_physical_record` VALUES ('159', '12', '1', '2017-12-04 11:34:24', '肥胖', '92', '20', '2017-12-04 11:36:12');
INSERT INTO `hms_physical_record` VALUES ('160', '12', '1', '2017-12-04 11:34:24', '肥胖', '93', '20', '2017-12-04 11:36:14');
INSERT INTO `hms_physical_record` VALUES ('161', '12', '1', '2017-12-04 11:34:24', '肥胖', '95', '20', '2017-12-04 11:36:15');
INSERT INTO `hms_physical_record` VALUES ('162', '12', '1', '2017-12-04 11:34:24', '肥胖', '94', '20', '2017-12-04 11:36:14');
INSERT INTO `hms_physical_record` VALUES ('163', '12', '1', '2017-12-04 11:34:24', '肥胖', '96', '20', '2017-12-04 11:36:15');
INSERT INTO `hms_physical_record` VALUES ('164', '12', '1', '2017-12-04 11:37:34', '肥胖', '97', '20', '2017-12-04 11:38:30');
INSERT INTO `hms_physical_record` VALUES ('165', '12', '1', '2017-12-04 11:37:34', '肥胖', '98', '20', '2017-12-04 11:38:31');
INSERT INTO `hms_physical_record` VALUES ('166', '12', '1', '2017-12-04 11:37:34', '肥胖', '99', '20', '2017-12-04 11:38:32');
INSERT INTO `hms_physical_record` VALUES ('167', '12', '1', '2017-12-04 11:37:34', '肥胖', '100', '20', '2017-12-04 11:38:31');
INSERT INTO `hms_physical_record` VALUES ('168', '12', '1', '2017-12-04 11:37:34', '肥胖', '102', '20', '2017-12-04 11:38:32');
INSERT INTO `hms_physical_record` VALUES ('169', '12', '1', '2017-12-04 11:37:34', '肥胖', '101', '20', '2017-12-04 11:38:32');
INSERT INTO `hms_physical_record` VALUES ('170', '12', '1', '2017-12-04 11:37:34', '肥胖', '103', '20', '2017-12-04 11:38:33');
INSERT INTO `hms_physical_record` VALUES ('171', '12', '1', '2017-12-04 11:37:34', '肥胖', '104', '20', '2017-12-04 11:38:34');
INSERT INTO `hms_physical_record` VALUES ('172', '12', '1', '2017-12-04 11:37:34', '肥胖', '105', '20', '2017-12-04 11:38:35');
INSERT INTO `hms_physical_record` VALUES ('173', '12', '1', '2017-12-04 11:37:34', '肥胖', '106', '20', '2017-12-04 11:38:35');
INSERT INTO `hms_physical_record` VALUES ('174', '12', '1', '2017-12-04 11:37:34', '肥胖', '107', '20', '2017-12-04 11:38:36');
INSERT INTO `hms_physical_record` VALUES ('175', '12', '1', '2017-12-04 11:37:34', '肥胖', '108', '20', '2017-12-04 11:38:37');
INSERT INTO `hms_physical_record` VALUES ('176', '12', '1', '2017-12-04 11:37:34', '肥胖', '109', '20', '2017-12-04 11:38:38');
INSERT INTO `hms_physical_record` VALUES ('177', '12', '1', '2017-12-04 11:37:34', '肥胖', '110', '20', '2017-12-04 11:38:38');
INSERT INTO `hms_physical_record` VALUES ('178', '12', '1', '2017-12-04 11:37:34', '肥胖', '112', '20', '2017-12-04 11:38:40');
INSERT INTO `hms_physical_record` VALUES ('179', '12', '1', '2017-12-04 11:37:34', '肥胖', '111', '20', '2017-12-04 11:38:39');
INSERT INTO `hms_physical_record` VALUES ('180', '12', '1', '2017-12-04 11:37:34', '肥胖', '114', '20', '2017-12-04 11:38:40');
INSERT INTO `hms_physical_record` VALUES ('181', '12', '1', '2017-12-04 11:37:34', '肥胖', '115', '20', '2017-12-04 11:38:40');
INSERT INTO `hms_physical_record` VALUES ('182', '12', '1', '2017-12-04 11:37:34', '肥胖', '113', '20', '2017-12-04 11:38:40');
INSERT INTO `hms_physical_record` VALUES ('183', '12', '1', '2017-12-04 11:37:34', '肥胖', '116', '20', '2017-12-04 11:38:41');
INSERT INTO `hms_physical_record` VALUES ('184', '12', '1', '2017-12-04 11:41:09', '肥胖', '118', '20', '2017-12-04 11:41:21');
INSERT INTO `hms_physical_record` VALUES ('185', '12', '1', '2017-12-04 11:41:09', '肥胖', '117', '20', '2017-12-04 11:41:21');
INSERT INTO `hms_physical_record` VALUES ('186', '12', '1', '2017-12-04 11:41:09', '肥胖', '119', '20', '2017-12-04 11:41:22');
INSERT INTO `hms_physical_record` VALUES ('187', '12', '1', '2017-12-04 11:41:09', '肥胖', '120', '20', '2017-12-04 11:41:25');
INSERT INTO `hms_physical_record` VALUES ('188', '12', '1', '2017-12-04 11:41:09', '肥胖', '121', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('189', '12', '1', '2017-12-04 11:41:09', '肥胖', '124', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('190', '12', '1', '2017-12-04 11:41:09', '肥胖', '126', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('191', '12', '1', '2017-12-04 11:41:09', '肥胖', '123', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('192', '12', '1', '2017-12-04 11:41:09', '肥胖', '122', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('193', '12', '1', '2017-12-04 11:41:09', '肥胖', '125', '20', '2017-12-04 11:48:39');
INSERT INTO `hms_physical_record` VALUES ('194', '12', '1', '2017-12-04 11:41:09', '肥胖', '127', '20', '2017-12-04 11:50:35');
INSERT INTO `hms_physical_record` VALUES ('195', '12', '1', '2017-12-04 11:41:09', '肥胖', '128', '20', '2017-12-04 11:50:36');
INSERT INTO `hms_physical_record` VALUES ('196', '12', '1', '2017-12-04 11:41:09', '肥胖', '129', '20', '2017-12-04 11:50:45');
INSERT INTO `hms_physical_record` VALUES ('197', '12', '1', '2017-12-04 11:41:09', '肥胖', '132', '20', '2017-12-04 11:50:46');
INSERT INTO `hms_physical_record` VALUES ('198', '12', '1', '2017-12-04 11:41:09', '肥胖', '130', '20', '2017-12-04 11:50:45');
INSERT INTO `hms_physical_record` VALUES ('199', '12', '1', '2017-12-04 11:41:09', '肥胖', '131', '20', '2017-12-04 11:50:45');
INSERT INTO `hms_physical_record` VALUES ('200', '12', '1', '2017-12-04 11:41:09', '肥胖', '133', '20', '2017-12-04 11:50:46');
INSERT INTO `hms_physical_record` VALUES ('201', '12', '1', '2017-12-04 11:41:09', '肥胖', '134', '20', '2017-12-04 11:50:46');
INSERT INTO `hms_physical_record` VALUES ('202', '12', '1', '2017-12-04 11:41:09', '肥胖', '136', '20', '2017-12-04 11:50:47');
INSERT INTO `hms_physical_record` VALUES ('203', '12', '1', '2017-12-04 11:41:09', '肥胖', '135', '20', '2017-12-04 11:50:46');
INSERT INTO `hms_physical_record` VALUES ('204', '12', '1', '2017-12-04 11:48:03', '肥胖', '137', '20', '2017-12-04 11:50:47');
INSERT INTO `hms_physical_record` VALUES ('205', '12', '1', '2017-12-04 11:48:03', '肥胖', '140', '20', '2017-12-04 11:50:48');
INSERT INTO `hms_physical_record` VALUES ('206', '12', '1', '2017-12-04 11:48:03', '肥胖', '139', '20', '2017-12-04 11:50:48');
INSERT INTO `hms_physical_record` VALUES ('207', '12', '1', '2017-12-04 11:48:03', '肥胖', '138', '20', '2017-12-04 11:50:49');
INSERT INTO `hms_physical_record` VALUES ('208', '12', '1', '2017-12-04 11:48:03', '肥胖', '141', '20', '2017-12-04 11:50:48');
INSERT INTO `hms_physical_record` VALUES ('209', '12', '1', '2017-12-04 11:48:03', '肥胖', '142', '20', '2017-12-04 11:50:49');
INSERT INTO `hms_physical_record` VALUES ('210', '12', '1', '2017-12-04 11:48:03', '肥胖', '143', '20', '2017-12-04 11:50:50');
INSERT INTO `hms_physical_record` VALUES ('211', '12', '1', '2017-12-04 11:48:03', '肥胖', '144', '20', '2017-12-04 11:50:52');
INSERT INTO `hms_physical_record` VALUES ('212', '12', '1', '2017-12-04 11:48:03', '肥胖', '145', '20', '2017-12-04 11:50:53');
INSERT INTO `hms_physical_record` VALUES ('213', '12', '1', '2017-12-04 11:48:03', '肥胖', '146', '20', '2017-12-04 11:50:54');
INSERT INTO `hms_physical_record` VALUES ('214', '12', '1', '2017-12-04 11:48:03', '肥胖', '147', '20', '2017-12-04 11:50:54');
INSERT INTO `hms_physical_record` VALUES ('215', '12', '1', '2017-12-04 11:48:03', '肥胖', '148', '20', '2017-12-04 11:50:54');
INSERT INTO `hms_physical_record` VALUES ('216', '12', '1', '2017-12-04 11:48:03', '肥胖', '149', '20', '2017-12-04 11:50:54');
INSERT INTO `hms_physical_record` VALUES ('217', '12', '1', '2017-12-04 11:48:03', '肥胖', '150', '20', '2017-12-04 11:50:55');
INSERT INTO `hms_physical_record` VALUES ('218', '12', '1', '2017-12-04 11:48:03', '偏胖', '151', '20', '2017-12-04 11:50:56');
INSERT INTO `hms_physical_record` VALUES ('219', '12', '1', '2017-12-04 11:48:03', '偏胖', '152', '20', '2017-12-04 11:50:56');
INSERT INTO `hms_physical_record` VALUES ('220', '12', '1', '2017-12-04 11:48:03', '偏胖', '153', '20', '2017-12-04 11:50:57');
INSERT INTO `hms_physical_record` VALUES ('221', '12', '1', '2017-12-04 11:48:03', '偏胖', '154', '20', '2017-12-04 11:50:58');
INSERT INTO `hms_physical_record` VALUES ('222', '12', '1', '2017-12-04 11:48:03', '偏胖', '155', '20', '2017-12-04 11:50:58');
INSERT INTO `hms_physical_record` VALUES ('223', '12', '1', '2017-12-04 11:48:03', '偏胖', '156', '20', '2017-12-04 11:50:59');
INSERT INTO `hms_physical_record` VALUES ('224', '12', '1', '2017-12-04 11:51:35', '偏胖', '157', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('225', '12', '1', '2017-12-04 11:51:35', '偏胖', '158', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('226', '12', '1', '2017-12-04 11:51:35', '偏胖', '159', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('227', '12', '1', '2017-12-04 11:51:35', '偏胖', '162', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('228', '12', '1', '2017-12-04 11:51:35', '偏胖', '160', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('229', '12', '1', '2017-12-04 11:51:35', '偏胖', '161', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('230', '12', '1', '2017-12-04 11:51:35', '偏胖', '163', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('231', '12', '1', '2017-12-04 11:51:35', '偏胖', '164', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('232', '12', '1', '2017-12-04 11:51:35', '偏胖', '165', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('233', '12', '1', '2017-12-04 11:51:35', '偏胖', '166', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('234', '12', '1', '2017-12-04 11:51:35', '偏胖', '167', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('235', '12', '1', '2017-12-04 11:51:35', '偏胖', '168', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('236', '12', '1', '2017-12-04 11:51:35', '偏胖', '169', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('237', '12', '1', '2017-12-04 11:51:35', '偏胖', '170', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('238', '12', '1', '2017-12-04 11:51:35', '偏胖', '171', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('239', '12', '1', '2017-12-04 11:51:35', '偏胖', '172', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('240', '12', '1', '2017-12-04 11:51:35', '偏胖', '173', '20', '2017-12-04 11:52:43');
INSERT INTO `hms_physical_record` VALUES ('241', '12', '1', '2017-12-04 11:51:35', '偏胖', '174', '20', '2017-12-04 11:52:44');
INSERT INTO `hms_physical_record` VALUES ('242', '12', '1', '2017-12-04 11:51:35', '偏胖', '175', '20', '2017-12-04 11:52:44');
INSERT INTO `hms_physical_record` VALUES ('243', '12', '1', '2017-12-04 11:51:35', '偏胖', '176', '20', '2017-12-04 11:52:44');
INSERT INTO `hms_physical_record` VALUES ('244', '12', '1', '2017-12-04 11:56:16', '正常', '177', '20', '2017-12-04 11:56:18');
INSERT INTO `hms_physical_record` VALUES ('245', '12', '1', '2017-12-04 12:07:57', null, '178', '20', '2017-12-04 12:08:00');
INSERT INTO `hms_physical_record` VALUES ('246', '20', '4', '2018-01-26 12:32:28', '正常指标', '30', '29', '2018-01-26 12:32:30');
INSERT INTO `hms_physical_record` VALUES ('247', '20', '4', '2018-01-26 12:32:43', '正常指标', '31', '29', '2018-01-26 12:32:46');
INSERT INTO `hms_physical_record` VALUES ('248', '20', '4', '2018-01-26 12:33:00', '正常指标', '32', '29', '2018-01-26 12:33:02');
INSERT INTO `hms_physical_record` VALUES ('249', '20', '1', '2018-01-26 12:33:31', '偏瘦', '179', '29', '2018-01-26 12:33:32');
INSERT INTO `hms_physical_record` VALUES ('250', '20', '1', '2018-01-26 12:33:51', '偏胖', '180', '29', '2018-01-26 12:33:53');
INSERT INTO `hms_physical_record` VALUES ('251', '20', '1', '2018-01-26 12:34:06', '偏瘦', '181', '29', '2018-01-26 12:34:08');
INSERT INTO `hms_physical_record` VALUES ('252', '20', '4', '2018-01-26 12:37:31', '正常指标', '33', '29', '2018-01-26 12:37:33');
INSERT INTO `hms_physical_record` VALUES ('253', '20', '1', '2018-01-26 12:47:49', '正常', '182', '29', '2018-01-26 12:47:50');
INSERT INTO `hms_physical_record` VALUES ('254', '20', '4', '2018-01-26 12:53:56', '正常指标', '34', '29', '2018-01-26 12:53:59');
INSERT INTO `hms_physical_record` VALUES ('255', '20', '2', '2018-01-26 12:59:18', '数值异常', '22', '29', '2018-01-26 12:59:20');
INSERT INTO `hms_physical_record` VALUES ('256', '20', '5', '2018-01-26 12:59:18', '正常区间', '16', '29', '2018-01-26 12:59:20');
INSERT INTO `hms_physical_record` VALUES ('257', '20', '3', '2018-01-26 13:01:12', '血糖偏高', '7', '29', '2018-01-26 13:01:14');
INSERT INTO `hms_physical_record` VALUES ('258', '20', '4', '2018-01-26 13:04:59', '正常指标', '35', '29', '2018-01-26 13:05:01');
INSERT INTO `hms_physical_record` VALUES ('259', '20', '4', '2018-01-26 13:05:35', '正常指标', '36', '29', '2018-01-26 13:05:36');
INSERT INTO `hms_physical_record` VALUES ('260', '20', '4', '2018-01-26 13:06:35', '正常指标', '37', '29', '2018-01-26 13:06:37');
INSERT INTO `hms_physical_record` VALUES ('261', '20', '9', '2018-01-27 21:59:52', '北京市昌平区龙禧三街', '1', '29', '2018-01-27 21:59:53');
INSERT INTO `hms_physical_record` VALUES ('262', '20', '9', '2018-01-27 22:04:54', '北京市昌平区回龙观西大街95号', '2', '29', '2018-01-27 22:04:56');
INSERT INTO `hms_physical_record` VALUES ('263', '20', '9', '2018-01-27 22:09:53', '北京市昌平区回龙观西大街95号', '3', '29', '2018-01-27 22:09:55');
INSERT INTO `hms_physical_record` VALUES ('264', '20', '9', '2018-01-27 22:14:53', '北京市昌平区龙禧三街', '4', '29', '2018-01-27 22:14:54');
INSERT INTO `hms_physical_record` VALUES ('265', '20', '9', '2018-01-27 22:19:53', '北京市昌平区龙禧三街', '5', '29', '2018-01-27 22:19:54');
INSERT INTO `hms_physical_record` VALUES ('266', '20', '9', '2018-01-27 22:24:52', '北京市昌平区龙禧三街', '6', '29', '2018-01-27 22:24:55');
INSERT INTO `hms_physical_record` VALUES ('267', '20', '9', '2018-01-27 22:29:52', '北京市昌平区龙禧三街', '7', '29', '2018-01-27 22:29:54');
INSERT INTO `hms_physical_record` VALUES ('268', '20', '9', '2018-01-27 22:34:52', '北京市昌平区龙禧三街', '8', '29', '2018-01-27 22:34:54');
INSERT INTO `hms_physical_record` VALUES ('269', '20', '9', '2018-01-27 22:39:53', '北京市昌平区龙禧三街', '9', '29', '2018-01-27 22:39:54');
INSERT INTO `hms_physical_record` VALUES ('270', '20', '9', '2018-01-27 22:44:53', '北京市昌平区龙禧三街', '10', '29', '2018-01-27 22:44:56');
INSERT INTO `hms_physical_record` VALUES ('271', '20', '9', '2018-01-27 22:49:54', '北京市昌平区龙禧三街', '11', '29', '2018-01-27 22:49:55');
INSERT INTO `hms_physical_record` VALUES ('272', '20', '9', '2018-01-27 22:54:54', '北京市昌平区龙禧三街', '12', '29', '2018-01-27 22:54:56');
INSERT INTO `hms_physical_record` VALUES ('273', '20', '9', '2018-01-27 22:59:53', '北京市昌平区龙禧三街', '13', '29', '2018-01-27 22:59:55');
INSERT INTO `hms_physical_record` VALUES ('274', '20', '9', '2018-01-27 23:04:53', '北京市昌平区龙禧三街', '14', '29', '2018-01-27 23:04:55');
INSERT INTO `hms_physical_record` VALUES ('275', '20', '9', '2018-01-27 23:09:53', '北京市昌平区回龙观西大街95号', '15', '29', '2018-01-27 23:09:55');
INSERT INTO `hms_physical_record` VALUES ('276', '20', '9', '2018-01-27 23:14:54', '北京市昌平区龙禧三街', '16', '29', '2018-01-27 23:14:55');
INSERT INTO `hms_physical_record` VALUES ('277', '20', '9', '2018-01-27 23:19:54', '北京市昌平区龙禧三街', '17', '29', '2018-01-27 23:19:56');
INSERT INTO `hms_physical_record` VALUES ('278', '20', '9', '2018-01-27 23:24:54', '北京市昌平区龙禧三街', '18', '29', '2018-01-27 23:24:56');
INSERT INTO `hms_physical_record` VALUES ('279', '20', '9', '2018-01-27 23:29:54', '北京市昌平区龙禧三街', '19', '29', '2018-01-27 23:29:56');
INSERT INTO `hms_physical_record` VALUES ('280', '20', '9', '2018-01-27 23:34:54', '北京市昌平区龙禧三街', '20', '29', '2018-01-27 23:34:55');
INSERT INTO `hms_physical_record` VALUES ('281', '20', '9', '2018-01-27 23:40:34', '北京市昌平区龙禧三街', '21', '29', '2018-01-27 23:40:35');
INSERT INTO `hms_physical_record` VALUES ('282', '20', '9', '2018-01-27 23:44:54', '北京市昌平区龙禧三街', '22', '29', '2018-01-27 23:44:55');
INSERT INTO `hms_physical_record` VALUES ('283', '20', '9', '2018-01-27 23:49:54', '北京市昌平区龙禧三街', '23', '29', '2018-01-27 23:49:55');
INSERT INTO `hms_physical_record` VALUES ('284', '20', '9', '2018-01-27 23:54:54', '北京市昌平区龙禧三街', '24', '29', '2018-01-27 23:54:55');
INSERT INTO `hms_physical_record` VALUES ('285', '20', '9', '2018-01-27 23:59:54', '北京市昌平区龙禧三街', '25', '29', '2018-01-27 23:59:56');
INSERT INTO `hms_physical_record` VALUES ('286', '20', '9', '2018-01-28 00:04:54', '北京市昌平区龙禧三街', '26', '29', '2018-01-28 00:04:56');
INSERT INTO `hms_physical_record` VALUES ('287', '20', '9', '2018-01-28 00:09:54', '北京市昌平区龙禧三街', '27', '29', '2018-01-28 00:09:55');
INSERT INTO `hms_physical_record` VALUES ('288', '20', '9', '2018-01-28 00:19:53', '北京市昌平区龙禧三街', '28', '29', '2018-01-28 00:19:55');
INSERT INTO `hms_physical_record` VALUES ('289', '20', '9', '2018-01-28 00:24:54', '北京市昌平区回龙观西大街95号', '29', '29', '2018-01-28 00:24:56');
INSERT INTO `hms_physical_record` VALUES ('290', '20', '9', '2018-01-28 00:29:54', '北京市昌平区龙禧三街', '30', '29', '2018-01-28 00:29:56');
INSERT INTO `hms_physical_record` VALUES ('291', '20', '9', '2018-01-28 00:34:54', '北京市昌平区龙禧三街', '31', '29', '2018-01-28 00:34:56');
INSERT INTO `hms_physical_record` VALUES ('292', '20', '9', '2018-01-28 00:39:54', '北京市昌平区龙禧三街', '32', '29', '2018-01-28 00:39:56');
INSERT INTO `hms_physical_record` VALUES ('293', '20', '9', '2018-01-28 00:44:54', '北京市昌平区龙禧三街', '33', '29', '2018-01-28 00:44:56');
INSERT INTO `hms_physical_record` VALUES ('294', '20', '9', '2018-01-28 00:50:34', '北京市昌平区龙禧三街', '34', '29', '2018-01-28 00:50:36');
INSERT INTO `hms_physical_record` VALUES ('295', '20', '9', '2018-01-28 00:54:54', '北京市昌平区龙禧三街', '35', '29', '2018-01-28 00:54:56');
INSERT INTO `hms_physical_record` VALUES ('296', '20', '9', '2018-01-28 00:59:54', '北京市昌平区龙禧三街', '36', '29', '2018-01-28 00:59:56');
INSERT INTO `hms_physical_record` VALUES ('297', '20', '9', '2018-01-28 01:04:54', '北京市昌平区龙禧三街', '37', '29', '2018-01-28 01:04:56');
INSERT INTO `hms_physical_record` VALUES ('298', '20', '9', '2018-01-28 01:09:54', '北京市昌平区龙禧三街', '38', '29', '2018-01-28 01:09:56');
INSERT INTO `hms_physical_record` VALUES ('299', '20', '9', '2018-01-28 01:14:55', '北京市昌平区龙禧三街', '39', '29', '2018-01-28 01:14:57');
INSERT INTO `hms_physical_record` VALUES ('300', '20', '9', '2018-01-28 01:19:54', '北京市昌平区龙禧三街', '40', '29', '2018-01-28 01:19:56');
INSERT INTO `hms_physical_record` VALUES ('301', '20', '9', '2018-01-28 01:25:34', '北京市昌平区龙禧三街', '41', '29', '2018-01-28 01:25:37');
INSERT INTO `hms_physical_record` VALUES ('302', '20', '9', '2018-01-28 01:49:55', '北京市昌平区龙禧三街', '42', '29', '2018-01-28 01:49:58');
INSERT INTO `hms_physical_record` VALUES ('303', '20', '9', '2018-01-28 01:59:55', '北京市昌平区龙禧三街', '43', '29', '2018-01-28 01:59:58');
INSERT INTO `hms_physical_record` VALUES ('304', '20', '9', '2018-01-28 02:04:55', '北京市昌平区龙禧三街', '44', '29', '2018-01-28 02:04:59');
INSERT INTO `hms_physical_record` VALUES ('305', '20', '9', '2018-01-28 02:19:56', '北京市昌平区龙禧三街', '45', '29', '2018-01-28 02:19:58');
INSERT INTO `hms_physical_record` VALUES ('306', '20', '9', '2018-01-28 02:29:55', '北京市昌平区龙禧三街', '46', '29', '2018-01-28 02:29:58');
INSERT INTO `hms_physical_record` VALUES ('307', '20', '9', '2018-01-28 02:34:56', '北京市昌平区龙禧三街', '47', '29', '2018-01-28 02:34:58');
INSERT INTO `hms_physical_record` VALUES ('308', '20', '9', '2018-01-28 02:44:56', '北京市昌平区龙禧三街', '48', '29', '2018-01-28 02:44:58');
INSERT INTO `hms_physical_record` VALUES ('309', '20', '9', '2018-01-28 02:49:56', '北京市昌平区龙禧三街', '49', '29', '2018-01-28 02:50:00');
INSERT INTO `hms_physical_record` VALUES ('310', '20', '9', '2018-01-28 02:54:56', '北京市昌平区龙禧三街', '50', '29', '2018-01-28 02:54:58');
INSERT INTO `hms_physical_record` VALUES ('311', '20', '9', '2018-01-28 02:59:56', '北京市昌平区龙禧三街', '51', '29', '2018-01-28 02:59:58');
INSERT INTO `hms_physical_record` VALUES ('312', '20', '9', '2018-01-28 03:09:57', '北京市昌平区龙禧三街', '52', '29', '2018-01-28 03:10:00');
INSERT INTO `hms_physical_record` VALUES ('313', '20', '9', '2018-01-28 03:29:57', '北京市昌平区龙禧三街', '53', '29', '2018-01-28 03:29:59');
INSERT INTO `hms_physical_record` VALUES ('314', '20', '9', '2018-01-28 03:34:57', '北京市昌平区龙禧三街', '54', '29', '2018-01-28 03:34:59');
INSERT INTO `hms_physical_record` VALUES ('315', '20', '9', '2018-01-28 03:39:57', '北京市昌平区龙禧三街', '55', '29', '2018-01-28 03:40:00');
INSERT INTO `hms_physical_record` VALUES ('316', '20', '9', '2018-01-28 03:54:58', '北京市昌平区龙禧三街', '56', '29', '2018-01-28 03:55:00');
INSERT INTO `hms_physical_record` VALUES ('317', '20', '9', '2018-01-28 03:59:59', '北京市昌平区龙禧三街', '57', '29', '2018-01-28 04:00:00');
INSERT INTO `hms_physical_record` VALUES ('318', '20', '9', '2018-01-28 04:04:58', '北京市昌平区龙禧三街', '58', '29', '2018-01-28 04:05:00');
INSERT INTO `hms_physical_record` VALUES ('319', '20', '9', '2018-01-28 04:09:58', '北京市昌平区龙禧三街', '59', '29', '2018-01-28 04:10:00');
INSERT INTO `hms_physical_record` VALUES ('320', '20', '9', '2018-01-28 04:14:58', '北京市昌平区龙禧三街', '60', '29', '2018-01-28 04:15:00');
INSERT INTO `hms_physical_record` VALUES ('321', '20', '9', '2018-01-28 04:19:59', '北京市昌平区龙禧三街', '61', '29', '2018-01-28 04:20:01');
INSERT INTO `hms_physical_record` VALUES ('322', '20', '9', '2018-01-28 04:24:59', '北京市昌平区龙禧三街', '62', '29', '2018-01-28 04:25:00');
INSERT INTO `hms_physical_record` VALUES ('323', '20', '9', '2018-01-28 04:29:59', '北京市昌平区龙禧三街', '63', '29', '2018-01-28 04:30:00');
INSERT INTO `hms_physical_record` VALUES ('324', '20', '9', '2018-01-28 04:34:59', '北京市昌平区龙禧三街', '64', '29', '2018-01-28 04:35:00');
INSERT INTO `hms_physical_record` VALUES ('325', '20', '9', '2018-01-28 04:39:59', '北京市昌平区龙禧三街', '65', '29', '2018-01-28 04:40:00');
INSERT INTO `hms_physical_record` VALUES ('326', '20', '9', '2018-01-28 04:44:59', '北京市昌平区龙禧三街', '66', '29', '2018-01-28 04:45:00');
INSERT INTO `hms_physical_record` VALUES ('327', '20', '9', '2018-01-28 04:49:59', '北京市昌平区龙禧三街', '67', '29', '2018-01-28 04:50:00');
INSERT INTO `hms_physical_record` VALUES ('328', '20', '9', '2018-01-28 04:54:59', '北京市昌平区龙禧三街', '68', '29', '2018-01-28 04:55:00');
INSERT INTO `hms_physical_record` VALUES ('329', '20', '9', '2018-01-28 04:59:59', '北京市昌平区龙禧三街', '69', '29', '2018-01-28 05:00:01');
INSERT INTO `hms_physical_record` VALUES ('330', '20', '9', '2018-01-28 05:04:59', '北京市昌平区龙禧三街', '70', '29', '2018-01-28 05:05:01');
INSERT INTO `hms_physical_record` VALUES ('331', '20', '9', '2018-01-28 05:09:59', '北京市昌平区龙禧三街', '71', '29', '2018-01-28 05:10:00');
INSERT INTO `hms_physical_record` VALUES ('332', '20', '9', '2018-01-28 05:14:59', '北京市昌平区龙禧三街', '72', '29', '2018-01-28 05:15:01');
INSERT INTO `hms_physical_record` VALUES ('333', '20', '9', '2018-01-28 05:19:59', '北京市昌平区龙禧三街', '73', '29', '2018-01-28 05:20:01');
INSERT INTO `hms_physical_record` VALUES ('334', '20', '9', '2018-01-28 05:24:59', '北京市昌平区龙禧三街', '74', '29', '2018-01-28 05:25:01');
INSERT INTO `hms_physical_record` VALUES ('335', '20', '9', '2018-01-28 05:29:59', '北京市昌平区龙禧三街', '75', '29', '2018-01-28 05:30:00');
INSERT INTO `hms_physical_record` VALUES ('336', '20', '9', '2018-01-28 05:34:59', '北京市昌平区龙禧三街', '76', '29', '2018-01-28 05:35:01');
INSERT INTO `hms_physical_record` VALUES ('337', '20', '9', '2018-01-28 05:39:59', '北京市昌平区龙禧三街', '77', '29', '2018-01-28 05:40:01');
INSERT INTO `hms_physical_record` VALUES ('338', '20', '9', '2018-01-28 05:44:59', '北京市昌平区龙禧三街', '78', '29', '2018-01-28 05:45:00');
INSERT INTO `hms_physical_record` VALUES ('339', '20', '9', '2018-01-28 05:49:59', '北京市昌平区龙禧三街', '79', '29', '2018-01-28 05:50:00');
INSERT INTO `hms_physical_record` VALUES ('340', '20', '9', '2018-01-28 05:54:59', '北京市昌平区龙禧三街', '80', '29', '2018-01-28 05:55:00');
INSERT INTO `hms_physical_record` VALUES ('341', '20', '9', '2018-01-28 05:59:59', '北京市昌平区龙禧三街', '81', '29', '2018-01-28 06:00:00');
INSERT INTO `hms_physical_record` VALUES ('342', '20', '9', '2018-01-28 06:04:59', '北京市昌平区龙禧三街', '82', '29', '2018-01-28 06:05:00');
INSERT INTO `hms_physical_record` VALUES ('343', '20', '9', '2018-01-28 06:09:59', '北京市昌平区龙禧三街', '83', '29', '2018-01-28 06:10:00');
INSERT INTO `hms_physical_record` VALUES ('344', '20', '9', '2018-01-28 06:14:59', '北京市昌平区龙禧三街', '84', '29', '2018-01-28 06:15:00');
INSERT INTO `hms_physical_record` VALUES ('345', '20', '9', '2018-01-28 06:19:59', '北京市昌平区龙禧三街', '85', '29', '2018-01-28 06:20:02');
INSERT INTO `hms_physical_record` VALUES ('346', '20', '9', '2018-01-28 06:24:59', '北京市昌平区龙禧三街', '86', '29', '2018-01-28 06:25:02');
INSERT INTO `hms_physical_record` VALUES ('347', '20', '9', '2018-01-28 06:29:59', '北京市昌平区龙禧三街', '87', '29', '2018-01-28 06:30:02');
INSERT INTO `hms_physical_record` VALUES ('348', '20', '9', '2018-01-28 06:34:59', '北京市昌平区龙禧三街', '88', '29', '2018-01-28 06:35:00');
INSERT INTO `hms_physical_record` VALUES ('349', '20', '9', '2018-01-28 06:39:59', '北京市昌平区龙禧三街', '89', '29', '2018-01-28 06:40:00');
INSERT INTO `hms_physical_record` VALUES ('350', '20', '9', '2018-01-28 06:44:59', '北京市昌平区龙禧三街', '90', '29', '2018-01-28 06:45:00');
INSERT INTO `hms_physical_record` VALUES ('351', '20', '9', '2018-01-28 06:49:59', '北京市昌平区龙禧三街', '91', '29', '2018-01-28 06:50:00');
INSERT INTO `hms_physical_record` VALUES ('352', '20', '9', '2018-01-28 06:54:59', '北京市昌平区龙禧三街', '92', '29', '2018-01-28 06:55:01');
INSERT INTO `hms_physical_record` VALUES ('353', '20', '9', '2018-01-28 07:00:39', '北京市昌平区龙禧三街', '93', '29', '2018-01-28 07:00:41');
INSERT INTO `hms_physical_record` VALUES ('354', '20', '9', '2018-01-28 07:10:38', '北京市昌平区龙禧三街', '94', '29', '2018-01-28 07:10:41');
INSERT INTO `hms_physical_record` VALUES ('355', '20', '9', '2018-01-28 07:24:59', '北京市昌平区龙禧三街', '95', '29', '2018-01-28 07:25:01');
INSERT INTO `hms_physical_record` VALUES ('356', '20', '9', '2018-01-28 07:40:39', '北京市昌平区龙禧三街', '96', '29', '2018-01-28 07:40:41');
INSERT INTO `hms_physical_record` VALUES ('357', '20', '9', '2018-01-28 07:50:39', '北京市昌平区龙禧三街', '97', '29', '2018-01-28 07:50:41');
INSERT INTO `hms_physical_record` VALUES ('358', '20', '9', '2018-01-28 08:14:59', '北京市昌平区龙禧三街', '98', '29', '2018-01-28 08:15:02');
INSERT INTO `hms_physical_record` VALUES ('359', '20', '9', '2018-01-28 08:19:59', '北京市昌平区龙禧三街', '99', '29', '2018-01-28 08:20:02');
INSERT INTO `hms_physical_record` VALUES ('360', '20', '9', '2018-01-28 08:24:59', '北京市昌平区龙禧三街', '100', '29', '2018-01-28 08:25:02');
INSERT INTO `hms_physical_record` VALUES ('361', '20', '9', '2018-01-28 08:29:59', '北京市昌平区龙禧三街', '101', '29', '2018-01-28 08:30:02');
INSERT INTO `hms_physical_record` VALUES ('362', '20', '9', '2018-01-28 08:34:59', '北京市昌平区龙禧三街', '102', '29', '2018-01-28 08:35:01');
INSERT INTO `hms_physical_record` VALUES ('363', '20', '9', '2018-01-28 08:39:59', '北京市昌平区龙禧三街', '103', '29', '2018-01-28 08:40:02');
INSERT INTO `hms_physical_record` VALUES ('364', '20', '9', '2018-01-28 08:55:00', '北京市昌平区龙禧三街', '104', '29', '2018-01-28 08:55:02');
INSERT INTO `hms_physical_record` VALUES ('365', '20', '9', '2018-01-28 09:00:00', '北京市昌平区龙禧三街', '105', '29', '2018-01-28 09:00:01');
INSERT INTO `hms_physical_record` VALUES ('366', '20', '9', '2018-01-28 09:05:00', '北京市昌平区龙禧三街', '106', '29', '2018-01-28 09:05:02');
INSERT INTO `hms_physical_record` VALUES ('367', '20', '9', '2018-01-28 09:10:00', '北京市昌平区龙禧三街', '107', '29', '2018-01-28 09:10:14');
INSERT INTO `hms_physical_record` VALUES ('368', '20', '9', '2018-01-28 09:15:01', '北京市昌平区龙禧三街', '108', '29', '2018-01-28 09:15:23');
INSERT INTO `hms_physical_record` VALUES ('369', '20', '9', '2018-01-28 09:20:01', '北京市昌平区龙禧三街', '109', '29', '2018-01-28 09:20:04');
INSERT INTO `hms_physical_record` VALUES ('370', '20', '9', '2018-01-28 09:25:00', '北京市昌平区龙禧三街', '110', '29', '2018-01-28 09:25:09');
INSERT INTO `hms_physical_record` VALUES ('371', '20', '9', '2018-01-28 09:30:01', '北京市昌平区龙禧三街', '111', '29', '2018-01-28 09:31:05');
INSERT INTO `hms_physical_record` VALUES ('372', '20', '9', '2018-01-28 09:35:00', '北京市昌平区龙禧三街', '112', '29', '2018-01-28 09:35:30');
INSERT INTO `hms_physical_record` VALUES ('373', '20', '9', '2018-01-28 09:40:01', '北京市昌平区龙禧三街', '113', '29', '2018-01-28 09:40:09');
INSERT INTO `hms_physical_record` VALUES ('374', '20', '9', '2018-01-28 09:45:00', '北京市昌平区龙禧三街', '114', '29', '2018-01-28 09:45:04');
INSERT INTO `hms_physical_record` VALUES ('375', '20', '9', '2018-01-28 09:50:00', '北京市昌平区龙禧三街', '115', '29', '2018-01-28 09:50:03');
INSERT INTO `hms_physical_record` VALUES ('376', '20', '9', '2018-01-28 09:55:00', '北京市昌平区龙禧三街', '116', '29', '2018-01-28 09:55:09');
INSERT INTO `hms_physical_record` VALUES ('377', '20', '9', '2018-01-28 10:00:00', '北京市昌平区龙禧三街', '117', '29', '2018-01-28 10:00:03');
INSERT INTO `hms_physical_record` VALUES ('378', '20', '9', '2018-01-28 10:05:00', '北京市昌平区龙禧三街', '118', '29', '2018-01-28 10:05:09');
INSERT INTO `hms_physical_record` VALUES ('379', '20', '9', '2018-01-28 10:50:01', '北京市昌平区龙禧三街', '119', '29', '2018-01-28 10:50:03');
INSERT INTO `hms_physical_record` VALUES ('380', '20', '9', '2018-01-28 10:55:01', '北京市昌平区龙禧三街', '120', '29', '2018-01-28 10:55:16');
INSERT INTO `hms_physical_record` VALUES ('381', '20', '9', '2018-01-28 11:00:01', '北京市昌平区龙禧三街', '121', '29', '2018-01-28 11:00:04');
INSERT INTO `hms_physical_record` VALUES ('382', '20', '9', '2018-01-28 11:05:01', '北京市昌平区龙禧三街', '122', '29', '2018-01-28 11:05:04');
INSERT INTO `hms_physical_record` VALUES ('383', '20', '9', '2018-01-28 11:10:01', '北京市昌平区龙禧三街', '123', '29', '2018-01-28 11:10:04');
INSERT INTO `hms_physical_record` VALUES ('384', '20', '9', '2018-01-28 11:15:01', '北京市昌平区龙禧三街', '124', '29', '2018-01-28 11:15:05');
INSERT INTO `hms_physical_record` VALUES ('385', '20', '9', '2018-01-28 11:20:01', '北京市昌平区同成街', '125', '29', '2018-01-28 11:20:12');
INSERT INTO `hms_physical_record` VALUES ('386', '20', '9', '2018-01-28 11:25:02', '北京市昌平区龙禧三街', '126', '29', '2018-01-28 11:25:04');
INSERT INTO `hms_physical_record` VALUES ('387', '20', '9', '2018-01-28 11:30:02', '北京市昌平区龙禧三街', '127', '29', '2018-01-28 11:30:04');
INSERT INTO `hms_physical_record` VALUES ('388', '20', '9', '2018-01-28 11:35:01', '北京市昌平区龙禧三街', '128', '29', '2018-01-28 11:35:04');
INSERT INTO `hms_physical_record` VALUES ('389', '20', '9', '2018-01-28 11:40:02', '北京市昌平区龙禧三街', '129', '29', '2018-01-28 11:40:10');
INSERT INTO `hms_physical_record` VALUES ('390', '20', '9', '2018-01-28 11:45:02', '北京市昌平区龙禧三街', '130', '29', '2018-01-28 11:45:04');
INSERT INTO `hms_physical_record` VALUES ('391', '20', '9', '2018-01-28 11:50:02', '北京市昌平区龙禧三街', '131', '29', '2018-01-28 11:50:05');
INSERT INTO `hms_physical_record` VALUES ('392', '20', '9', '2018-01-28 11:55:02', '北京市昌平区龙禧三街', '132', '29', '2018-01-28 11:55:04');
INSERT INTO `hms_physical_record` VALUES ('393', '20', '9', '2018-01-28 12:00:02', '北京市昌平区龙禧三街', '133', '29', '2018-01-28 12:00:05');
INSERT INTO `hms_physical_record` VALUES ('394', '20', '9', '2018-01-28 12:05:02', '北京市昌平区回龙观西大街辅路', '134', '29', '2018-01-28 12:05:05');
INSERT INTO `hms_physical_record` VALUES ('395', '20', '9', '2018-01-28 12:10:02', '北京市昌平区龙禧三街', '135', '29', '2018-01-28 12:10:04');
INSERT INTO `hms_physical_record` VALUES ('396', '20', '9', '2018-01-28 12:15:02', '北京市昌平区龙禧三街', '136', '29', '2018-01-28 12:15:04');
INSERT INTO `hms_physical_record` VALUES ('397', '20', '9', '2018-01-28 12:20:02', '北京市昌平区回龙观西大街95号', '137', '29', '2018-01-28 12:20:04');
INSERT INTO `hms_physical_record` VALUES ('398', '20', '9', '2018-01-28 12:25:42', '北京市昌平区同成街', '138', '29', '2018-01-28 12:25:44');
INSERT INTO `hms_physical_record` VALUES ('399', '20', '9', '2018-01-28 12:30:43', '北京市昌平区同成街', '139', '29', '2018-01-28 12:30:44');
INSERT INTO `hms_physical_record` VALUES ('400', '20', '9', '2018-01-28 12:35:42', '北京市昌平区同成街', '140', '29', '2018-01-28 12:35:45');
INSERT INTO `hms_physical_record` VALUES ('401', '20', '9', '2018-01-28 12:40:42', '北京市昌平区同成街', '141', '29', '2018-01-28 12:40:43');
INSERT INTO `hms_physical_record` VALUES ('402', '20', '9', '2018-01-28 12:45:42', '北京市昌平区同成街', '142', '29', '2018-01-28 12:45:44');
INSERT INTO `hms_physical_record` VALUES ('403', '20', '9', '2018-01-28 12:55:42', '北京市昌平区育知西路', '143', '29', '2018-01-28 13:00:07');
INSERT INTO `hms_physical_record` VALUES ('404', '20', '9', '2018-01-28 12:55:42', '北京市昌平区育知西路', '144', '29', '2018-01-28 13:00:41');
INSERT INTO `hms_physical_record` VALUES ('405', '20', '9', '2018-01-28 13:00:01', '北京市昌平区育知西路', '145', '29', '2018-01-28 13:00:41');
INSERT INTO `hms_physical_record` VALUES ('406', '20', '9', '2018-01-28 13:15:03', '北京市昌平区回龙观西大街95号', '146', '29', '2018-01-28 13:15:05');
INSERT INTO `hms_physical_record` VALUES ('407', '20', '9', '2018-01-28 13:20:02', '北京市昌平区回龙观西大街辅路', '147', '29', '2018-01-28 13:20:31');
INSERT INTO `hms_physical_record` VALUES ('408', '20', '9', '2018-01-28 13:25:02', '北京市昌平区回龙观西大街辅路', '148', '29', '2018-01-28 13:25:31');
INSERT INTO `hms_physical_record` VALUES ('409', '20', '9', '2018-01-28 13:35:02', '北京市昌平区回龙观西大街辅路', '149', '29', '2018-01-28 13:35:40');
INSERT INTO `hms_physical_record` VALUES ('410', '20', '9', '2018-01-28 13:40:03', '北京市昌平区龙禧三街', '150', '29', '2018-01-28 13:40:04');
INSERT INTO `hms_physical_record` VALUES ('411', '20', '9', '2018-01-28 13:45:03', '北京市昌平区回龙观西大街辅路', '151', '29', '2018-01-28 13:45:04');
INSERT INTO `hms_physical_record` VALUES ('412', '20', '9', '2018-01-28 13:50:03', '北京市昌平区龙禧三街', '152', '29', '2018-01-28 13:50:05');
INSERT INTO `hms_physical_record` VALUES ('413', '20', '9', '2018-01-28 13:55:03', '北京市昌平区龙禧三街', '153', '29', '2018-01-28 13:55:05');
INSERT INTO `hms_physical_record` VALUES ('414', '20', '9', '2018-01-28 14:00:03', '北京市昌平区龙禧三街', '154', '29', '2018-01-28 14:00:06');
INSERT INTO `hms_physical_record` VALUES ('415', '20', '9', '2018-01-28 14:05:03', '北京市昌平区龙禧三街', '155', '29', '2018-01-28 14:05:05');
INSERT INTO `hms_physical_record` VALUES ('416', '20', '9', '2018-01-28 14:10:03', '北京市昌平区龙禧三街', '156', '29', '2018-01-28 14:10:06');
INSERT INTO `hms_physical_record` VALUES ('417', '20', '9', '2018-01-28 14:15:04', '北京市昌平区龙禧三街', '157', '29', '2018-01-28 14:15:06');
INSERT INTO `hms_physical_record` VALUES ('418', '20', '9', '2018-01-28 14:20:04', '北京市昌平区回龙观西大街辅路', '158', '29', '2018-01-28 14:20:09');
INSERT INTO `hms_physical_record` VALUES ('419', '20', '9', '2018-01-28 14:25:04', '北京市昌平区回龙观西大街辅路', '159', '29', '2018-01-28 14:25:06');
INSERT INTO `hms_physical_record` VALUES ('420', '20', '9', '2018-01-28 14:35:05', '北京市昌平区龙禧三街', '160', '29', '2018-01-28 14:35:07');
INSERT INTO `hms_physical_record` VALUES ('421', '20', '9', '2018-01-28 14:40:05', '北京市昌平区回龙观西大街辅路', '161', '29', '2018-01-28 14:40:09');
INSERT INTO `hms_physical_record` VALUES ('422', '20', '9', '2018-01-28 14:45:05', '北京市昌平区龙禧三街', '162', '29', '2018-01-28 14:45:07');
INSERT INTO `hms_physical_record` VALUES ('423', '20', '9', '2018-01-28 14:50:05', '北京市昌平区龙禧三街', '163', '29', '2018-01-28 14:50:13');
INSERT INTO `hms_physical_record` VALUES ('424', '20', '9', '2018-01-28 14:55:05', '北京市昌平区龙禧三街', '164', '29', '2018-01-28 14:55:07');
INSERT INTO `hms_physical_record` VALUES ('425', '20', '9', '2018-01-28 15:00:05', '北京市昌平区龙禧三街', '165', '29', '2018-01-28 15:00:07');
INSERT INTO `hms_physical_record` VALUES ('426', '20', '9', '2018-01-28 15:05:05', '北京市昌平区龙禧三街', '166', '29', '2018-01-28 15:05:07');
INSERT INTO `hms_physical_record` VALUES ('427', '20', '9', '2018-01-28 15:10:05', '北京市昌平区龙禧三街', '167', '29', '2018-01-28 15:10:07');
INSERT INTO `hms_physical_record` VALUES ('428', '20', '9', '2018-01-28 15:15:05', '北京市昌平区龙禧三街', '168', '29', '2018-01-28 15:15:08');
INSERT INTO `hms_physical_record` VALUES ('429', '20', '9', '2018-01-28 15:20:05', '北京市昌平区龙禧三街', '169', '29', '2018-01-28 15:20:08');
INSERT INTO `hms_physical_record` VALUES ('430', '20', '9', '2018-01-28 15:25:05', '北京市昌平区龙禧三街', '170', '29', '2018-01-28 15:25:07');
INSERT INTO `hms_physical_record` VALUES ('431', '20', '9', '2018-01-28 15:30:05', '北京市昌平区龙禧三街', '171', '29', '2018-01-28 15:30:08');
INSERT INTO `hms_physical_record` VALUES ('432', '20', '9', '2018-01-28 15:35:05', '北京市昌平区龙禧三街', '172', '29', '2018-01-28 15:35:06');
INSERT INTO `hms_physical_record` VALUES ('433', '20', '9', '2018-01-28 15:40:05', '北京市昌平区龙禧三街', '173', '29', '2018-01-28 15:40:19');
INSERT INTO `hms_physical_record` VALUES ('434', '20', '9', '2018-01-28 15:45:05', '北京市昌平区龙禧三街', '174', '29', '2018-01-28 15:45:19');
INSERT INTO `hms_physical_record` VALUES ('435', '20', '9', '2018-01-28 15:50:05', '北京市昌平区龙禧三街', '175', '29', '2018-01-28 15:50:09');
INSERT INTO `hms_physical_record` VALUES ('436', '20', '9', '2018-01-28 15:55:06', '北京市昌平区龙禧三街', '176', '29', '2018-01-28 15:55:07');
INSERT INTO `hms_physical_record` VALUES ('437', '20', '9', '2018-01-28 16:00:06', '北京市昌平区龙禧三街', '177', '29', '2018-01-28 16:00:07');
INSERT INTO `hms_physical_record` VALUES ('438', '20', '9', '2018-01-28 16:05:06', '北京市昌平区龙禧三街', '178', '29', '2018-01-28 16:05:07');
INSERT INTO `hms_physical_record` VALUES ('439', '20', '9', '2018-01-28 16:10:06', '北京市昌平区龙禧三街', '179', '29', '2018-01-28 16:10:09');
INSERT INTO `hms_physical_record` VALUES ('440', '20', '9', '2018-01-28 16:15:06', '北京市昌平区龙禧三街', '180', '29', '2018-01-28 16:15:14');
INSERT INTO `hms_physical_record` VALUES ('441', '20', '9', '2018-01-28 16:20:06', '北京市昌平区龙禧三街', '181', '29', '2018-01-28 16:20:07');
INSERT INTO `hms_physical_record` VALUES ('442', '20', '9', '2018-01-28 16:25:06', '北京市昌平区龙禧三街', '182', '29', '2018-01-28 16:25:07');
INSERT INTO `hms_physical_record` VALUES ('443', '20', '9', '2018-01-28 16:30:06', '北京市昌平区龙禧三街', '183', '29', '2018-01-28 16:30:20');
INSERT INTO `hms_physical_record` VALUES ('444', '20', '9', '2018-01-28 16:35:06', '北京市昌平区龙禧三街', '184', '29', '2018-01-28 16:35:08');
INSERT INTO `hms_physical_record` VALUES ('445', '20', '9', '2018-01-28 16:40:06', '北京市昌平区龙禧三街', '185', '29', '2018-01-28 16:40:08');
INSERT INTO `hms_physical_record` VALUES ('446', '20', '9', '2018-01-28 16:45:06', '北京市昌平区龙禧三街', '186', '29', '2018-01-28 16:45:09');
INSERT INTO `hms_physical_record` VALUES ('447', '20', '9', '2018-01-28 16:50:06', '北京市昌平区龙禧三街', '187', '29', '2018-01-28 16:50:08');
INSERT INTO `hms_physical_record` VALUES ('448', '20', '9', '2018-01-28 16:55:07', '北京市昌平区龙禧三街', '188', '29', '2018-01-28 16:55:08');
INSERT INTO `hms_physical_record` VALUES ('449', '20', '9', '2018-01-28 17:00:07', '北京市昌平区龙禧三街', '189', '29', '2018-01-28 17:00:09');
INSERT INTO `hms_physical_record` VALUES ('450', '20', '9', '2018-01-28 17:05:07', '北京市昌平区龙禧三街', '190', '29', '2018-01-28 17:05:09');
INSERT INTO `hms_physical_record` VALUES ('451', '20', '9', '2018-01-28 17:10:07', '北京市昌平区龙禧三街', '191', '29', '2018-01-28 17:10:08');
INSERT INTO `hms_physical_record` VALUES ('452', '20', '9', '2018-01-28 17:15:07', '北京市昌平区龙禧三街', '192', '29', '2018-01-28 17:15:10');
INSERT INTO `hms_physical_record` VALUES ('453', '20', '9', '2018-01-28 17:20:08', '北京市昌平区回龙观西大街95号', '193', '29', '2018-01-28 17:20:10');
INSERT INTO `hms_physical_record` VALUES ('454', '20', '9', '2018-01-28 17:25:07', '北京市昌平区龙禧三街', '194', '29', '2018-01-28 17:25:09');
INSERT INTO `hms_physical_record` VALUES ('455', '20', '9', '2018-01-28 17:30:08', '北京市昌平区龙禧三街', '195', '29', '2018-01-28 17:30:09');
INSERT INTO `hms_physical_record` VALUES ('456', '20', '9', '2018-01-28 17:35:08', '北京市昌平区龙禧三街', '196', '29', '2018-01-28 17:35:10');
INSERT INTO `hms_physical_record` VALUES ('457', '20', '9', '2018-01-28 17:40:08', '北京市昌平区龙禧三街', '197', '29', '2018-01-28 17:40:10');
INSERT INTO `hms_physical_record` VALUES ('458', '20', '9', '2018-01-28 17:45:08', '北京市昌平区龙禧三街', '198', '29', '2018-01-28 17:45:10');
INSERT INTO `hms_physical_record` VALUES ('459', '20', '9', '2018-01-28 17:50:08', '北京市昌平区龙禧三街', '199', '29', '2018-01-28 17:50:17');
INSERT INTO `hms_physical_record` VALUES ('460', '20', '9', '2018-01-28 17:55:08', '北京市昌平区回龙观西大街辅路', '200', '29', '2018-01-28 17:55:11');
INSERT INTO `hms_physical_record` VALUES ('461', '20', '9', '2018-01-28 18:00:08', '北京市昌平区龙禧三街', '201', '29', '2018-01-28 18:00:10');
INSERT INTO `hms_physical_record` VALUES ('462', '20', '9', '2018-01-28 18:05:08', '北京市昌平区龙禧三街', '202', '29', '2018-01-28 18:05:10');
INSERT INTO `hms_physical_record` VALUES ('463', '20', '9', '2018-01-28 18:10:08', '北京市昌平区龙禧三街', '203', '29', '2018-01-28 18:10:11');
INSERT INTO `hms_physical_record` VALUES ('464', '20', '9', '2018-01-28 18:20:09', '北京市昌平区回龙观西大街辅路', '204', '29', '2018-01-28 18:22:13');
INSERT INTO `hms_physical_record` VALUES ('465', '20', '9', '2018-01-28 18:25:09', '北京市昌平区回龙观西大街辅路', '205', '29', '2018-01-28 18:25:10');
INSERT INTO `hms_physical_record` VALUES ('466', '20', '9', '2018-01-28 18:30:09', '北京市昌平区龙禧三街', '206', '29', '2018-01-28 18:30:12');
INSERT INTO `hms_physical_record` VALUES ('467', '20', '9', '2018-01-29 00:22:52', '北京市昌平区龙禧三街', '207', '29', '2018-01-29 00:22:53');
INSERT INTO `hms_physical_record` VALUES ('468', '20', '9', '2018-01-29 00:25:58', '北京市昌平区龙禧三街', '208', '29', '2018-01-29 00:26:00');
INSERT INTO `hms_physical_record` VALUES ('469', '20', '9', '2018-01-29 00:30:58', '北京市昌平区龙禧三街', '209', '29', '2018-01-29 00:31:00');
INSERT INTO `hms_physical_record` VALUES ('470', '20', '9', '2018-01-29 00:35:58', '北京市昌平区龙禧三街', '210', '29', '2018-01-29 00:36:00');
INSERT INTO `hms_physical_record` VALUES ('471', '20', '9', '2018-01-29 00:40:58', '北京市昌平区龙禧三街', '211', '29', '2018-01-29 00:41:00');
INSERT INTO `hms_physical_record` VALUES ('472', '20', '9', '2018-01-29 00:45:58', '北京市昌平区龙禧三街', '212', '29', '2018-01-29 00:46:00');
INSERT INTO `hms_physical_record` VALUES ('473', '20', '9', '2018-01-29 00:50:58', '北京市昌平区龙禧三街', '213', '29', '2018-01-29 00:51:00');
INSERT INTO `hms_physical_record` VALUES ('474', '20', '9', '2018-01-29 00:55:58', '北京市昌平区龙禧三街', '214', '29', '2018-01-29 00:56:02');
INSERT INTO `hms_physical_record` VALUES ('475', '20', '9', '2018-01-29 01:00:58', '北京市昌平区龙禧三街', '215', '29', '2018-01-29 01:01:00');
INSERT INTO `hms_physical_record` VALUES ('476', '20', '9', '2018-01-29 01:05:58', '北京市昌平区龙禧三街', '216', '29', '2018-01-29 01:06:00');
INSERT INTO `hms_physical_record` VALUES ('477', '20', '9', '2018-01-29 01:10:58', '北京市昌平区龙禧三街', '217', '29', '2018-01-29 01:11:00');
INSERT INTO `hms_physical_record` VALUES ('478', '20', '9', '2018-01-29 01:15:58', '北京市昌平区龙禧三街', '218', '29', '2018-01-29 01:16:00');
INSERT INTO `hms_physical_record` VALUES ('479', '20', '9', '2018-01-29 01:20:58', '北京市昌平区龙禧三街', '219', '29', '2018-01-29 01:21:00');
INSERT INTO `hms_physical_record` VALUES ('480', '20', '9', '2018-01-29 01:25:59', '北京市昌平区龙禧三街', '220', '29', '2018-01-29 01:26:01');
INSERT INTO `hms_physical_record` VALUES ('481', '20', '9', '2018-01-29 01:30:59', '北京市昌平区龙禧三街', '221', '29', '2018-01-29 01:31:02');
INSERT INTO `hms_physical_record` VALUES ('482', '20', '9', '2018-01-29 01:35:59', '北京市昌平区龙禧三街', '222', '29', '2018-01-29 01:36:01');
INSERT INTO `hms_physical_record` VALUES ('483', '20', '9', '2018-01-29 01:40:59', '北京市昌平区龙禧三街', '223', '29', '2018-01-29 01:41:01');
INSERT INTO `hms_physical_record` VALUES ('484', '20', '9', '2018-01-29 01:46:39', '北京市昌平区龙禧三街', '224', '29', '2018-01-29 01:46:42');
INSERT INTO `hms_physical_record` VALUES ('485', '20', '9', '2018-01-29 01:50:59', '北京市昌平区龙禧三街', '225', '29', '2018-01-29 01:51:01');
INSERT INTO `hms_physical_record` VALUES ('486', '20', '9', '2018-01-29 01:55:59', '北京市昌平区龙禧三街', '226', '29', '2018-01-29 01:56:01');
INSERT INTO `hms_physical_record` VALUES ('487', '20', '9', '2018-01-29 02:00:59', '北京市昌平区龙禧三街', '227', '29', '2018-01-29 02:01:01');
INSERT INTO `hms_physical_record` VALUES ('488', '20', '9', '2018-01-29 02:05:59', '北京市昌平区龙禧三街', '228', '29', '2018-01-29 02:06:02');
INSERT INTO `hms_physical_record` VALUES ('489', '20', '9', '2018-01-29 02:10:59', '北京市昌平区龙禧三街', '229', '29', '2018-01-29 02:11:02');
INSERT INTO `hms_physical_record` VALUES ('490', '20', '9', '2018-01-29 02:15:59', '北京市昌平区龙禧三街', '230', '29', '2018-01-29 02:16:01');
INSERT INTO `hms_physical_record` VALUES ('491', '20', '9', '2018-01-29 02:35:59', '北京市昌平区龙禧三街', '231', '29', '2018-01-29 02:36:01');
INSERT INTO `hms_physical_record` VALUES ('492', '20', '9', '2018-01-29 02:40:59', '北京市昌平区龙禧三街', '232', '29', '2018-01-29 02:41:01');
INSERT INTO `hms_physical_record` VALUES ('493', '20', '9', '2018-01-29 02:45:59', '北京市昌平区龙禧三街', '233', '29', '2018-01-29 02:46:01');
INSERT INTO `hms_physical_record` VALUES ('494', '20', '9', '2018-01-29 02:50:59', '北京市昌平区龙禧三街', '234', '29', '2018-01-29 02:51:01');
INSERT INTO `hms_physical_record` VALUES ('495', '20', '9', '2018-01-29 02:55:59', '北京市昌平区龙禧三街', '235', '29', '2018-01-29 02:56:01');
INSERT INTO `hms_physical_record` VALUES ('496', '20', '9', '2018-01-29 03:31:00', '北京市昌平区龙禧三街', '236', '29', '2018-01-29 03:31:02');
INSERT INTO `hms_physical_record` VALUES ('497', '20', '9', '2018-01-29 03:36:01', '北京市昌平区龙禧三街', '237', '29', '2018-01-29 03:36:03');
INSERT INTO `hms_physical_record` VALUES ('498', '20', '9', '2018-01-29 04:01:00', '北京市昌平区龙禧三街', '238', '29', '2018-01-29 04:01:02');
INSERT INTO `hms_physical_record` VALUES ('499', '20', '9', '2018-01-29 04:31:01', '北京市昌平区龙禧三街', '239', '29', '2018-01-29 04:31:02');
INSERT INTO `hms_physical_record` VALUES ('500', '20', '9', '2018-01-29 04:41:01', '北京市昌平区龙禧三街', '240', '29', '2018-01-29 04:41:03');
INSERT INTO `hms_physical_record` VALUES ('501', '20', '9', '2018-01-29 05:11:01', '北京市昌平区龙禧三街', '241', '29', '2018-01-29 05:11:03');
INSERT INTO `hms_physical_record` VALUES ('502', '20', '9', '2018-01-29 05:16:01', '北京市昌平区龙禧三街', '242', '29', '2018-01-29 05:16:03');
INSERT INTO `hms_physical_record` VALUES ('503', '20', '9', '2018-01-29 05:21:01', '北京市昌平区龙禧三街', '243', '29', '2018-01-29 05:21:03');
INSERT INTO `hms_physical_record` VALUES ('504', '20', '9', '2018-01-29 05:31:02', '北京市昌平区龙禧三街', '244', '29', '2018-01-29 05:31:03');
INSERT INTO `hms_physical_record` VALUES ('505', '20', '9', '2018-01-29 05:36:02', '北京市昌平区龙禧三街', '245', '29', '2018-01-29 05:36:03');
INSERT INTO `hms_physical_record` VALUES ('506', '20', '9', '2018-01-29 05:41:02', '北京市昌平区龙禧三街', '246', '29', '2018-01-29 05:41:03');
INSERT INTO `hms_physical_record` VALUES ('507', '20', '9', '2018-01-29 05:46:02', '北京市昌平区龙禧三街', '247', '29', '2018-01-29 05:46:03');
INSERT INTO `hms_physical_record` VALUES ('508', '20', '9', '2018-01-29 05:51:02', '北京市昌平区龙禧三街', '248', '29', '2018-01-29 05:51:04');
INSERT INTO `hms_physical_record` VALUES ('509', '20', '9', '2018-01-29 05:56:02', '北京市昌平区龙禧三街', '249', '29', '2018-01-29 05:56:04');
INSERT INTO `hms_physical_record` VALUES ('510', '20', '9', '2018-01-29 06:01:02', '北京市昌平区龙禧三街', '250', '29', '2018-01-29 06:01:03');
INSERT INTO `hms_physical_record` VALUES ('511', '20', '9', '2018-01-29 06:06:02', '北京市昌平区龙禧三街', '251', '29', '2018-01-29 06:06:03');
INSERT INTO `hms_physical_record` VALUES ('512', '20', '9', '2018-01-29 06:11:02', '北京市昌平区龙禧三街', '252', '29', '2018-01-29 06:11:03');
INSERT INTO `hms_physical_record` VALUES ('513', '20', '9', '2018-01-29 06:16:02', '北京市昌平区龙禧三街', '253', '29', '2018-01-29 06:16:03');
INSERT INTO `hms_physical_record` VALUES ('514', '20', '9', '2018-01-29 06:21:02', '北京市昌平区龙禧三街', '254', '29', '2018-01-29 06:21:04');
INSERT INTO `hms_physical_record` VALUES ('515', '20', '9', '2018-01-29 06:26:02', '北京市昌平区龙禧三街', '255', '29', '2018-01-29 06:26:03');
INSERT INTO `hms_physical_record` VALUES ('516', '20', '9', '2018-01-29 06:31:02', '北京市昌平区龙禧三街', '256', '29', '2018-01-29 06:31:04');
INSERT INTO `hms_physical_record` VALUES ('517', '20', '9', '2018-01-29 06:36:02', '北京市昌平区龙禧三街', '257', '29', '2018-01-29 06:36:04');
INSERT INTO `hms_physical_record` VALUES ('518', '20', '9', '2018-01-29 06:41:02', '北京市昌平区龙禧三街', '258', '29', '2018-01-29 06:41:05');
INSERT INTO `hms_physical_record` VALUES ('519', '20', '9', '2018-01-29 06:46:02', '北京市昌平区龙禧三街', '259', '29', '2018-01-29 06:46:08');
INSERT INTO `hms_physical_record` VALUES ('520', '20', '9', '2018-01-29 06:51:02', '北京市昌平区龙禧三街', '260', '29', '2018-01-29 06:51:21');
INSERT INTO `hms_physical_record` VALUES ('521', '20', '9', '2018-01-29 06:56:02', '北京市昌平区龙禧三街', '261', '29', '2018-01-29 06:56:26');
INSERT INTO `hms_physical_record` VALUES ('522', '20', '9', '2018-01-29 07:01:02', '北京市昌平区龙禧三街', '262', '29', '2018-01-29 07:02:04');
INSERT INTO `hms_physical_record` VALUES ('523', '20', '9', '2018-01-29 07:06:02', '北京市昌平区龙禧三街', '263', '29', '2018-01-29 07:06:04');
INSERT INTO `hms_physical_record` VALUES ('524', '20', '9', '2018-01-29 07:11:02', '北京市昌平区龙禧三街', '264', '29', '2018-01-29 07:11:03');
INSERT INTO `hms_physical_record` VALUES ('525', '20', '9', '2018-01-29 07:16:02', '北京市昌平区龙禧三街', '265', '29', '2018-01-29 07:16:11');
INSERT INTO `hms_physical_record` VALUES ('526', '20', '9', '2018-01-29 07:21:02', '北京市昌平区龙禧三街', '266', '29', '2018-01-29 07:21:05');
INSERT INTO `hms_physical_record` VALUES ('527', '20', '9', '2018-01-29 07:26:02', '北京市昌平区龙禧三街', '267', '29', '2018-01-29 07:26:04');
INSERT INTO `hms_physical_record` VALUES ('528', '20', '9', '2018-01-29 07:31:02', '北京市昌平区龙禧三街', '268', '29', '2018-01-29 07:31:04');
INSERT INTO `hms_physical_record` VALUES ('529', '20', '9', '2018-01-29 07:36:02', '北京市昌平区龙禧三街', '269', '29', '2018-01-29 07:36:04');
INSERT INTO `hms_physical_record` VALUES ('530', '20', '9', '2018-01-29 07:41:03', '北京市昌平区龙禧三街', '270', '29', '2018-01-29 07:41:04');
INSERT INTO `hms_physical_record` VALUES ('531', '20', '9', '2018-01-29 07:46:03', '北京市昌平区龙禧三街', '271', '29', '2018-01-29 07:46:04');
INSERT INTO `hms_physical_record` VALUES ('532', '20', '9', '2018-01-29 07:51:03', '北京市昌平区龙禧三街', '272', '29', '2018-01-29 07:51:04');
INSERT INTO `hms_physical_record` VALUES ('533', '20', '9', '2018-01-29 07:56:03', '北京市昌平区龙禧三街', '273', '29', '2018-01-29 07:56:04');
INSERT INTO `hms_physical_record` VALUES ('534', '20', '9', '2018-01-29 08:01:03', '北京市昌平区龙禧三街', '274', '29', '2018-01-29 08:01:05');
INSERT INTO `hms_physical_record` VALUES ('535', '20', '9', '2018-01-29 08:06:03', '北京市昌平区龙禧三街', '275', '29', '2018-01-29 08:06:05');
INSERT INTO `hms_physical_record` VALUES ('536', '20', '9', '2018-01-29 08:11:43', '北京市昌平区龙禧三街', '276', '29', '2018-01-29 08:11:45');
INSERT INTO `hms_physical_record` VALUES ('537', '20', '9', '2018-01-29 08:16:04', '北京市昌平区龙禧三街', '277', '29', '2018-01-29 08:16:05');
INSERT INTO `hms_physical_record` VALUES ('538', '20', '9', '2018-01-29 08:21:43', '北京市昌平区龙禧三街', '278', '29', '2018-01-29 08:21:48');
INSERT INTO `hms_physical_record` VALUES ('539', '20', '9', '2018-01-29 08:26:03', '北京市昌平区龙禧三街', '279', '29', '2018-01-29 08:26:12');
INSERT INTO `hms_physical_record` VALUES ('540', '20', '9', '2018-01-29 08:31:03', '北京市昌平区回龙观西大街95号', '280', '29', '2018-01-29 08:31:05');
INSERT INTO `hms_physical_record` VALUES ('541', '20', '9', '2018-01-29 08:36:04', '北京市昌平区同成街', '281', '29', '2018-01-29 08:36:06');
INSERT INTO `hms_physical_record` VALUES ('542', '20', '9', '2018-01-29 08:41:04', '北京市昌平区育知东路辅路', '282', '29', '2018-01-29 08:41:05');
INSERT INTO `hms_physical_record` VALUES ('543', '20', '9', '2018-01-29 08:46:04', '北京市昌平区文华东路27', '283', '29', '2018-01-29 08:46:07');
INSERT INTO `hms_physical_record` VALUES ('544', '20', '9', '2018-01-29 08:51:04', '北京市昌平区黄平路5号', '284', '29', '2018-01-29 08:51:09');
INSERT INTO `hms_physical_record` VALUES ('545', '20', '9', '2018-01-29 08:56:04', '北京市昌平区文华路', '285', '29', '2018-01-29 08:56:05');
INSERT INTO `hms_physical_record` VALUES ('546', '20', '9', '2018-01-29 09:01:04', '北京市昌平区文华路', '286', '29', '2018-01-29 09:01:05');
INSERT INTO `hms_physical_record` VALUES ('547', '20', '9', '2018-01-29 09:06:04', '北京市昌平区文华路', '287', '29', '2018-01-29 09:06:05');
INSERT INTO `hms_physical_record` VALUES ('548', '20', '9', '2018-01-29 09:11:04', '北京市昌平区文华路', '288', '29', '2018-01-29 09:11:06');
INSERT INTO `hms_physical_record` VALUES ('549', '20', '9', '2018-01-29 09:16:04', '北京市昌平区文华路', '289', '29', '2018-01-29 09:16:05');
INSERT INTO `hms_physical_record` VALUES ('550', '20', '9', '2018-01-29 09:21:04', '北京市昌平区文华路', '290', '29', '2018-01-29 09:21:05');
INSERT INTO `hms_physical_record` VALUES ('551', '20', '9', '2018-01-29 09:26:04', '北京市昌平区文华路', '291', '29', '2018-01-29 09:26:07');
INSERT INTO `hms_physical_record` VALUES ('552', '20', '9', '2018-01-29 09:31:04', '北京市昌平区文华路', '292', '29', '2018-01-29 09:31:07');
INSERT INTO `hms_physical_record` VALUES ('553', '20', '1', '2018-01-29 10:35:06', '偏胖', '183', '29', '2018-01-29 10:35:08');
INSERT INTO `hms_physical_record` VALUES ('554', '20', '4', '2018-01-29 10:36:58', '正常指标', '38', '29', '2018-01-29 10:37:00');
INSERT INTO `hms_physical_record` VALUES ('555', '20', '4', '2018-01-29 10:37:13', '正常指标', '39', '29', '2018-01-29 10:37:15');
INSERT INTO `hms_physical_record` VALUES ('556', '20', '1', '2018-01-29 10:37:33', '偏瘦', '184', '29', '2018-01-29 10:37:36');
INSERT INTO `hms_physical_record` VALUES ('557', '20', '1', '2018-01-29 10:38:41', '偏瘦', '185', '29', '2018-01-29 10:38:43');
INSERT INTO `hms_physical_record` VALUES ('558', '20', '4', '2018-01-29 10:40:10', '正常指标', '40', '29', '2018-01-29 10:40:12');
INSERT INTO `hms_physical_record` VALUES ('559', '20', '1', '2018-01-29 10:41:44', '偏瘦', '186', '29', '2018-01-29 10:41:47');
INSERT INTO `hms_physical_record` VALUES ('560', '20', '4', '2018-01-29 10:47:31', '正常指标', '41', '29', '2018-01-29 10:47:33');
INSERT INTO `hms_physical_record` VALUES ('561', '20', '2', '2018-01-29 10:48:53', '正常', '23', '29', '2018-01-29 10:48:55');
INSERT INTO `hms_physical_record` VALUES ('562', '20', '5', '2018-01-29 10:48:53', '心动过速', '17', '29', '2018-01-29 10:48:55');
INSERT INTO `hms_physical_record` VALUES ('563', '6', '9', '2018-01-29 10:51:04', '北京市昌平区育知东路辅路', '293', '13', '2018-01-29 10:51:06');
INSERT INTO `hms_physical_record` VALUES ('564', '6', '9', '2018-01-29 10:56:04', '北京市昌平区同成街', '294', '13', '2018-01-29 10:56:07');
INSERT INTO `hms_physical_record` VALUES ('565', '20', '2', '2018-01-29 10:58:13', '正常', '24', '29', '2018-01-29 10:58:14');
INSERT INTO `hms_physical_record` VALUES ('566', '20', '5', '2018-01-29 10:58:13', '正常区间', '18', '29', '2018-01-29 10:58:14');
INSERT INTO `hms_physical_record` VALUES ('567', '6', '9', '2018-01-29 11:01:04', '北京市昌平区同成街', '295', '13', '2018-01-29 11:01:05');
INSERT INTO `hms_physical_record` VALUES ('568', '20', '2', '2018-01-29 11:01:26', '数值异常', '25', '29', '2018-01-29 11:01:28');
INSERT INTO `hms_physical_record` VALUES ('569', '20', '5', '2018-01-29 11:01:26', '正常区间', '19', '29', '2018-01-29 11:01:28');
INSERT INTO `hms_physical_record` VALUES ('570', '20', '4', '2018-01-29 11:01:42', '正常指标', '42', '29', '2018-01-29 11:01:44');
INSERT INTO `hms_physical_record` VALUES ('571', '20', '2', '2018-01-29 11:02:44', '正常', '26', '29', '2018-01-29 11:02:45');
INSERT INTO `hms_physical_record` VALUES ('572', '20', '5', '2018-01-29 11:02:44', '正常区间', '20', '29', '2018-01-29 11:02:45');
INSERT INTO `hms_physical_record` VALUES ('573', '20', '2', '2018-01-29 11:03:47', '正常', '27', '29', '2018-01-29 11:03:49');
INSERT INTO `hms_physical_record` VALUES ('574', '20', '5', '2018-01-29 11:03:47', '正常区间', '21', '29', '2018-01-29 11:03:49');
INSERT INTO `hms_physical_record` VALUES ('575', '20', '4', '2018-01-29 11:04:51', '正常指标', '43', '29', '2018-01-29 11:04:53');
INSERT INTO `hms_physical_record` VALUES ('576', '20', '1', '2018-01-29 11:05:17', '偏瘦', '187', '29', '2018-01-29 11:05:19');
INSERT INTO `hms_physical_record` VALUES ('577', '6', '9', '2018-01-29 11:06:04', '北京市昌平区文华路', '296', '13', '2018-01-29 11:06:05');
INSERT INTO `hms_physical_record` VALUES ('578', '20', '2', '2018-01-29 11:06:12', '正常', '28', '29', '2018-01-29 11:06:15');
INSERT INTO `hms_physical_record` VALUES ('579', '20', '5', '2018-01-29 11:06:12', '正常区间', '22', '29', '2018-01-29 11:06:15');
INSERT INTO `hms_physical_record` VALUES ('580', '20', '3', '2018-01-29 11:11:03', '血糖偏低', '8', '29', '2018-01-29 11:11:04');
INSERT INTO `hms_physical_record` VALUES ('581', '6', '9', '2018-01-29 11:11:04', '北京市昌平区文华路', '297', '13', '2018-01-29 11:11:06');
INSERT INTO `hms_physical_record` VALUES ('582', '20', '4', '2018-01-29 11:15:25', '正常指标', '44', '29', '2018-01-29 11:15:27');
INSERT INTO `hms_physical_record` VALUES ('583', '20', '4', '2018-01-29 11:15:48', '正常指标', '45', '29', '2018-01-29 11:15:49');
INSERT INTO `hms_physical_record` VALUES ('584', '6', '9', '2018-01-29 11:16:04', '北京市昌平区文华路', '298', '13', '2018-01-29 11:16:06');
INSERT INTO `hms_physical_record` VALUES ('585', '6', '9', '2018-01-29 11:21:04', '北京市昌平区文华路', '299', '13', '2018-01-29 11:21:06');
INSERT INTO `hms_physical_record` VALUES ('586', '6', '9', '2018-01-29 11:26:04', '北京市昌平区文华路', '300', '13', '2018-01-29 11:26:06');
INSERT INTO `hms_physical_record` VALUES ('587', '20', '3', '2018-01-29 11:29:39', '血糖偏高', '9', '29', '2018-01-29 11:29:42');
INSERT INTO `hms_physical_record` VALUES ('588', '6', '9', '2018-01-29 11:31:04', '北京市昌平区文华路', '301', '13', '2018-01-29 11:31:06');
INSERT INTO `hms_physical_record` VALUES ('589', '25', '3', '2018-02-01 01:35:05', '血糖偏高', '10', '29', '2018-02-01 01:35:05');
INSERT INTO `hms_physical_record` VALUES ('590', '25', '3', '2018-02-01 11:35:05', '血糖偏低', '11', '29', '2018-02-01 11:35:05');
INSERT INTO `hms_physical_record` VALUES ('591', '6', '9', '2018-01-29 11:36:05', '北京市昌平区文华路', '302', '13', '2018-01-29 11:36:06');
INSERT INTO `hms_physical_record` VALUES ('592', '6', '9', '2018-01-29 11:41:05', '北京市昌平区文华路', '303', '13', '2018-01-29 11:41:07');
INSERT INTO `hms_physical_record` VALUES ('593', '6', '9', '2018-01-29 11:46:05', '北京市昌平区文华路', '304', '13', '2018-01-29 11:46:07');
INSERT INTO `hms_physical_record` VALUES ('594', '6', '9', '2018-01-29 11:51:05', '北京市昌平区文华路', '305', '13', '2018-01-29 11:51:06');
INSERT INTO `hms_physical_record` VALUES ('595', '6', '9', '2018-01-29 11:56:05', '北京市昌平区文华路', '306', '13', '2018-01-29 11:56:06');
INSERT INTO `hms_physical_record` VALUES ('596', '6', '9', '2018-01-29 12:01:05', '北京市昌平区文华路', '307', '13', '2018-01-29 12:01:06');
INSERT INTO `hms_physical_record` VALUES ('597', '6', '9', '2018-01-29 12:06:05', '北京市昌平区文华路', '308', '13', '2018-01-29 12:06:06');
INSERT INTO `hms_physical_record` VALUES ('598', '6', '9', '2018-01-29 12:11:05', '北京市昌平区文华路', '309', '13', '2018-01-29 12:11:06');
INSERT INTO `hms_physical_record` VALUES ('599', '6', '9', '2018-01-29 12:16:05', '北京市昌平区文华路', '310', '13', '2018-01-29 12:16:06');
INSERT INTO `hms_physical_record` VALUES ('600', '6', '9', '2018-01-29 12:21:05', '北京市昌平区文华路', '311', '13', '2018-01-29 12:21:06');
INSERT INTO `hms_physical_record` VALUES ('601', '6', '9', '2018-01-29 12:26:05', '北京市昌平区文华路', '312', '13', '2018-01-29 12:26:06');
INSERT INTO `hms_physical_record` VALUES ('602', '6', '9', '2018-01-29 12:31:05', '北京市昌平区文华路', '313', '13', '2018-01-29 12:31:07');
INSERT INTO `hms_physical_record` VALUES ('603', '6', '9', '2018-01-29 12:36:05', '北京市昌平区文华路', '314', '13', '2018-01-29 12:36:06');
INSERT INTO `hms_physical_record` VALUES ('604', '6', '9', '2018-01-29 12:41:05', '北京市昌平区文华路', '315', '13', '2018-01-29 12:41:07');
INSERT INTO `hms_physical_record` VALUES ('605', '6', '9', '2018-01-29 12:46:05', '北京市昌平区文华路', '316', '13', '2018-01-29 12:46:07');
INSERT INTO `hms_physical_record` VALUES ('606', '6', '9', '2018-01-29 12:51:05', '北京市昌平区文华路', '317', '13', '2018-01-29 12:51:06');
INSERT INTO `hms_physical_record` VALUES ('607', '6', '9', '2018-01-29 12:56:05', '北京市昌平区文华路', '318', '13', '2018-01-29 12:56:06');
INSERT INTO `hms_physical_record` VALUES ('608', '6', '9', '2018-01-29 13:01:05', '北京市昌平区文华路', '319', '13', '2018-01-29 13:01:06');
INSERT INTO `hms_physical_record` VALUES ('609', '6', '9', '2018-01-29 13:06:05', '北京市昌平区文华路', '320', '13', '2018-01-29 13:06:06');
INSERT INTO `hms_physical_record` VALUES ('610', '6', '9', '2018-01-29 13:11:05', '北京市昌平区文华路', '321', '13', '2018-01-29 13:11:07');
INSERT INTO `hms_physical_record` VALUES ('611', '6', '9', '2018-01-29 13:16:05', '北京市昌平区文华路', '322', '13', '2018-01-29 13:16:06');
INSERT INTO `hms_physical_record` VALUES ('612', '6', '9', '2018-01-29 13:21:05', '北京市昌平区文华路', '323', '13', '2018-01-29 13:21:06');
INSERT INTO `hms_physical_record` VALUES ('613', '6', '9', '2018-01-29 13:26:05', '北京市昌平区文华路', '324', '13', '2018-01-29 13:26:07');
INSERT INTO `hms_physical_record` VALUES ('614', '20', '1', '2018-01-29 13:30:25', '偏胖', '188', '29', '2018-01-29 13:30:27');
INSERT INTO `hms_physical_record` VALUES ('615', '6', '9', '2018-01-29 13:31:05', '北京市昌平区文华路', '325', '13', '2018-01-29 13:31:06');
INSERT INTO `hms_physical_record` VALUES ('616', '6', '9', '2018-01-29 13:36:05', '北京市昌平区文华路', '326', '13', '2018-01-29 13:36:07');
INSERT INTO `hms_physical_record` VALUES ('617', '6', '9', '2018-01-29 13:41:05', '北京市昌平区文华路', '327', '13', '2018-01-29 13:41:06');
INSERT INTO `hms_physical_record` VALUES ('618', '6', '9', '2018-01-29 13:46:05', '北京市昌平区文华路', '328', '13', '2018-01-29 13:46:06');
INSERT INTO `hms_physical_record` VALUES ('619', '6', '9', '2018-01-29 13:51:05', '北京市昌平区文华路', '329', '13', '2018-01-29 13:51:06');
INSERT INTO `hms_physical_record` VALUES ('620', '6', '9', '2018-01-29 13:56:05', '北京市昌平区文华路', '330', '13', '2018-01-29 13:56:06');
INSERT INTO `hms_physical_record` VALUES ('621', '6', '9', '2018-01-29 14:01:05', '北京市昌平区文华路', '331', '13', '2018-01-29 14:01:06');
INSERT INTO `hms_physical_record` VALUES ('622', '6', '9', '2018-01-29 14:06:05', '北京市昌平区文华路', '332', '13', '2018-01-29 14:06:07');
INSERT INTO `hms_physical_record` VALUES ('623', '6', '9', '2018-01-29 14:11:05', '北京市昌平区文华路', '333', '13', '2018-01-29 14:11:06');
INSERT INTO `hms_physical_record` VALUES ('624', '6', '9', '2018-01-29 14:16:05', '北京市昌平区文华路', '334', '13', '2018-01-29 14:16:07');
INSERT INTO `hms_physical_record` VALUES ('625', '6', '9', '2018-01-29 14:21:05', '北京市昌平区文华路', '335', '13', '2018-01-29 14:21:07');
INSERT INTO `hms_physical_record` VALUES ('626', '6', '9', '2018-01-29 14:26:05', '北京市昌平区文华路', '336', '13', '2018-01-29 14:26:07');
INSERT INTO `hms_physical_record` VALUES ('627', '6', '9', '2018-01-29 14:31:06', '北京市昌平区文华路', '337', '13', '2018-01-29 14:31:08');
INSERT INTO `hms_physical_record` VALUES ('628', '6', '9', '2018-01-29 14:36:05', '北京市昌平区文华路', '338', '13', '2018-01-29 14:36:07');
INSERT INTO `hms_physical_record` VALUES ('629', '6', '9', '2018-01-29 14:41:05', '北京市昌平区文华路', '339', '13', '2018-01-29 14:41:08');
INSERT INTO `hms_physical_record` VALUES ('630', '6', '9', '2018-01-29 14:46:06', '北京市昌平区文华路', '340', '13', '2018-01-29 14:46:08');
INSERT INTO `hms_physical_record` VALUES ('631', '20', '2', '2018-01-29 14:47:56', '正常', '29', '29', '2018-01-29 14:47:58');
INSERT INTO `hms_physical_record` VALUES ('632', '20', '5', '2018-01-29 14:47:56', '正常区间', '23', '29', '2018-01-29 14:47:58');
INSERT INTO `hms_physical_record` VALUES ('633', '6', '9', '2018-01-29 14:51:06', '北京市昌平区文华路', '341', '13', '2018-01-29 14:51:07');
INSERT INTO `hms_physical_record` VALUES ('634', '20', '2', '2018-01-29 14:51:59', '正常', '30', '29', '2018-01-29 14:52:01');
INSERT INTO `hms_physical_record` VALUES ('635', '20', '5', '2018-01-29 14:51:59', '正常区间', '24', '29', '2018-01-29 14:52:01');
INSERT INTO `hms_physical_record` VALUES ('636', '6', '9', '2018-01-29 14:56:06', '北京市昌平区育知东路辅路', '342', '13', '2018-01-29 14:56:08');
INSERT INTO `hms_physical_record` VALUES ('637', '6', '9', '2018-01-29 15:01:06', '北京市昌平区育知东路辅路', '343', '13', '2018-01-29 15:01:17');
INSERT INTO `hms_physical_record` VALUES ('638', '6', '9', '2018-01-29 15:06:06', '北京市昌平区育知东路辅路', '344', '13', '2018-01-29 15:06:14');
INSERT INTO `hms_physical_record` VALUES ('639', '6', '9', '2018-01-29 15:11:06', '北京市昌平区文华路', '345', '13', '2018-01-29 15:11:07');
INSERT INTO `hms_physical_record` VALUES ('640', '6', '9', '2018-01-29 15:16:06', '北京市昌平区文华路', '346', '13', '2018-01-29 15:16:07');
INSERT INTO `hms_physical_record` VALUES ('641', '6', '9', '2018-01-29 15:21:06', '北京市昌平区文华路', '347', '13', '2018-01-29 15:21:07');
INSERT INTO `hms_physical_record` VALUES ('642', '6', '9', '2018-01-29 15:26:06', '北京市昌平区育知东路辅路', '348', '13', '2018-01-29 15:26:10');
INSERT INTO `hms_physical_record` VALUES ('643', '20', '9', '2018-01-29 15:31:06', '北京市昌平区育知东路辅路', '349', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_physical_record` VALUES ('644', '20', '9', '2018-01-29 15:36:06', '北京市昌平区文华路', '350', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_physical_record` VALUES ('645', '20', '9', '2018-01-29 15:41:06', '北京市昌平区文华路', '351', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_physical_record` VALUES ('646', '20', '9', '2018-01-29 15:46:06', '北京市昌平区文华路', '352', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_physical_record` VALUES ('647', '20', '9', '2018-01-29 15:51:06', '北京市昌平区文华路', '353', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_physical_record` VALUES ('648', '20', '9', '2018-01-29 15:56:06', '北京市昌平区文华路', '354', '29', '2018-01-29 15:56:08');
INSERT INTO `hms_physical_record` VALUES ('649', '20', '9', '2018-01-29 16:01:06', '北京市昌平区文华路', '355', '29', '2018-01-29 16:01:08');
INSERT INTO `hms_physical_record` VALUES ('650', '20', '9', '2018-01-29 16:06:06', '北京市昌平区同成街', '356', '29', '2018-01-29 16:06:08');
INSERT INTO `hms_physical_record` VALUES ('651', '20', '9', '2018-01-29 16:11:06', '北京市昌平区育知东路辅路', '357', '29', '2018-01-29 16:11:15');
INSERT INTO `hms_physical_record` VALUES ('652', '20', '9', '2018-01-29 16:16:07', '北京市昌平区同成街', '358', '29', '2018-01-29 16:16:09');
INSERT INTO `hms_physical_record` VALUES ('653', '20', '9', '2018-01-29 16:21:06', '北京市昌平区文华路', '359', '29', '2018-01-29 16:21:08');
INSERT INTO `hms_physical_record` VALUES ('654', '20', '9', '2018-01-29 16:26:07', '北京市昌平区同成街', '360', '29', '2018-01-29 16:26:08');
INSERT INTO `hms_physical_record` VALUES ('655', '20', '9', '2018-01-29 16:31:07', '北京市昌平区文华路', '361', '29', '2018-01-29 16:31:09');
INSERT INTO `hms_physical_record` VALUES ('656', '20', '9', '2018-01-29 16:36:07', '北京市昌平区同成街', '362', '29', '2018-01-29 16:36:08');
INSERT INTO `hms_physical_record` VALUES ('657', '20', '9', '2018-01-29 16:41:07', '北京市昌平区文华路', '363', '29', '2018-01-29 16:41:09');
INSERT INTO `hms_physical_record` VALUES ('658', '20', '9', '2018-01-29 16:46:07', '北京市昌平区文华路', '364', '29', '2018-01-29 16:46:09');
INSERT INTO `hms_physical_record` VALUES ('659', '20', '9', '2018-01-29 16:51:07', '北京市昌平区文华路', '365', '29', '2018-01-29 16:51:09');
INSERT INTO `hms_physical_record` VALUES ('660', '20', '9', '2018-01-29 16:56:07', '北京市昌平区文华路', '366', '29', '2018-01-29 16:56:09');
INSERT INTO `hms_physical_record` VALUES ('661', '20', '9', '2018-01-29 17:01:07', '北京市昌平区文华路', '367', '29', '2018-01-29 17:01:09');
INSERT INTO `hms_physical_record` VALUES ('662', '20', '9', '2018-01-29 17:06:07', '北京市昌平区文华路', '368', '29', '2018-01-29 17:06:09');
INSERT INTO `hms_physical_record` VALUES ('663', '20', '9', '2018-01-29 17:11:07', '北京市昌平区文华路', '369', '29', '2018-01-29 17:11:09');
INSERT INTO `hms_physical_record` VALUES ('664', '20', '9', '2018-01-29 17:16:07', '北京市昌平区文华路', '370', '29', '2018-01-29 17:16:09');
INSERT INTO `hms_physical_record` VALUES ('665', '20', '9', '2018-01-29 17:21:07', '北京市昌平区文华路', '371', '29', '2018-01-29 17:21:09');
INSERT INTO `hms_physical_record` VALUES ('666', '20', '9', '2018-01-29 17:26:07', '北京市昌平区文华路', '372', '29', '2018-01-29 17:26:09');
INSERT INTO `hms_physical_record` VALUES ('667', '20', '9', '2018-01-29 17:31:07', '北京市昌平区文华路', '373', '29', '2018-01-29 17:31:09');
INSERT INTO `hms_physical_record` VALUES ('668', '20', '9', '2018-01-29 17:36:08', '北京市昌平区文华路', '374', '29', '2018-01-29 17:36:09');
INSERT INTO `hms_physical_record` VALUES ('669', '20', '9', '2018-01-29 17:41:08', '北京市昌平区文华路', '375', '29', '2018-01-29 17:41:40');
INSERT INTO `hms_physical_record` VALUES ('670', '20', '9', '2018-01-29 17:46:08', '北京市昌平区文华路', '376', '29', '2018-01-29 17:46:09');
INSERT INTO `hms_physical_record` VALUES ('671', '20', '9', '2018-01-29 17:56:07', '北京市昌平区文华路', '377', '29', '2018-01-29 17:56:09');
INSERT INTO `hms_physical_record` VALUES ('672', '20', '9', '2018-01-29 18:01:07', '北京市昌平区文华路', '378', '29', '2018-01-29 18:01:09');
INSERT INTO `hms_physical_record` VALUES ('673', '20', '9', '2018-01-29 18:06:07', '北京市昌平区文华路', '379', '29', '2018-01-29 18:06:09');
INSERT INTO `hms_physical_record` VALUES ('674', '20', '9', '2018-01-29 18:11:07', '北京市昌平区文华路', '380', '29', '2018-01-29 18:21:44');
INSERT INTO `hms_physical_record` VALUES ('675', '20', '9', '2018-01-29 18:16:07', '北京市昌平区文华路', '381', '29', '2018-01-29 18:21:44');
INSERT INTO `hms_physical_record` VALUES ('676', '20', '9', '2018-01-29 18:26:07', '北京市昌平区育知东路辅路', '382', '29', '2018-01-29 18:26:44');
INSERT INTO `hms_physical_record` VALUES ('677', '20', '9', '2018-01-29 18:31:07', '北京市昌平区文华路', '383', '29', '2018-01-29 18:31:09');
INSERT INTO `hms_physical_record` VALUES ('678', '20', '9', '2018-01-29 18:36:07', '北京市昌平区文华路', '384', '29', '2018-01-29 18:36:09');
INSERT INTO `hms_physical_record` VALUES ('679', '20', '9', '2018-01-29 18:41:07', '北京市昌平区文华路', '385', '29', '2018-01-29 18:41:09');
INSERT INTO `hms_physical_record` VALUES ('680', '20', '9', '2018-01-29 18:46:07', '北京市昌平区文华路', '386', '29', '2018-01-29 18:46:09');
INSERT INTO `hms_physical_record` VALUES ('681', '20', '9', '2018-01-29 18:51:07', '北京市昌平区育知东路辅路', '387', '29', '2018-01-29 18:51:10');
INSERT INTO `hms_physical_record` VALUES ('682', '20', '9', '2018-01-29 18:56:08', '北京市昌平区文华路', '388', '29', '2018-01-29 18:56:10');
INSERT INTO `hms_physical_record` VALUES ('683', '20', '9', '2018-01-29 19:01:08', '北京市昌平区文华路', '389', '29', '2018-01-29 19:01:10');
INSERT INTO `hms_physical_record` VALUES ('684', '20', '9', '2018-01-29 19:06:08', '北京市昌平区育知东路辅路', '390', '29', '2018-01-29 19:06:11');
INSERT INTO `hms_physical_record` VALUES ('685', '20', '9', '2018-01-29 19:11:08', '北京市昌平区文华路', '391', '29', '2018-01-29 19:11:10');
INSERT INTO `hms_physical_record` VALUES ('686', '20', '9', '2018-01-29 19:16:08', '北京市昌平区文华路', '392', '29', '2018-01-29 19:16:10');
INSERT INTO `hms_physical_record` VALUES ('687', '20', '9', '2018-01-29 19:21:08', '北京市昌平区文华路', '393', '29', '2018-01-29 19:21:10');
INSERT INTO `hms_physical_record` VALUES ('688', '20', '9', '2018-01-29 19:26:08', '北京市昌平区文华路', '394', '29', '2018-01-29 19:26:10');
INSERT INTO `hms_physical_record` VALUES ('689', '20', '9', '2018-01-29 19:31:08', '北京市昌平区文华路', '395', '29', '2018-01-29 19:31:10');
INSERT INTO `hms_physical_record` VALUES ('690', '20', '9', '2018-01-29 19:36:08', '北京市昌平区文华路', '396', '29', '2018-01-29 19:36:10');
INSERT INTO `hms_physical_record` VALUES ('691', '20', '9', '2018-01-29 19:41:09', '北京市昌平区文华路', '397', '29', '2018-01-29 19:41:10');
INSERT INTO `hms_physical_record` VALUES ('692', '20', '9', '2018-01-29 19:46:08', '北京市昌平区文华路', '398', '29', '2018-01-29 19:46:10');
INSERT INTO `hms_physical_record` VALUES ('693', '20', '9', '2018-01-29 19:51:09', '北京市昌平区文华路', '399', '29', '2018-01-29 19:51:11');
INSERT INTO `hms_physical_record` VALUES ('694', '20', '9', '2018-01-29 19:56:09', '北京市昌平区文华路', '400', '29', '2018-01-29 19:56:11');
INSERT INTO `hms_physical_record` VALUES ('695', '20', '9', '2018-01-29 20:01:09', '北京市昌平区文华路', '401', '29', '2018-01-29 20:01:11');
INSERT INTO `hms_physical_record` VALUES ('696', '20', '9', '2018-01-29 20:06:09', '北京市昌平区文华路', '402', '29', '2018-01-29 20:06:11');
INSERT INTO `hms_physical_record` VALUES ('697', '20', '9', '2018-01-29 20:11:09', '北京市昌平区文华路', '403', '29', '2018-01-29 20:11:11');
INSERT INTO `hms_physical_record` VALUES ('698', '20', '9', '2018-01-29 20:16:09', '北京市昌平区育知东路辅路', '404', '29', '2018-01-29 20:16:11');
INSERT INTO `hms_physical_record` VALUES ('699', '20', '9', '2018-01-29 20:21:09', '北京市昌平区育知东路辅路', '405', '29', '2018-01-29 20:21:11');
INSERT INTO `hms_physical_record` VALUES ('700', '20', '9', '2018-01-29 20:26:09', '北京市昌平区文华路', '406', '29', '2018-01-29 20:26:11');
INSERT INTO `hms_physical_record` VALUES ('701', '20', '9', '2018-01-29 20:31:09', '北京市昌平区文华路', '407', '29', '2018-01-29 20:31:11');
INSERT INTO `hms_physical_record` VALUES ('702', '20', '9', '2018-01-29 20:36:09', '北京市昌平区文华路', '408', '29', '2018-01-29 20:36:11');
INSERT INTO `hms_physical_record` VALUES ('703', '20', '9', '2018-01-29 20:41:09', '北京市昌平区文华路', '409', '29', '2018-01-29 20:41:11');
INSERT INTO `hms_physical_record` VALUES ('704', '20', '9', '2018-01-29 20:46:09', '北京市昌平区文华路', '410', '29', '2018-01-29 20:46:11');
INSERT INTO `hms_physical_record` VALUES ('705', '20', '9', '2018-01-29 20:51:09', '北京市昌平区文华路', '411', '29', '2018-01-29 20:51:11');
INSERT INTO `hms_physical_record` VALUES ('706', '20', '9', '2018-01-29 20:56:09', '北京市昌平区文华路', '412', '29', '2018-01-29 20:56:11');
INSERT INTO `hms_physical_record` VALUES ('707', '20', '9', '2018-01-29 21:01:09', '北京市昌平区文华路', '413', '29', '2018-01-29 21:01:11');
INSERT INTO `hms_physical_record` VALUES ('708', '20', '9', '2018-01-29 21:06:09', '北京市昌平区文华路', '414', '29', '2018-01-29 21:06:11');
INSERT INTO `hms_physical_record` VALUES ('709', '20', '9', '2018-01-29 21:11:09', '北京市昌平区文华路', '415', '29', '2018-01-29 21:11:11');
INSERT INTO `hms_physical_record` VALUES ('710', '20', '9', '2018-01-29 21:16:09', '北京市昌平区文华路', '416', '29', '2018-01-29 21:16:12');
INSERT INTO `hms_physical_record` VALUES ('711', '20', '9', '2018-01-29 21:21:09', '北京市昌平区文华路', '417', '29', '2018-01-29 21:21:11');
INSERT INTO `hms_physical_record` VALUES ('712', '20', '9', '2018-01-29 21:26:09', '北京市昌平区文华路', '418', '29', '2018-01-29 21:26:11');
INSERT INTO `hms_physical_record` VALUES ('713', '20', '9', '2018-01-29 21:31:09', '北京市昌平区文华路', '419', '29', '2018-01-29 21:31:11');
INSERT INTO `hms_physical_record` VALUES ('714', '20', '9', '2018-01-29 21:36:09', '北京市昌平区文华路', '420', '29', '2018-01-29 21:36:11');
INSERT INTO `hms_physical_record` VALUES ('715', '20', '9', '2018-01-29 21:41:09', '北京市昌平区文华路', '421', '29', '2018-01-29 21:41:11');
INSERT INTO `hms_physical_record` VALUES ('716', '20', '9', '2018-01-29 21:46:09', '北京市昌平区文华路', '422', '29', '2018-01-29 21:46:11');
INSERT INTO `hms_physical_record` VALUES ('717', '20', '9', '2018-01-29 21:51:09', '北京市昌平区文华路', '423', '29', '2018-01-29 21:51:11');
INSERT INTO `hms_physical_record` VALUES ('718', '20', '9', '2018-01-29 21:56:09', '北京市昌平区文华路', '424', '29', '2018-01-29 21:56:11');
INSERT INTO `hms_physical_record` VALUES ('719', '20', '9', '2018-01-29 22:01:09', '北京市昌平区文华路', '425', '29', '2018-01-29 22:01:11');
INSERT INTO `hms_physical_record` VALUES ('720', '20', '9', '2018-01-29 22:06:09', '北京市昌平区文华路', '426', '29', '2018-01-29 22:06:11');
INSERT INTO `hms_physical_record` VALUES ('721', '20', '9', '2018-01-29 22:11:09', '北京市昌平区文华路', '427', '29', '2018-01-29 22:11:11');
INSERT INTO `hms_physical_record` VALUES ('722', '20', '9', '2018-01-29 22:16:09', '北京市昌平区文华路', '428', '29', '2018-01-29 22:16:11');
INSERT INTO `hms_physical_record` VALUES ('723', '20', '9', '2018-01-29 22:21:09', '北京市昌平区文华路', '429', '29', '2018-01-29 22:21:11');
INSERT INTO `hms_physical_record` VALUES ('724', '20', '9', '2018-01-29 22:26:09', '北京市昌平区文华路', '430', '29', '2018-01-29 22:26:11');
INSERT INTO `hms_physical_record` VALUES ('725', '20', '9', '2018-01-29 22:31:09', '北京市昌平区文华路', '431', '29', '2018-01-29 22:31:11');
INSERT INTO `hms_physical_record` VALUES ('726', '20', '9', '2018-01-29 22:36:10', '北京市昌平区文华路', '432', '29', '2018-01-29 22:36:11');
INSERT INTO `hms_physical_record` VALUES ('727', '20', '9', '2018-01-29 22:41:09', '北京市昌平区文华路', '433', '29', '2018-01-29 22:41:11');
INSERT INTO `hms_physical_record` VALUES ('728', '20', '9', '2018-01-29 22:46:09', '北京市昌平区文华路', '434', '29', '2018-01-29 22:46:11');
INSERT INTO `hms_physical_record` VALUES ('729', '20', '9', '2018-01-29 22:51:10', '北京市昌平区文华路', '435', '29', '2018-01-29 22:51:12');
INSERT INTO `hms_physical_record` VALUES ('730', '20', '9', '2018-01-29 22:56:10', '北京市昌平区文华路', '436', '29', '2018-01-29 22:56:12');
INSERT INTO `hms_physical_record` VALUES ('731', '20', '9', '2018-01-29 23:01:10', '北京市昌平区文华路', '437', '29', '2018-01-29 23:01:11');
INSERT INTO `hms_physical_record` VALUES ('732', '20', '9', '2018-01-29 23:06:10', '北京市昌平区文华路', '438', '29', '2018-01-29 23:06:11');
INSERT INTO `hms_physical_record` VALUES ('733', '20', '9', '2018-01-29 23:11:10', '北京市昌平区文华路', '439', '29', '2018-01-29 23:11:12');
INSERT INTO `hms_physical_record` VALUES ('734', '20', '9', '2018-01-29 23:16:10', '北京市昌平区文华路', '440', '29', '2018-01-29 23:16:12');
INSERT INTO `hms_physical_record` VALUES ('735', '20', '9', '2018-01-29 23:21:10', '北京市昌平区文华路', '441', '29', '2018-01-29 23:21:12');
INSERT INTO `hms_physical_record` VALUES ('736', '20', '9', '2018-01-29 23:26:10', '北京市昌平区文华路', '442', '29', '2018-01-29 23:26:44');
INSERT INTO `hms_physical_record` VALUES ('737', '20', '9', '2018-01-29 23:31:10', '北京市昌平区文华路', '443', '29', '2018-01-29 23:31:12');
INSERT INTO `hms_physical_record` VALUES ('738', '20', '9', '2018-01-29 23:36:10', '北京市昌平区文华路', '444', '29', '2018-01-29 23:36:12');
INSERT INTO `hms_physical_record` VALUES ('739', '20', '9', '2018-01-29 23:41:10', '北京市昌平区文华路', '445', '29', '2018-01-29 23:41:12');
INSERT INTO `hms_physical_record` VALUES ('740', '20', '9', '2018-01-29 23:46:10', '北京市昌平区文华路', '446', '29', '2018-01-29 23:46:12');
INSERT INTO `hms_physical_record` VALUES ('741', '20', '9', '2018-01-29 23:51:11', '北京市昌平区文华路', '447', '29', '2018-01-29 23:51:13');
INSERT INTO `hms_physical_record` VALUES ('742', '20', '9', '2018-01-29 23:56:11', '北京市昌平区文华路', '448', '29', '2018-01-29 23:56:13');
INSERT INTO `hms_physical_record` VALUES ('743', '20', '1', '2018-01-30 11:41:01', '正常', '189', '43', '2018-01-30 11:41:04');
INSERT INTO `hms_physical_record` VALUES ('744', '134', '4', '2018-01-30 15:37:00', '正常指标', '46', '50', '2018-01-30 15:37:02');
INSERT INTO `hms_physical_record` VALUES ('745', '134', '4', '2018-01-30 15:38:33', '正常指标', '47', '50', '2018-01-30 15:38:35');
INSERT INTO `hms_physical_record` VALUES ('746', '134', '1', '2018-01-30 15:39:23', '偏瘦', '190', '50', '2018-01-30 15:39:25');
INSERT INTO `hms_physical_record` VALUES ('747', '134', '1', '2018-01-30 15:42:17', '偏瘦', '191', '50', '2018-01-30 15:42:19');
INSERT INTO `hms_physical_record` VALUES ('748', '134', '2', '2018-01-30 15:45:57', '正常', '31', '50', '2018-01-30 15:45:58');
INSERT INTO `hms_physical_record` VALUES ('749', '134', '5', '2018-01-30 15:45:57', '正常区间', '25', '50', '2018-01-30 15:45:58');
INSERT INTO `hms_physical_record` VALUES ('750', '134', '4', '2018-01-31 10:52:40', '正常指标', '48', '50', '2018-01-31 10:52:42');
INSERT INTO `hms_physical_record` VALUES ('751', '134', '4', '2018-01-31 14:17:20', '正常指标', '49', '50', '2018-01-31 14:17:22');
INSERT INTO `hms_physical_record` VALUES ('752', '134', '4', '2018-01-31 14:17:48', '正常指标', '50', '50', '2018-01-31 14:17:51');
INSERT INTO `hms_physical_record` VALUES ('753', '134', '4', '2018-01-31 14:22:45', '正常指标', '51', '50', '2018-01-31 14:22:47');
INSERT INTO `hms_physical_record` VALUES ('754', '134', '4', '2018-01-31 14:50:29', '正常指标', '52', '50', '2018-01-31 14:50:31');
INSERT INTO `hms_physical_record` VALUES ('755', '134', '4', '2018-01-31 14:50:57', '正常指标', '53', '50', '2018-01-31 14:51:00');
INSERT INTO `hms_physical_record` VALUES ('756', '134', '4', '2018-01-31 14:51:28', '正常指标', '54', '50', '2018-01-31 14:51:30');
INSERT INTO `hms_physical_record` VALUES ('757', '134', '4', '2018-01-31 14:51:59', '正常指标', '55', '50', '2018-01-31 14:52:01');
INSERT INTO `hms_physical_record` VALUES ('758', '134', '1', '2018-02-01 08:55:53', '偏胖', '192', '50', '2018-02-01 08:55:54');
INSERT INTO `hms_physical_record` VALUES ('759', '134', '2', '2018-02-01 09:42:32', '高血压', '32', '50', '2018-02-01 09:42:34');
INSERT INTO `hms_physical_record` VALUES ('760', '134', '5', '2018-02-01 09:42:32', '正常区间', '26', '50', '2018-02-01 09:42:34');
INSERT INTO `hms_physical_record` VALUES ('761', '25', '2', '2018-02-01 10:24:11', '正常', '33', '34', '2018-02-01 10:24:12');
INSERT INTO `hms_physical_record` VALUES ('762', '25', '5', '2018-02-01 10:24:11', '正常区间', '27', '34', '2018-02-01 10:24:12');
INSERT INTO `hms_physical_record` VALUES ('763', '25', '4', '2018-02-01 14:38:47', '正常指标', '56', '34', '2018-02-01 14:38:49');
INSERT INTO `hms_physical_record` VALUES ('764', '25', '4', '2018-02-01 14:39:18', '正常指标', '57', '34', '2018-02-01 14:39:19');
INSERT INTO `hms_physical_record` VALUES ('765', '134', '4', '2018-02-01 15:07:42', '正常指标', '58', '50', '2018-02-01 15:07:44');
INSERT INTO `hms_physical_record` VALUES ('766', '134', '4', '2018-02-01 15:23:21', '正常指标', '59', '50', '2018-02-01 15:23:24');
INSERT INTO `hms_physical_record` VALUES ('767', '134', '1', '2018-02-01 15:27:51', '偏瘦', '193', '50', '2018-02-01 15:27:53');
INSERT INTO `hms_physical_record` VALUES ('768', '134', '4', '2018-02-01 16:06:20', '正常指标', '60', '50', '2018-02-01 16:06:22');
INSERT INTO `hms_physical_record` VALUES ('769', '134', '4', '2018-02-01 16:06:51', '正常指标', '61', '50', '2018-02-01 16:06:53');
INSERT INTO `hms_physical_record` VALUES ('770', '25', '1', '2018-02-01 18:20:25', '正常', '194', '34', '2018-02-01 18:20:27');
INSERT INTO `hms_physical_record` VALUES ('771', '25', '2', '2018-02-01 18:21:48', '正常', '34', '34', '2018-02-01 18:21:49');
INSERT INTO `hms_physical_record` VALUES ('772', '25', '5', '2018-02-01 18:21:48', '正常区间', '28', '34', '2018-02-01 18:21:49');
INSERT INTO `hms_physical_record` VALUES ('773', '25', '2', '2018-02-01 18:30:58', '数值异常', '35', '34', '2018-02-01 18:31:00');
INSERT INTO `hms_physical_record` VALUES ('774', '25', '5', '2018-02-01 18:30:58', '正常区间', '29', '34', '2018-02-01 18:31:00');
INSERT INTO `hms_physical_record` VALUES ('775', '134', '4', '2018-02-02 09:13:59', '正常指标', '62', '50', '2018-02-02 09:14:02');
INSERT INTO `hms_physical_record` VALUES ('776', '25', '4', '2018-02-02 09:15:20', '正常指标', '63', '34', '2018-02-02 09:15:22');
INSERT INTO `hms_physical_record` VALUES ('777', '25', '2', '2018-02-02 09:19:24', '正常', '36', '34', '2018-02-02 09:19:24');
INSERT INTO `hms_physical_record` VALUES ('778', '25', '5', '2018-02-02 09:19:24', '正常区间', '30', '34', '2018-02-02 09:19:24');
INSERT INTO `hms_physical_record` VALUES ('779', '134', '4', '2018-02-02 09:21:24', '正常指标', '64', '50', '2018-02-02 09:21:27');
INSERT INTO `hms_physical_record` VALUES ('780', '134', '2', '2018-02-02 09:23:49', '正常', '37', '50', '2018-02-02 09:23:51');
INSERT INTO `hms_physical_record` VALUES ('781', '134', '5', '2018-02-02 09:23:49', '正常区间', '31', '50', '2018-02-02 09:23:51');
INSERT INTO `hms_physical_record` VALUES ('782', '134', '1', '2018-02-02 09:25:35', '偏瘦', '195', '50', '2018-02-02 09:25:36');
INSERT INTO `hms_physical_record` VALUES ('783', '134', '4', '2018-02-02 09:26:37', '正常指标', '65', '50', '2018-02-02 09:26:37');
INSERT INTO `hms_physical_record` VALUES ('784', '134', '4', '2018-02-02 09:26:51', '正常指标', '66', '50', '2018-02-02 09:26:53');
INSERT INTO `hms_physical_record` VALUES ('785', '134', '4', '2018-02-02 09:27:04', '正常指标', '67', '50', '2018-02-02 09:27:06');
INSERT INTO `hms_physical_record` VALUES ('786', '134', '4', '2018-02-02 09:27:19', '正常指标', '68', '50', '2018-02-02 09:27:21');
INSERT INTO `hms_physical_record` VALUES ('787', '134', '1', '2018-02-05 13:04:02', '正常', '196', '50', '2018-02-05 13:04:04');

-- ----------------------------
-- Table structure for hms_physical_weight
-- ----------------------------
DROP TABLE IF EXISTS `hms_physical_weight`;
CREATE TABLE `hms_physical_weight` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增长',
  `MEMBER_ID` int(11) NOT NULL COMMENT '外键表：HMS_MEMBER，外键字段：ID',
  `PHYSICAL_TIME` datetime DEFAULT NULL,
  `WEIGHT` float(4,1) DEFAULT NULL COMMENT '单位kg，公斤或千克',
  `PHYSICAL_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL COMMENT '外键表：UUMS_USER，外键字段：ID',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `HMS_PHYSICAL_WEIGHT_MEMBER` (`MEMBER_ID`),
  KEY `HMS_PHYSICAL_WEIGHT_CREATOR` (`CREATOR`),
  CONSTRAINT `HMS_PHYSICAL_WEIGHT_CREATOR` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`),
  CONSTRAINT `HMS_PHYSICAL_WEIGHT_MEMBER` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_physical_weight
-- ----------------------------
INSERT INTO `hms_physical_weight` VALUES ('1', '1', '2017-11-24 09:45:56', '57.8', null, '02000000003520015807010517220001670000000000009006a55d', '1', '2017-11-24 09:46:03');
INSERT INTO `hms_physical_weight` VALUES ('2', '1', '2017-11-24 09:46:49', '57.9', null, '02000000003520015807010517220001670000000000009006a55d', '1', '2017-11-24 09:46:56');
INSERT INTO `hms_physical_weight` VALUES ('177', '12', '2017-12-04 11:56:16', '62.2', '正常', '02000000003520015807010517220001670000000000009006a55d', '20', '2017-12-04 11:56:18');
INSERT INTO `hms_physical_weight` VALUES ('178', '12', '2017-12-04 12:07:57', '57.0', null, '02000000003520015807010517220001670000000000009006a55d', '20', '2017-12-04 12:08:00');
INSERT INTO `hms_physical_weight` VALUES ('179', '20', '2018-01-26 12:33:31', '18.7', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-26 12:33:32');
INSERT INTO `hms_physical_weight` VALUES ('180', '20', '2018-01-26 12:33:51', '67.2', '偏胖', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-26 12:33:53');
INSERT INTO `hms_physical_weight` VALUES ('181', '20', '2018-01-26 12:34:06', '13.1', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-26 12:34:08');
INSERT INTO `hms_physical_weight` VALUES ('182', '20', '2018-01-26 12:47:49', '54.2', '正常', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-26 12:47:50');
INSERT INTO `hms_physical_weight` VALUES ('183', '20', '2018-01-29 10:35:06', '65.4', '偏胖', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 10:35:08');
INSERT INTO `hms_physical_weight` VALUES ('184', '20', '2018-01-29 10:37:33', '15.4', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 10:37:36');
INSERT INTO `hms_physical_weight` VALUES ('185', '20', '2018-01-29 10:38:41', '27.1', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 10:38:43');
INSERT INTO `hms_physical_weight` VALUES ('186', '20', '2018-01-29 10:41:44', '38.4', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 10:41:47');
INSERT INTO `hms_physical_weight` VALUES ('187', '20', '2018-01-29 11:05:17', '34.9', '偏瘦', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 11:05:19');
INSERT INTO `hms_physical_weight` VALUES ('188', '20', '2018-01-29 13:30:25', '68.0', '偏胖', '020000000035200158070105172200016700000000000090a4a45d', '29', '2018-01-29 13:30:27');
INSERT INTO `hms_physical_weight` VALUES ('189', '20', '2018-01-30 11:41:01', '63.0', '正常', '0200000000352001580701051722000167000000000000402dd95d', '43', '2018-01-30 11:41:04');
INSERT INTO `hms_physical_weight` VALUES ('190', '134', '2018-01-30 15:39:23', '15.3', '偏瘦', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-01-30 15:39:25');
INSERT INTO `hms_physical_weight` VALUES ('191', '134', '2018-01-30 15:42:17', '32.0', '偏瘦', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-01-30 15:42:19');
INSERT INTO `hms_physical_weight` VALUES ('192', '134', '2018-02-01 08:55:53', '66.9', '偏胖', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-02-01 08:55:54');
INSERT INTO `hms_physical_weight` VALUES ('193', '134', '2018-02-01 15:27:51', '21.4', '偏瘦', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-02-01 15:27:53');
INSERT INTO `hms_physical_weight` VALUES ('194', '25', '2018-02-01 18:20:25', '68.2', '正常', '0200000000352001580701051722000167000000000000c0a5a85d', '34', '2018-02-01 18:20:27');
INSERT INTO `hms_physical_weight` VALUES ('195', '134', '2018-02-02 09:25:35', '23.6', '偏瘦', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-02-02 09:25:36');
INSERT INTO `hms_physical_weight` VALUES ('196', '134', '2018-02-05 13:04:02', '53.4', '正常', '0200000000352001580701051722000167000000000000402dd95d', '50', '2018-02-05 13:04:04');

-- ----------------------------
-- Table structure for hms_position
-- ----------------------------
DROP TABLE IF EXISTS `hms_position`;
CREATE TABLE `hms_position` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MEMBER_ID` int(11) NOT NULL,
  `LOCATION_TIME` datetime DEFAULT NULL,
  `LONGITUDE` double(9,6) DEFAULT NULL,
  `LATITUDE` double(9,6) DEFAULT NULL,
  `POSITION_STATUS` varchar(200) DEFAULT NULL,
  `DATA_KEY` text,
  `CREATOR` int(11) NOT NULL,
  `CREATE_TIME` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_MEMBER_POSITION` (`MEMBER_ID`),
  KEY `FK_POSITION_CREATER` (`CREATOR`),
  CONSTRAINT `FK_MEMBER_POSITION` FOREIGN KEY (`MEMBER_ID`) REFERENCES `hms_member` (`ID`),
  CONSTRAINT `FK_POSITION_CREATER` FOREIGN KEY (`CREATOR`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=449 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hms_position
-- ----------------------------
INSERT INTO `hms_position` VALUES ('1', '20', '2018-01-27 21:59:52', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|28#10e3|55d|646|25#10e3|d622|639|9#10d5|9ea8|641|9#10e3|e8c4|654|8', '29', '2018-01-27 21:59:53');
INSERT INTO `hms_position` VALUES ('2', '20', '2018-01-27 22:04:54', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$6$460$1$255#10e3|55d|646|28#10e3|e8d6|644|25#10e3|e8c3|648|19#10e3|55c|637|13#10e3|d622|639|12#10e3|e8c4|654|12', '29', '2018-01-27 22:04:56');
INSERT INTO `hms_position` VALUES ('3', '20', '2018-01-27 22:09:53', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$6$460$1$255#10e3|55d|646|31#10e3|e8c3|648|27#10e3|e8d6|644|26#10e3|d622|639|16#10e3|e8c4|654|9#10e3|60f2|640|8', '29', '2018-01-27 22:09:55');
INSERT INTO `hms_position` VALUES ('4', '20', '2018-01-27 22:14:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|28#10e3|55d|646|27#10e3|d622|639|14#10d5|9ea8|641|12#10e3|d620|650|10#10e3|e8c4|654|7', '29', '2018-01-27 22:14:54');
INSERT INTO `hms_position` VALUES ('5', '20', '2018-01-27 22:19:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|34#10e3|55d|646|28#10e3|d622|639|14#10e3|d620|650|13#10d5|9ea8|641|11#10e3|60f2|640|7', '29', '2018-01-27 22:19:54');
INSERT INTO `hms_position` VALUES ('6', '20', '2018-01-27 22:24:52', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|33#10e3|55d|646|21#10e3|e8c4|654|9#10e3|d622|639|6#10d5|9ea8|641|4', '29', '2018-01-27 22:24:55');
INSERT INTO `hms_position` VALUES ('7', '20', '2018-01-27 22:29:52', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|27#10e3|55d|646|25#10e3|d620|650|15#10e3|d622|639|11#10e3|e8c4|654|9#10e3|2d1c|123|7', '29', '2018-01-27 22:29:54');
INSERT INTO `hms_position` VALUES ('8', '20', '2018-01-27 22:34:52', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|25#10e3|d620|650|13#10e3|e8c4|654|12#10e3|d622|639|12#10e4|d14e|653|9#10e3|55d|646|8', '29', '2018-01-27 22:34:54');
INSERT INTO `hms_position` VALUES ('9', '20', '2018-01-27 22:39:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|21#10e3|d620|650|12#10e3|e8c4|654|10#10e3|55d|646|8', '29', '2018-01-27 22:39:54');
INSERT INTO `hms_position` VALUES ('10', '20', '2018-01-27 22:44:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|27#10e3|55d|646|15#10e3|d620|650|13#10e3|e8c4|654|8#10e3|d622|639|7', '29', '2018-01-27 22:44:56');
INSERT INTO `hms_position` VALUES ('11', '20', '2018-01-27 22:49:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|23#10e3|d622|639|11#10e3|e976|649|9#10e3|e8c4|654|7#10e3|d620|650|3', '29', '2018-01-27 22:49:55');
INSERT INTO `hms_position` VALUES ('12', '20', '2018-01-27 22:54:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|20#10e3|55d|646|12#10e3|d620|650|9#10e3|d622|639|9#10e3|e8c4|654|2', '29', '2018-01-27 22:54:56');
INSERT INTO `hms_position` VALUES ('13', '20', '2018-01-27 22:59:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|26#10e3|55d|646|18#10e3|d622|639|6', '29', '2018-01-27 22:59:55');
INSERT INTO `hms_position` VALUES ('14', '20', '2018-01-27 23:04:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|25#10e3|d620|650|18#10e3|55d|646|12#10e3|d622|639|9#10e3|e8c4|654|7', '29', '2018-01-27 23:04:55');
INSERT INTO `hms_position` VALUES ('15', '20', '2018-01-27 23:09:53', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$4$460$1$255#10e3|55d|646|22#10e3|e8c3|648|18#10e3|e8d6|644|16#10e3|d622|639|13', '29', '2018-01-27 23:09:55');
INSERT INTO `hms_position` VALUES ('16', '20', '2018-01-27 23:14:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$2$460$1$255#10e3|e8c3|648|25#10e3|55d|646|9', '29', '2018-01-27 23:14:55');
INSERT INTO `hms_position` VALUES ('17', '20', '2018-01-27 23:19:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$2$460$1$255#10e3|e8c3|648|23#10e3|55d|646|12', '29', '2018-01-27 23:19:56');
INSERT INTO `hms_position` VALUES ('18', '20', '2018-01-27 23:24:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|27#10e3|55d|646|18#10e3|e8c4|654|12#10e3|d622|639|8#10e3|d620|650|8', '29', '2018-01-27 23:24:56');
INSERT INTO `hms_position` VALUES ('19', '20', '2018-01-27 23:29:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|34#10e3|e8c4|654|22#10e3|e8c2|639|20#10e3|55b|653|19#10e3|d620|650|18', '29', '2018-01-27 23:29:56');
INSERT INTO `hms_position` VALUES ('20', '20', '2018-01-27 23:34:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|33#10e3|e8c4|654|22#10e3|55b|653|20#10e3|e8c2|639|19#10e3|d620|650|17', '29', '2018-01-27 23:34:55');
INSERT INTO `hms_position` VALUES ('21', '20', '2018-01-27 23:40:34', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|33#10e3|e8c4|654|22#10e3|55b|653|19#10e3|e8c2|639|17#10e3|2d1c|123|16', '29', '2018-01-27 23:40:35');
INSERT INTO `hms_position` VALUES ('22', '20', '2018-01-27 23:44:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|34#10e3|e8c4|654|23#10e3|55b|653|19#10e3|d620|650|19#10e3|e8c2|639|18', '29', '2018-01-27 23:44:55');
INSERT INTO `hms_position` VALUES ('23', '20', '2018-01-27 23:49:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|31#10e3|e8c4|654|23#10e3|55b|653|19#10e3|d620|650|19#10e3|e8c2|639|19', '29', '2018-01-27 23:49:55');
INSERT INTO `hms_position` VALUES ('24', '20', '2018-01-27 23:54:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|55d|646|26#10e3|d622|639|20#10e3|d620|650|17#10e3|e8c4|654|13#10e3|2d1c|123|10', '29', '2018-01-27 23:54:55');
INSERT INTO `hms_position` VALUES ('25', '20', '2018-01-27 23:59:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|26#10e3|55d|646|24#10e3|e8c4|654|13#10e3|d620|650|8#10d5|9ea8|641|6', '29', '2018-01-27 23:59:56');
INSERT INTO `hms_position` VALUES ('26', '20', '2018-01-28 00:04:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|32#10e3|55d|646|24#10e3|e8c4|654|13#10e3|d622|639|13#10e3|55b|653|10#10e3|60f2|640|2', '29', '2018-01-28 00:04:56');
INSERT INTO `hms_position` VALUES ('27', '20', '2018-01-28 00:09:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|28#10e3|55d|646|21#10e3|d622|639|8', '29', '2018-01-28 00:09:55');
INSERT INTO `hms_position` VALUES ('28', '20', '2018-01-28 00:19:53', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|37#10e3|55d|646|21#10e3|e8c4|654|19#10e3|55b|653|16#10e3|d620|650|14#10d5|9ea8|641|8', '29', '2018-01-28 00:19:55');
INSERT INTO `hms_position` VALUES ('29', '20', '2018-01-28 00:24:54', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$4$460$1$255#10e3|55d|646|14#10e3|e8c3|648|13#10e3|55b|653|3#10e3|d622|639|3', '29', '2018-01-28 00:24:56');
INSERT INTO `hms_position` VALUES ('30', '20', '2018-01-28 00:29:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|22#10e3|55d|646|18#10e3|e8d6|644|9#10e3|e8c4|654|9#10e3|e8cd|650|6', '29', '2018-01-28 00:29:56');
INSERT INTO `hms_position` VALUES ('31', '20', '2018-01-28 00:34:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|22#10e3|55d|646|19#10e3|d620|650|8#10e3|e8c4|654|8#10e3|d622|639|2', '29', '2018-01-28 00:34:56');
INSERT INTO `hms_position` VALUES ('32', '20', '2018-01-28 00:39:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|30#10e3|55d|646|26#10e3|55b|653|22#10e3|e8c4|654|20#10e3|d620|650|19', '29', '2018-01-28 00:39:56');
INSERT INTO `hms_position` VALUES ('33', '20', '2018-01-28 00:44:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|d622|639|31#10e3|55d|646|29#10e3|d620|650|21#10e3|55b|653|21#10e3|e8c4|654|20', '29', '2018-01-28 00:44:56');
INSERT INTO `hms_position` VALUES ('34', '20', '2018-01-28 00:50:34', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|37#10e3|d622|639|30#10e3|55d|646|30#10e3|55b|653|22#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 00:50:36');
INSERT INTO `hms_position` VALUES ('35', '20', '2018-01-28 00:54:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|d622|639|31#10e3|55d|646|30#10e3|e976|649|21#10e3|d620|650|21#10e3|e8c4|654|20', '29', '2018-01-28 00:54:56');
INSERT INTO `hms_position` VALUES ('36', '20', '2018-01-28 00:59:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|37#10e3|55d|646|29#10e3|d622|639|29#10e3|55b|653|21#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 00:59:56');
INSERT INTO `hms_position` VALUES ('37', '20', '2018-01-28 01:04:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|30#10e3|55d|646|30#10e3|55b|653|20#10e3|e8c4|654|19#10e3|d620|650|19', '29', '2018-01-28 01:04:56');
INSERT INTO `hms_position` VALUES ('38', '20', '2018-01-28 01:09:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|29#10e3|55d|646|29#10e3|d620|650|21#10e3|e8c4|654|20#10e3|55b|653|20', '29', '2018-01-28 01:09:56');
INSERT INTO `hms_position` VALUES ('39', '20', '2018-01-28 01:14:55', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|30#10e3|55d|646|30#10e3|55b|653|21#10e3|e8c4|654|20#10e3|d620|650|20', '29', '2018-01-28 01:14:57');
INSERT INTO `hms_position` VALUES ('40', '20', '2018-01-28 01:19:54', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|30#10e3|55d|646|28#10e3|55b|653|20#10e3|e8c4|654|20#10e3|d620|650|20', '29', '2018-01-28 01:19:56');
INSERT INTO `hms_position` VALUES ('41', '20', '2018-01-28 01:25:34', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|37#10e3|d622|639|30#10e3|55d|646|28#10e3|55b|653|21#10e3|d620|650|20#10e3|e8c4|654|19', '29', '2018-01-28 01:25:37');
INSERT INTO `hms_position` VALUES ('42', '20', '2018-01-28 01:49:55', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|30#10e3|55d|646|26#10e3|55b|653|23#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 01:49:58');
INSERT INTO `hms_position` VALUES ('43', '20', '2018-01-28 01:59:55', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|31#10e3|55d|646|28#10e3|e8c4|654|22#10e3|d620|650|21#10e3|55b|653|21', '29', '2018-01-28 01:59:58');
INSERT INTO `hms_position` VALUES ('44', '20', '2018-01-28 02:04:55', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|30#10e3|55d|646|26#10e3|55b|653|25#10e3|e8c4|654|23#10e3|d620|650|18', '29', '2018-01-28 02:04:59');
INSERT INTO `hms_position` VALUES ('45', '20', '2018-01-28 02:19:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|31#10e3|e8d6|644|26#10e3|55b|653|26#10e3|55d|646|24#10e3|e8c4|654|22', '29', '2018-01-28 02:19:58');
INSERT INTO `hms_position` VALUES ('46', '20', '2018-01-28 02:29:55', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|31#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 02:29:58');
INSERT INTO `hms_position` VALUES ('47', '20', '2018-01-28 02:34:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|28#10e3|55b|653|25#10e3|e8c4|654|23#10e3|d620|650|18', '29', '2018-01-28 02:34:58');
INSERT INTO `hms_position` VALUES ('48', '20', '2018-01-28 02:44:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$1#10e3|e8c3|648|42#10e3|d622|639|32#10e3|55d|646|28#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 02:44:58');
INSERT INTO `hms_position` VALUES ('49', '20', '2018-01-28 02:49:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|32#10e3|55d|646|25#10e3|55b|653|23#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 02:50:00');
INSERT INTO `hms_position` VALUES ('50', '20', '2018-01-28 02:54:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|26#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|21', '29', '2018-01-28 02:54:58');
INSERT INTO `hms_position` VALUES ('51', '20', '2018-01-28 02:59:56', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|24#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 02:59:58');
INSERT INTO `hms_position` VALUES ('52', '20', '2018-01-28 03:09:57', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55b|653|24#10e3|55d|646|24#10e3|e8c4|654|22#10e3|d620|650|21', '29', '2018-01-28 03:10:00');
INSERT INTO `hms_position` VALUES ('53', '20', '2018-01-28 03:29:57', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|26#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 03:29:59');
INSERT INTO `hms_position` VALUES ('54', '20', '2018-01-28 03:34:57', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|28#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 03:34:59');
INSERT INTO `hms_position` VALUES ('55', '20', '2018-01-28 03:39:57', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|25#10e3|55b|653|23#10e3|e8c4|654|22#10e3|d620|650|22', '29', '2018-01-28 03:40:00');
INSERT INTO `hms_position` VALUES ('56', '20', '2018-01-28 03:54:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|20', '29', '2018-01-28 03:55:00');
INSERT INTO `hms_position` VALUES ('57', '20', '2018-01-28 03:59:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|32#10e3|55d|646|25#10e3|55b|653|25#10e3|e8c4|654|24#10e3|d620|650|20', '29', '2018-01-28 04:00:00');
INSERT INTO `hms_position` VALUES ('58', '20', '2018-01-28 04:04:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|30#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 04:05:00');
INSERT INTO `hms_position` VALUES ('59', '20', '2018-01-28 04:09:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|32#10e3|55d|646|31#10e3|e8d6|644|30#10e3|55b|653|25#10e3|e8c4|654|23', '29', '2018-01-28 04:10:00');
INSERT INTO `hms_position` VALUES ('60', '20', '2018-01-28 04:14:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|55d|646|31#10e3|d622|639|31#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 04:15:00');
INSERT INTO `hms_position` VALUES ('61', '20', '2018-01-28 04:19:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|31#10e3|55d|646|29#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|18', '29', '2018-01-28 04:20:01');
INSERT INTO `hms_position` VALUES ('62', '20', '2018-01-28 04:24:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|31#10e3|e8d6|644|30#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|23', '29', '2018-01-28 04:25:00');
INSERT INTO `hms_position` VALUES ('63', '20', '2018-01-28 04:29:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|31#10e3|55d|646|27#10e3|55b|653|25#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 04:30:00');
INSERT INTO `hms_position` VALUES ('64', '20', '2018-01-28 04:34:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|18', '29', '2018-01-28 04:35:00');
INSERT INTO `hms_position` VALUES ('65', '20', '2018-01-28 04:39:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|17', '29', '2018-01-28 04:40:00');
INSERT INTO `hms_position` VALUES ('66', '20', '2018-01-28 04:44:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|18', '29', '2018-01-28 04:45:00');
INSERT INTO `hms_position` VALUES ('67', '20', '2018-01-28 04:49:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|29#10e3|55b|653|23#10e3|e8c4|654|21#10e3|d620|650|17', '29', '2018-01-28 04:50:00');
INSERT INTO `hms_position` VALUES ('68', '20', '2018-01-28 04:54:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|18', '29', '2018-01-28 04:55:00');
INSERT INTO `hms_position` VALUES ('69', '20', '2018-01-28 04:59:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|17', '29', '2018-01-28 05:00:01');
INSERT INTO `hms_position` VALUES ('70', '20', '2018-01-28 05:04:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|33#10e3|55d|646|28#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 05:05:01');
INSERT INTO `hms_position` VALUES ('71', '20', '2018-01-28 05:09:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|d622|639|33#10e3|55d|646|28#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|19', '29', '2018-01-28 05:10:00');
INSERT INTO `hms_position` VALUES ('72', '20', '2018-01-28 05:14:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|30#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 05:15:01');
INSERT INTO `hms_position` VALUES ('73', '20', '2018-01-28 05:19:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|28#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|17', '29', '2018-01-28 05:20:01');
INSERT INTO `hms_position` VALUES ('74', '20', '2018-01-28 05:24:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|32#10e3|55d|646|28#10e3|55b|653|26#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 05:25:01');
INSERT INTO `hms_position` VALUES ('75', '20', '2018-01-28 05:29:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|29#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|21', '29', '2018-01-28 05:30:00');
INSERT INTO `hms_position` VALUES ('76', '20', '2018-01-28 05:34:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|31#10e3|55b|653|26#10e3|e8c4|654|22#10e3|d620|650|18', '29', '2018-01-28 05:35:01');
INSERT INTO `hms_position` VALUES ('77', '20', '2018-01-28 05:39:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|26#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 05:40:01');
INSERT INTO `hms_position` VALUES ('78', '20', '2018-01-28 05:44:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|28#10e3|55b|653|26#10e3|e8c4|654|21#10e3|d620|650|19', '29', '2018-01-28 05:45:00');
INSERT INTO `hms_position` VALUES ('79', '20', '2018-01-28 05:49:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|40#10e3|d622|639|31#10e3|55d|646|29#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 05:50:00');
INSERT INTO `hms_position` VALUES ('80', '20', '2018-01-28 05:54:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 05:55:00');
INSERT INTO `hms_position` VALUES ('81', '20', '2018-01-28 05:59:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|31#10e3|55d|646|31#10e3|55b|653|25#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 06:00:00');
INSERT INTO `hms_position` VALUES ('82', '20', '2018-01-28 06:04:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|55b|653|26#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 06:05:00');
INSERT INTO `hms_position` VALUES ('83', '20', '2018-01-28 06:09:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|30#10e3|e8c4|654|22#10e3|d620|650|22', '29', '2018-01-28 06:10:00');
INSERT INTO `hms_position` VALUES ('84', '20', '2018-01-28 06:14:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|31#10e3|55d|646|31#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 06:15:00');
INSERT INTO `hms_position` VALUES ('85', '20', '2018-01-28 06:19:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|41#10e3|55d|646|32#10e3|d622|639|31#10e3|e8c4|654|21#10e3|d620|650|19', '29', '2018-01-28 06:20:02');
INSERT INTO `hms_position` VALUES ('86', '20', '2018-01-28 06:24:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|31#10e3|55b|653|23#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 06:25:02');
INSERT INTO `hms_position` VALUES ('87', '20', '2018-01-28 06:29:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|30#10e3|55b|653|26#10e3|e8c4|654|23#10e3|d620|650|20', '29', '2018-01-28 06:30:02');
INSERT INTO `hms_position` VALUES ('88', '20', '2018-01-28 06:34:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|d622|639|32#10e3|55d|646|30#10e3|e8d6|644|28#10e3|55b|653|25#10e3|e8c4|654|23', '29', '2018-01-28 06:35:00');
INSERT INTO `hms_position` VALUES ('89', '20', '2018-01-28 06:39:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|33#10e3|55d|646|31#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|19', '29', '2018-01-28 06:40:00');
INSERT INTO `hms_position` VALUES ('90', '20', '2018-01-28 06:44:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|d622|639|33#10e3|55d|646|31#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|19', '29', '2018-01-28 06:45:00');
INSERT INTO `hms_position` VALUES ('91', '20', '2018-01-28 06:49:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|55d|646|33#10e3|d622|639|32#10e3|55b|653|24#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 06:50:00');
INSERT INTO `hms_position` VALUES ('92', '20', '2018-01-28 06:54:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|33#10e3|55d|646|32#10e3|55b|653|25#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 06:55:01');
INSERT INTO `hms_position` VALUES ('93', '20', '2018-01-28 07:00:39', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|38#10e3|55d|646|33#10e3|d622|639|32#10e3|55b|653|26#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 07:00:41');
INSERT INTO `hms_position` VALUES ('94', '20', '2018-01-28 07:10:38', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|d622|639|33#10e3|55d|646|32#10e3|55b|653|26#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 07:10:41');
INSERT INTO `hms_position` VALUES ('95', '20', '2018-01-28 07:24:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|35#10e3|d622|639|31#10e3|55b|653|22#10e3|e8c4|654|19#10e3|d620|650|18', '29', '2018-01-28 07:25:01');
INSERT INTO `hms_position` VALUES ('96', '20', '2018-01-28 07:40:39', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|34#10e3|d622|639|32#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|18', '29', '2018-01-28 07:40:41');
INSERT INTO `hms_position` VALUES ('97', '20', '2018-01-28 07:50:39', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|55d|646|34#10e3|d622|639|32#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 07:50:41');
INSERT INTO `hms_position` VALUES ('98', '20', '2018-01-28 08:14:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|32#10e3|d622|639|31#10e3|55b|653|22#10e3|e8c4|654|20#10e3|d620|650|19', '29', '2018-01-28 08:15:02');
INSERT INTO `hms_position` VALUES ('99', '20', '2018-01-28 08:19:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|55d|646|33#10e3|d622|639|31#10e3|55b|653|22#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 08:20:02');
INSERT INTO `hms_position` VALUES ('100', '20', '2018-01-28 08:24:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|55d|646|34#10e3|d622|639|31#10e3|55b|653|23#10e3|e8c4|654|21#10e3|d620|650|20', '29', '2018-01-28 08:25:02');
INSERT INTO `hms_position` VALUES ('101', '20', '2018-01-28 08:29:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|55d|646|33#10e3|d622|639|31#10e3|55b|653|24#10e3|e8c4|654|23#10e3|d620|650|21', '29', '2018-01-28 08:30:02');
INSERT INTO `hms_position` VALUES ('102', '20', '2018-01-28 08:34:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|40#10e3|55d|646|34#10e3|d622|639|32#10e3|55b|653|24#10e3|e8c4|654|22#10e3|d620|650|21', '29', '2018-01-28 08:35:01');
INSERT INTO `hms_position` VALUES ('103', '20', '2018-01-28 08:39:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|55d|646|33#10e3|d622|639|31#10e3|55b|653|23#10e3|e8c4|654|22#10e3|d620|650|22', '29', '2018-01-28 08:40:02');
INSERT INTO `hms_position` VALUES ('104', '20', '2018-01-28 08:55:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|34#10e3|d622|639|31#10e3|e8c4|654|23#10e3|55b|653|23#10e3|d620|650|22', '29', '2018-01-28 08:55:02');
INSERT INTO `hms_position` VALUES ('105', '20', '2018-01-28 09:00:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|34#10e3|d622|639|31#10e3|55b|653|23#10e3|e8c4|654|23#10e3|d620|650|19', '29', '2018-01-28 09:00:01');
INSERT INTO `hms_position` VALUES ('106', '20', '2018-01-28 09:05:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|35#10e3|d622|639|31#10e3|55b|653|23#10e3|e8c4|654|22#10e3|d620|650|20', '29', '2018-01-28 09:05:02');
INSERT INTO `hms_position` VALUES ('107', '20', '2018-01-28 09:10:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|33#10e3|d622|639|30#10e3|55b|653|23#10e3|e8c4|654|22#10e3|d620|650|19', '29', '2018-01-28 09:10:14');
INSERT INTO `hms_position` VALUES ('108', '20', '2018-01-28 09:15:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|28#10e3|e8c4|654|15#10e3|d622|639|14#10e3|d620|650|13#10e3|55b|653|12', '29', '2018-01-28 09:15:23');
INSERT INTO `hms_position` VALUES ('109', '20', '2018-01-28 09:20:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|29#10e3|d622|639|17#10e3|e8c4|654|17#10e3|55b|653|15#10e3|d620|650|14', '29', '2018-01-28 09:20:04');
INSERT INTO `hms_position` VALUES ('110', '20', '2018-01-28 09:25:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|29#10e3|d622|639|17#10e3|e8c4|654|17#10e3|d620|650|14#10e3|60f2|640|10', '29', '2018-01-28 09:25:09');
INSERT INTO `hms_position` VALUES ('111', '20', '2018-01-28 09:30:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|29#10e3|e8d6|644|21#10e3|d622|639|17#10e3|e8c4|654|16#10e3|d620|650|14', '29', '2018-01-28 09:31:05');
INSERT INTO `hms_position` VALUES ('112', '20', '2018-01-28 09:35:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|30#10e3|d622|639|17#10e3|e8c4|654|17#10e3|e976|649|16#10e3|d620|650|15', '29', '2018-01-28 09:35:30');
INSERT INTO `hms_position` VALUES ('113', '20', '2018-01-28 09:40:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$0#10e3|e8c3|648|34#10e3|55d|646|30#10e3|e8d6|644|22#10e3|e8c4|654|17', '29', '2018-01-28 09:40:09');
INSERT INTO `hms_position` VALUES ('114', '20', '2018-01-28 09:45:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|23#10e3|55d|646|16#10e3|e8d6|644|7#10e3|d622|639|6', '29', '2018-01-28 09:45:04');
INSERT INTO `hms_position` VALUES ('115', '20', '2018-01-28 09:50:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|33#10e3|55d|646|20#10e3|d622|639|12#10e3|e8c4|654|7', '29', '2018-01-28 09:50:03');
INSERT INTO `hms_position` VALUES ('116', '20', '2018-01-28 09:55:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|32#10e3|55d|646|16#10e3|d622|639|10#10e3|e8c4|654|7#10e3|d620|650|4', '29', '2018-01-28 09:55:09');
INSERT INTO `hms_position` VALUES ('117', '20', '2018-01-28 10:00:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|16#10e3|d622|639|10#10e3|e8c4|654|7#10e3|d620|650|4#10e3|60f2|640|4', '29', '2018-01-28 10:00:03');
INSERT INTO `hms_position` VALUES ('118', '20', '2018-01-28 10:05:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|33#10e3|55d|646|8#10e3|d622|639|5#10e3|55b|653|4', '29', '2018-01-28 10:05:09');
INSERT INTO `hms_position` VALUES ('119', '20', '2018-01-28 10:50:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|26#10e3|55d|646|15#10e3|e8c4|654|7', '29', '2018-01-28 10:50:03');
INSERT INTO `hms_position` VALUES ('120', '20', '2018-01-28 10:55:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|28#10e3|55d|646|22#10e3|55b|653|14#10e3|d620|650|12#10e3|d622|639|11#10e3|e8c4|654|7', '29', '2018-01-28 10:55:16');
INSERT INTO `hms_position` VALUES ('121', '20', '2018-01-28 11:00:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|21#10e3|d622|639|11#10e3|e8c4|654|8#10e3|d620|650|7#10e3|55d|646|5#10e3|60f2|640|3', '29', '2018-01-28 11:00:04');
INSERT INTO `hms_position` VALUES ('122', '20', '2018-01-28 11:05:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|25#10e3|d622|639|17#10e3|e8c4|654|11#10e3|d620|650|10#10e3|55b|653|8#10e3|55d|646|4', '29', '2018-01-28 11:05:04');
INSERT INTO `hms_position` VALUES ('123', '20', '2018-01-28 11:10:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|35#10e3|55d|646|26#10e3|e8c4|654|13#10e3|d622|639|12#10e3|55b|653|8#10e3|d620|650|5', '29', '2018-01-28 11:10:04');
INSERT INTO `hms_position` VALUES ('124', '20', '2018-01-28 11:15:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|21#10e3|d622|639|23#10e3|55d|646|16#10e3|d620|650|15#10e3|55b|653|11#10e3|e8c4|654|11', '29', '2018-01-28 11:15:05');
INSERT INTO `hms_position` VALUES ('125', '20', '2018-01-28 11:20:01', '116.324921', '40.078388', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|d622|639|22#10e3|e8c3|648|28#10e3|e8d6|644|22#10e3|55d|646|21#10e3|d620|650|16#10e3|55b|653|12', '29', '2018-01-28 11:20:12');
INSERT INTO `hms_position` VALUES ('126', '20', '2018-01-28 11:25:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|28#10e3|d622|639|16#10e3|d620|650|13#10e3|e8c4|654|12#10e3|55b|653|11', '29', '2018-01-28 11:25:04');
INSERT INTO `hms_position` VALUES ('127', '20', '2018-01-28 11:30:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|34#10e3|55d|646|29#10e3|55b|653|18#10e3|d620|650|15#10e3|e8c4|654|13#10e3|d622|639|7', '29', '2018-01-28 11:30:04');
INSERT INTO `hms_position` VALUES ('128', '20', '2018-01-28 11:35:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|30#10e3|55d|646|23#10e3|55b|653|15#10e3|e8c4|654|15#10e3|d620|650|10#10e3|2d1c|123|9', '29', '2018-01-28 11:35:04');
INSERT INTO `hms_position` VALUES ('129', '20', '2018-01-28 11:40:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|32#10e3|55d|646|16#10e3|d622|639|13#10e3|e8c4|654|9#10e3|55b|653|8#10e3|d620|650|6', '29', '2018-01-28 11:40:10');
INSERT INTO `hms_position` VALUES ('130', '20', '2018-01-28 11:45:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|30#10e3|55d|646|22#10e3|d620|650|15#10e3|55b|653|13#10e3|d622|639|9#10e1|580e|654|8', '29', '2018-01-28 11:45:04');
INSERT INTO `hms_position` VALUES ('131', '20', '2018-01-28 11:50:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|25#10e3|e8d6|644|24#10e3|d622|639|18#10e3|55d|646|15#10e3|d620|650|8#10e3|e8c4|654|7', '29', '2018-01-28 11:50:05');
INSERT INTO `hms_position` VALUES ('132', '20', '2018-01-28 11:55:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|34#10e3|55d|646|22#10e3|e8c4|654|17#10e3|55b|653|11#10e3|d620|650|11#10e3|d622|639|6', '29', '2018-01-28 11:55:04');
INSERT INTO `hms_position` VALUES ('133', '20', '2018-01-28 12:00:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|27#10e3|55d|646|19#10e3|e8c4|654|11#10e3|d622|639|9#10e3|d620|650|8', '29', '2018-01-28 12:00:05');
INSERT INTO `hms_position` VALUES ('134', '20', '2018-01-28 12:05:02', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|30#10e3|e8c3|648|30#10e3|55d|646|26#10e3|d622|639|19#10e3|e8d8|637|18#10e3|d620|650|16', '29', '2018-01-28 12:05:05');
INSERT INTO `hms_position` VALUES ('135', '20', '2018-01-28 12:10:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|26#10e3|55d|646|24#10e3|d622|639|10#10e3|e8c4|654|10#10e3|d620|650|5', '29', '2018-01-28 12:10:04');
INSERT INTO `hms_position` VALUES ('136', '20', '2018-01-28 12:15:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|16#10e3|55d|646|23#10e3|e8d6|644|18#10e3|d622|639|14#10e3|d620|650|11', '29', '2018-01-28 12:15:04');
INSERT INTO `hms_position` VALUES ('137', '20', '2018-01-28 12:20:02', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$5$460$1$255#10e3|55d|646|32#10e3|e8d6|644|12#10e3|55b|653|6#10e3|e8c3|648|5#10e3|d622|639|3', '29', '2018-01-28 12:20:04');
INSERT INTO `hms_position` VALUES ('138', '20', '2018-01-28 12:25:42', '116.324921', '40.078388', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|d622|639|37#10e3|e8d8|637|37#10e3|d621|653|36#10e3|e976|649|34#10e3|e8d6|644|32#10e3|55d|646|29', '29', '2018-01-28 12:25:44');
INSERT INTO `hms_position` VALUES ('139', '20', '2018-01-28 12:30:43', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$5$460$1$1#10e3|e8d8|637|40#10e3|d622|639|35#10e3|55d|646|32#10e3|288a|121|30#10e3|e977|651|29', '29', '2018-01-28 12:30:44');
INSERT INTO `hms_position` VALUES ('140', '20', '2018-01-28 12:35:42', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|39#10e3|55d|646|33#10e3|d622|639|27#10e3|e977|651|25#10e3|e8d6|644|19#10e3|288a|121|14', '29', '2018-01-28 12:35:45');
INSERT INTO `hms_position` VALUES ('141', '20', '2018-01-28 12:40:42', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|40#10e3|55d|646|35#10e3|d622|639|27#10e3|e977|651|25#10e3|e8d6|644|20#10e3|288a|121|19', '29', '2018-01-28 12:40:43');
INSERT INTO `hms_position` VALUES ('142', '20', '2018-01-28 12:45:42', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|45#10e3|55d|646|33#10e3|d622|639|33#10e3|d62b|651|27#10e3|288a|121|26#10c2|13b5|654|18', '29', '2018-01-28 12:45:44');
INSERT INTO `hms_position` VALUES ('143', '20', '2018-01-28 12:55:42', '116.332153', '40.079151', '北京市昌平区育知西路', 'mcount$6$460$1$255#10e3|e976|649|41#10e3|55c|637|28#10e3|55d|646|21#10e3|d622|639|21#10e3|e977|651|18#10e3|d621|653|17', '29', '2018-01-28 13:00:07');
INSERT INTO `hms_position` VALUES ('144', '20', '2018-01-28 12:55:42', '116.332153', '40.079151', '北京市昌平区育知西路', 'mcount$6$460$1$255#10e3|e976|649|41#10e3|55c|637|28#10e3|55d|646|21#10e3|d622|639|21#10e3|e977|651|18#10e3|d621|653|17', '29', '2018-01-28 13:00:41');
INSERT INTO `hms_position` VALUES ('145', '20', '2018-01-28 13:00:01', '116.332153', '40.079151', '北京市昌平区育知西路', 'mcount$6$460$1$255#10e3|e976|649|27#10e3|e8d8|637|27#10e3|d622|639|24#10e3|288a|121|21#10e3|55d|646|20#10e3|d621|653|17', '29', '2018-01-28 13:00:41');
INSERT INTO `hms_position` VALUES ('146', '20', '2018-01-28 13:15:03', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$5$460$1$255#10e3|55d|646|24#10e3|e8c3|648|16#10e3|e8d6|644|16#10e3|d622|639|8#10d5|2d06|99|4', '29', '2018-01-28 13:15:05');
INSERT INTO `hms_position` VALUES ('147', '20', '2018-01-28 13:20:02', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|23#10e3|e8c3|648|18#10e3|d622|639|14#10e3|55d|646|9#10e3|d620|650|5#10e3|e8d8|637|3', '29', '2018-01-28 13:20:31');
INSERT INTO `hms_position` VALUES ('148', '20', '2018-01-28 13:25:02', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$4$460$1$2#10e3|e8d6|644|14#10e3|d622|639|10#10e3|55d|646|6#10e3|d620|650|3', '29', '2018-01-28 13:25:31');
INSERT INTO `hms_position` VALUES ('149', '20', '2018-01-28 13:35:02', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|26#10e3|e8c3|648|26#10e3|e8d8|637|12#10e3|d620|650|12#10e3|e8c4|654|10#10e3|55d|646|9', '29', '2018-01-28 13:35:40');
INSERT INTO `hms_position` VALUES ('150', '20', '2018-01-28 13:40:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|23#10e3|55d|646|16#10e3|d622|639|9#10e3|e8c4|654|7#10d5|9ea8|641|3', '29', '2018-01-28 13:40:04');
INSERT INTO `hms_position` VALUES ('151', '20', '2018-01-28 13:45:03', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|21#10e3|e8c3|648|27#10e3|55d|646|17#10e3|d622|639|16#10e3|e8d8|637|11#10e3|e8c4|654|8', '29', '2018-01-28 13:45:04');
INSERT INTO `hms_position` VALUES ('152', '20', '2018-01-28 13:50:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|26#10e3|55d|646|21#10e3|d622|639|6', '29', '2018-01-28 13:50:05');
INSERT INTO `hms_position` VALUES ('153', '20', '2018-01-28 13:55:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|21#10e3|55d|646|17#10e3|e976|649|6#10e3|d622|639|5#10e3|d620|650|4', '29', '2018-01-28 13:55:05');
INSERT INTO `hms_position` VALUES ('154', '20', '2018-01-28 14:00:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|20#10e3|55d|646|18#10e3|e8c4|654|7#10e3|d620|650|7#10e3|d622|639|6#10e3|e976|649|5', '29', '2018-01-28 14:00:06');
INSERT INTO `hms_position` VALUES ('155', '20', '2018-01-28 14:05:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|26#10e3|55d|646|21#10e3|d622|639|14#10e3|e976|649|11', '29', '2018-01-28 14:05:05');
INSERT INTO `hms_position` VALUES ('156', '20', '2018-01-28 14:10:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|20#10e3|55d|646|18#10e3|d622|639|15#10e3|d620|650|8#10e3|e976|649|5#10d5|2d07|122|3', '29', '2018-01-28 14:10:06');
INSERT INTO `hms_position` VALUES ('157', '20', '2018-01-28 14:15:04', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|33#10e3|d622|639|21#10e3|55d|646|17#10e3|d620|650|14#10e3|e8c4|654|14', '29', '2018-01-28 14:15:06');
INSERT INTO `hms_position` VALUES ('158', '20', '2018-01-28 14:20:04', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|21#10e3|55d|646|25#10e3|e8c3|648|23#10e3|d622|639|10#10e3|d620|650|8#10d5|2d07|122|7', '29', '2018-01-28 14:20:09');
INSERT INTO `hms_position` VALUES ('159', '20', '2018-01-28 14:25:04', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|29#10e3|e8c3|648|27#10e3|55d|646|26#10e3|e8d8|637|17#10e3|d620|650|15#10e3|e8c4|654|15', '29', '2018-01-28 14:25:06');
INSERT INTO `hms_position` VALUES ('160', '20', '2018-01-28 14:35:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|26#10e3|e8d6|644|14#10e3|e976|649|11#10e3|55d|646|9#10e3|e8c4|654|9', '29', '2018-01-28 14:35:07');
INSERT INTO `hms_position` VALUES ('161', '20', '2018-01-28 14:40:05', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$5$460$1$255#10e3|e8d6|644|19#10e3|e8c3|648|24#10e3|55d|646|19#10e3|e8c4|654|8#10e3|d622|639|7', '29', '2018-01-28 14:40:09');
INSERT INTO `hms_position` VALUES ('162', '20', '2018-01-28 14:45:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|34#10e3|55d|646|23#10e3|e8c4|654|10#10e3|d620|650|9#10e3|d622|639|7', '29', '2018-01-28 14:45:07');
INSERT INTO `hms_position` VALUES ('163', '20', '2018-01-28 14:50:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|24#10e3|d622|639|12#10e3|e976|649|9#10e3|55d|646|8#10e3|e8c4|654|4#10e3|55b|653|4', '29', '2018-01-28 14:50:13');
INSERT INTO `hms_position` VALUES ('164', '20', '2018-01-28 14:55:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|28#10e3|e8c4|654|18#10e3|d620|650|15#10e3|d622|639|12#10e3|60f2|640|10', '29', '2018-01-28 14:55:07');
INSERT INTO `hms_position` VALUES ('165', '20', '2018-01-28 15:00:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|35#10e3|55d|646|21#10e3|d622|639|11#10e3|55b|653|10#10e3|e8c4|654|10#10e3|d620|650|6', '29', '2018-01-28 15:00:07');
INSERT INTO `hms_position` VALUES ('166', '20', '2018-01-28 15:05:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|17#10e3|e8c4|654|13#10e3|d622|639|12#10e3|55b|653|5#10e3|d620|650|4', '29', '2018-01-28 15:05:07');
INSERT INTO `hms_position` VALUES ('167', '20', '2018-01-28 15:10:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|30#10e3|55d|646|17#10e3|e8c4|654|14#10e3|d622|639|12#10e3|55b|653|9#10e3|d620|650|2', '29', '2018-01-28 15:10:07');
INSERT INTO `hms_position` VALUES ('168', '20', '2018-01-28 15:15:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|24#10e3|55b|653|9#10e3|e8c4|654|8#10e3|2d1c|123|7#10e3|d620|650|4', '29', '2018-01-28 15:15:08');
INSERT INTO `hms_position` VALUES ('169', '20', '2018-01-28 15:20:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|22#10e3|55b|653|13#10e3|d620|650|12#10e3|d622|639|11#10e3|e8c4|654|10', '29', '2018-01-28 15:20:08');
INSERT INTO `hms_position` VALUES ('170', '20', '2018-01-28 15:25:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|31#10e3|d622|639|14#10e3|55d|646|12#10e3|55b|653|10#10e3|e8c4|654|8#10e3|d620|650|7', '29', '2018-01-28 15:25:07');
INSERT INTO `hms_position` VALUES ('171', '20', '2018-01-28 15:30:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|29#10e3|55d|646|22#10e3|55b|653|9', '29', '2018-01-28 15:30:08');
INSERT INTO `hms_position` VALUES ('172', '20', '2018-01-28 15:35:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|29#10e3|55d|646|21#10e3|e8d6|644|16#10e3|55b|653|11#10e3|e8c4|654|4#10e3|d620|650|3', '29', '2018-01-28 15:35:06');
INSERT INTO `hms_position` VALUES ('173', '20', '2018-01-28 15:40:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|31#10e3|e8d6|644|16#10e3|55d|646|11#10e3|e8c4|654|7#10e3|d622|639|4', '29', '2018-01-28 15:40:19');
INSERT INTO `hms_position` VALUES ('174', '20', '2018-01-28 15:45:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|35#10e3|55d|646|20#10e3|e8c4|654|11#10e3|55b|653|9#10e3|d622|639|9', '29', '2018-01-28 15:45:19');
INSERT INTO `hms_position` VALUES ('175', '20', '2018-01-28 15:50:05', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|34#10e3|55d|646|20#10e3|e8c4|654|10#10e3|d622|639|7', '29', '2018-01-28 15:50:09');
INSERT INTO `hms_position` VALUES ('176', '20', '2018-01-28 15:55:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|32#10e3|55d|646|20#10e3|d622|639|9#10e3|e8c4|654|5', '29', '2018-01-28 15:55:07');
INSERT INTO `hms_position` VALUES ('177', '20', '2018-01-28 16:00:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|32#10e3|55d|646|20#10e3|e8c4|654|8', '29', '2018-01-28 16:00:07');
INSERT INTO `hms_position` VALUES ('178', '20', '2018-01-28 16:05:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|32#10e3|55d|646|20#10e3|e8c4|654|6', '29', '2018-01-28 16:05:07');
INSERT INTO `hms_position` VALUES ('179', '20', '2018-01-28 16:10:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|31#10e3|55d|646|19#10e3|e8d6|644|14#10e3|e8c4|654|7#10e3|d622|639|5', '29', '2018-01-28 16:10:09');
INSERT INTO `hms_position` VALUES ('180', '20', '2018-01-28 16:15:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|31#10e3|55d|646|17#10e3|e8d6|644|14#10e3|d622|639|6#10e3|e8c4|654|6', '29', '2018-01-28 16:15:14');
INSERT INTO `hms_position` VALUES ('181', '20', '2018-01-28 16:20:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|31#10e3|55d|646|17#10e3|e8c4|654|6', '29', '2018-01-28 16:20:07');
INSERT INTO `hms_position` VALUES ('182', '20', '2018-01-28 16:25:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|31#10e3|55d|646|18#10e3|d622|639|8#10e3|e8c4|654|6', '29', '2018-01-28 16:25:07');
INSERT INTO `hms_position` VALUES ('183', '20', '2018-01-28 16:30:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|31#10e3|55d|646|20#10e3|d622|639|8#10e3|e8c4|654|6', '29', '2018-01-28 16:30:20');
INSERT INTO `hms_position` VALUES ('184', '20', '2018-01-28 16:35:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|37#10e3|55d|646|23#10e3|e8c4|654|15', '29', '2018-01-28 16:35:08');
INSERT INTO `hms_position` VALUES ('185', '20', '2018-01-28 16:40:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|37#10e3|55d|646|22#10e3|e8c4|654|16#10e3|55b|653|9#10e3|d620|650|7', '29', '2018-01-28 16:40:08');
INSERT INTO `hms_position` VALUES ('186', '20', '2018-01-28 16:45:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|37#10e3|55d|646|22#10e3|e8c4|654|16#10e3|d620|650|8#10e3|55b|653|7', '29', '2018-01-28 16:45:09');
INSERT INTO `hms_position` VALUES ('187', '20', '2018-01-28 16:50:06', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|37#10e3|55d|646|22#10e3|e8c4|654|17#10e3|55b|653|9#10e3|d620|650|7', '29', '2018-01-28 16:50:08');
INSERT INTO `hms_position` VALUES ('188', '20', '2018-01-28 16:55:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|24#10e3|e8c4|654|22#10e3|d620|650|13#10e3|55b|653|13#10e3|d622|639|9', '29', '2018-01-28 16:55:08');
INSERT INTO `hms_position` VALUES ('189', '20', '2018-01-28 17:00:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|e8c4|654|22#10e3|55d|646|21#10e3|e8d6|644|19#10e3|55b|653|13#10e3|d620|650|13', '29', '2018-01-28 17:00:09');
INSERT INTO `hms_position` VALUES ('190', '20', '2018-01-28 17:05:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|22#10e3|e8c4|654|21#10e3|55b|653|13#10e3|d620|650|13#10e3|2d1c|123|9', '29', '2018-01-28 17:05:09');
INSERT INTO `hms_position` VALUES ('191', '20', '2018-01-28 17:10:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|28#10e3|e8c4|654|20#10e3|d620|650|15#10e3|55b|653|10#10e3|2d1c|123|4', '29', '2018-01-28 17:10:08');
INSERT INTO `hms_position` VALUES ('192', '20', '2018-01-28 17:15:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|e8c4|654|21#10e3|55d|646|18#10e3|d620|650|9#10e3|d622|639|8#10e3|2d1c|123|5', '29', '2018-01-28 17:15:10');
INSERT INTO `hms_position` VALUES ('193', '20', '2018-01-28 17:20:08', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$5$460$1$255#10e3|55d|646|27#10e3|e8c3|648|27#10e3|e8d6|644|17#10e3|55b|653|11#10e3|e8d8|637|5', '29', '2018-01-28 17:20:10');
INSERT INTO `hms_position` VALUES ('194', '20', '2018-01-28 17:25:07', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|31#10e3|55d|646|25#10e3|e8d6|644|20#10e3|e8c4|654|15#10e3|55b|653|13#10e3|d620|650|9', '29', '2018-01-28 17:25:09');
INSERT INTO `hms_position` VALUES ('195', '20', '2018-01-28 17:30:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|24#10e3|55d|646|19#10e3|d620|650|14#10e3|55b|653|11#10e3|e8d6|644|10#10e3|e8c4|654|5', '29', '2018-01-28 17:30:09');
INSERT INTO `hms_position` VALUES ('196', '20', '2018-01-28 17:35:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$5$460$1$255#10e3|e8c3|648|28#10e3|55d|646|18#10e3|d620|650|12#10e3|55b|653|6#10e3|e8c4|654|5', '29', '2018-01-28 17:35:10');
INSERT INTO `hms_position` VALUES ('197', '20', '2018-01-28 17:40:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$3$460$1$255#10e3|e8c3|648|27#10e3|d620|650|9#10e3|55b|653|5', '29', '2018-01-28 17:40:10');
INSERT INTO `hms_position` VALUES ('198', '20', '2018-01-28 17:45:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|37#10e3|55d|646|24#10e3|e8c4|654|15#10e3|d622|639|14#10e3|55b|653|12#10e3|d620|650|11', '29', '2018-01-28 17:45:10');
INSERT INTO `hms_position` VALUES ('199', '20', '2018-01-28 17:50:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|23#10e3|d620|650|19#10e3|e8c4|654|17#10e3|55b|653|12#10e3|60f2|640|11', '29', '2018-01-28 17:50:17');
INSERT INTO `hms_position` VALUES ('200', '20', '2018-01-28 17:55:08', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|18#10e3|e8d8|637|13#10e3|d622|639|13#10e3|e8c3|648|13#10e3|55d|646|12#10e3|d620|650|10', '29', '2018-01-28 17:55:11');
INSERT INTO `hms_position` VALUES ('201', '20', '2018-01-28 18:00:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|27#10e3|55d|646|20#10e3|d620|650|6#10e3|d622|639|5', '29', '2018-01-28 18:00:10');
INSERT INTO `hms_position` VALUES ('202', '20', '2018-01-28 18:05:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$4$460$1$255#10e3|e8c3|648|27#10e3|55d|646|19#10e3|e8c4|654|7#10e3|d620|650|7', '29', '2018-01-28 18:05:10');
INSERT INTO `hms_position` VALUES ('203', '20', '2018-01-28 18:10:08', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|31#10e3|55d|646|21#10e3|e976|649|14#10e3|d622|639|13#10e3|d620|650|9#10e3|e8c4|654|7', '29', '2018-01-28 18:10:11');
INSERT INTO `hms_position` VALUES ('204', '20', '2018-01-28 18:20:09', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|26#10e3|e8c3|648|18#10e3|55d|646|13#10e3|e8d8|637|11#10e3|d622|639|8#10e3|e8c4|654|5', '29', '2018-01-28 18:22:13');
INSERT INTO `hms_position` VALUES ('205', '20', '2018-01-28 18:25:09', '116.327202', '40.083065', '北京市昌平区回龙观西大街辅路', 'mcount$6$460$1$255#10e3|e8d6|644|22#10e3|e8c3|648|18#10e3|55d|646|18#10e3|d622|639|14#10e3|e8d8|637|12#10e3|d620|650|8', '29', '2018-01-28 18:25:10');
INSERT INTO `hms_position` VALUES ('206', '20', '2018-01-28 18:30:09', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|23#10e3|55d|646|21#10e3|e8d6|644|19#10e3|e8c4|654|10#10e3|d620|650|8#10e3|d622|639|4', '29', '2018-01-28 18:30:12');
INSERT INTO `hms_position` VALUES ('207', '20', '2018-01-29 00:22:52', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|33#10e3|55d|646|24#10e3|e8d6|644|23#10e3|d620|650|19#10e3|d622|639|15#10e3|e8c4|654|15', '29', '2018-01-29 00:22:53');
INSERT INTO `hms_position` VALUES ('208', '20', '2018-01-29 00:25:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|25#10e3|d622|639|24#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 00:26:00');
INSERT INTO `hms_position` VALUES ('209', '20', '2018-01-29 00:30:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|25#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 00:31:00');
INSERT INTO `hms_position` VALUES ('210', '20', '2018-01-29 00:35:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|32#10e3|d620|650|25#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|18', '29', '2018-01-29 00:36:00');
INSERT INTO `hms_position` VALUES ('211', '20', '2018-01-29 00:40:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|18', '29', '2018-01-29 00:41:00');
INSERT INTO `hms_position` VALUES ('212', '20', '2018-01-29 00:45:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|22#10d5|2d07|122|18#10e3|55b|653|18', '29', '2018-01-29 00:46:00');
INSERT INTO `hms_position` VALUES ('213', '20', '2018-01-29 00:50:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|33#10e3|d620|650|25#10e3|d622|639|24#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 00:51:00');
INSERT INTO `hms_position` VALUES ('214', '20', '2018-01-29 00:55:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|33#10e3|d620|650|25#10e3|d622|639|23#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 00:56:02');
INSERT INTO `hms_position` VALUES ('215', '20', '2018-01-29 01:00:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|25#10e3|d622|639|22#10d5|2d07|122|19#10e1|580e|654|16', '29', '2018-01-29 01:01:00');
INSERT INTO `hms_position` VALUES ('216', '20', '2018-01-29 01:05:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|34#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|20#10e3|9e62|645|19', '29', '2018-01-29 01:06:00');
INSERT INTO `hms_position` VALUES ('217', '20', '2018-01-29 01:10:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|33#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|19#10e3|9e62|645|19', '29', '2018-01-29 01:11:00');
INSERT INTO `hms_position` VALUES ('218', '20', '2018-01-29 01:15:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|19#10e3|9e62|645|18', '29', '2018-01-29 01:16:00');
INSERT INTO `hms_position` VALUES ('219', '20', '2018-01-29 01:20:58', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|19#10e3|9e62|645|18', '29', '2018-01-29 01:21:00');
INSERT INTO `hms_position` VALUES ('220', '20', '2018-01-29 01:25:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|24#10e3|9e62|645|19#10e3|55b|653|19', '29', '2018-01-29 01:26:01');
INSERT INTO `hms_position` VALUES ('221', '20', '2018-01-29 01:30:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|32#10e3|d620|650|25#10e3|d622|639|23#10e3|9e62|645|19#10d5|2d07|122|18', '29', '2018-01-29 01:31:02');
INSERT INTO `hms_position` VALUES ('222', '20', '2018-01-29 01:35:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 01:36:01');
INSERT INTO `hms_position` VALUES ('223', '20', '2018-01-29 01:40:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|31#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 01:41:01');
INSERT INTO `hms_position` VALUES ('224', '20', '2018-01-29 01:46:39', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|32#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 01:46:42');
INSERT INTO `hms_position` VALUES ('225', '20', '2018-01-29 01:50:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|33#10e3|d620|650|25#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|19', '29', '2018-01-29 01:51:01');
INSERT INTO `hms_position` VALUES ('226', '20', '2018-01-29 01:55:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 01:56:01');
INSERT INTO `hms_position` VALUES ('227', '20', '2018-01-29 02:00:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|26#10e3|d622|639|23#10d5|2d07|122|19#10e3|9e62|645|18', '29', '2018-01-29 02:01:01');
INSERT INTO `hms_position` VALUES ('228', '20', '2018-01-29 02:05:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|30#10e3|d620|650|27#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 02:06:02');
INSERT INTO `hms_position` VALUES ('229', '20', '2018-01-29 02:10:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|27#10e3|d622|639|23#10e3|d621|653|19#10e3|9e62|645|18', '29', '2018-01-29 02:11:02');
INSERT INTO `hms_position` VALUES ('230', '20', '2018-01-29 02:15:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|31#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 02:16:01');
INSERT INTO `hms_position` VALUES ('231', '20', '2018-01-29 02:35:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|25#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|18', '29', '2018-01-29 02:36:01');
INSERT INTO `hms_position` VALUES ('232', '20', '2018-01-29 02:40:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|33#10e3|d620|650|26#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|19', '29', '2018-01-29 02:41:01');
INSERT INTO `hms_position` VALUES ('233', '20', '2018-01-29 02:45:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|29#10e3|d620|650|25#10e3|d622|639|23#10e3|55b|653|20#10d5|2d07|122|19', '29', '2018-01-29 02:46:01');
INSERT INTO `hms_position` VALUES ('234', '20', '2018-01-29 02:50:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|27#10e3|d620|650|26#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 02:51:01');
INSERT INTO `hms_position` VALUES ('235', '20', '2018-01-29 02:55:59', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|30#10e3|d620|650|25#10e3|d622|639|21#10d5|2d07|122|19#10e3|55b|653|18', '29', '2018-01-29 02:56:01');
INSERT INTO `hms_position` VALUES ('236', '20', '2018-01-29 03:31:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|33#10e3|d620|650|25#10e3|55b|653|21#10e3|d622|639|19#10d5|2d07|122|19', '29', '2018-01-29 03:31:02');
INSERT INTO `hms_position` VALUES ('237', '20', '2018-01-29 03:36:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|31#10e3|d620|650|25#10e3|d622|639|22#10e3|55b|653|21#10d5|2d07|122|18', '29', '2018-01-29 03:36:03');
INSERT INTO `hms_position` VALUES ('238', '20', '2018-01-29 04:01:00', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|29#10e3|d620|650|26#10e3|d622|639|22#10d5|2d07|122|19#10e3|d621|653|19', '29', '2018-01-29 04:01:02');
INSERT INTO `hms_position` VALUES ('239', '20', '2018-01-29 04:31:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|29#10e3|d620|650|25#10e3|d622|639|22#10e3|55b|653|19#10d5|2d07|122|19', '29', '2018-01-29 04:31:02');
INSERT INTO `hms_position` VALUES ('240', '20', '2018-01-29 04:41:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|30#10e3|d620|650|26#10e3|d622|639|22#10d5|2d07|122|19#10e3|55b|653|18', '29', '2018-01-29 04:41:03');
INSERT INTO `hms_position` VALUES ('241', '20', '2018-01-29 05:11:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|30#10e3|d620|650|25#10e3|d622|639|22#10d5|2d07|122|20#10e3|55b|653|18', '29', '2018-01-29 05:11:03');
INSERT INTO `hms_position` VALUES ('242', '20', '2018-01-29 05:16:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|27#10e3|e8c4|654|20#10e3|d620|650|19#10e3|55b|653|18', '29', '2018-01-29 05:16:03');
INSERT INTO `hms_position` VALUES ('243', '20', '2018-01-29 05:21:01', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|26#10e3|d620|650|22#10e3|55b|653|20#10e3|e8c4|654|20', '29', '2018-01-29 05:21:03');
INSERT INTO `hms_position` VALUES ('244', '20', '2018-01-29 05:31:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|47#10e3|55d|646|39#10e3|d622|639|26#10e3|e8c4|654|20#10e3|d620|650|20#10e3|55b|653|18', '29', '2018-01-29 05:31:03');
INSERT INTO `hms_position` VALUES ('245', '20', '2018-01-29 05:36:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|26#10e3|d620|650|20#10e3|e8c4|654|20#10e3|55b|653|18', '29', '2018-01-29 05:36:03');
INSERT INTO `hms_position` VALUES ('246', '20', '2018-01-29 05:41:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|21#10e3|55b|653|20#10e3|e8c4|654|19', '29', '2018-01-29 05:41:03');
INSERT INTO `hms_position` VALUES ('247', '20', '2018-01-29 05:46:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|39#10e3|d622|639|26#10e3|d620|650|22#10e3|e8c4|654|19#10d5|2d07|122|17', '29', '2018-01-29 05:46:03');
INSERT INTO `hms_position` VALUES ('248', '20', '2018-01-29 05:51:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|26#10e3|d620|650|21#10e3|e8c4|654|19#10e3|55b|653|19', '29', '2018-01-29 05:51:04');
INSERT INTO `hms_position` VALUES ('249', '20', '2018-01-29 05:56:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|21#10e3|55b|653|19#10e3|e8c4|654|19', '29', '2018-01-29 05:56:04');
INSERT INTO `hms_position` VALUES ('250', '20', '2018-01-29 06:01:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|26#10e3|d620|650|21#10e3|e8c4|654|20#10e3|55b|653|19', '29', '2018-01-29 06:01:03');
INSERT INTO `hms_position` VALUES ('251', '20', '2018-01-29 06:06:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|46#10e3|55d|646|38#10e3|d622|639|26#10e3|d620|650|20#10e3|e8c4|654|19#10e3|55b|653|18', '29', '2018-01-29 06:06:03');
INSERT INTO `hms_position` VALUES ('252', '20', '2018-01-29 06:11:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|23#10e3|55b|653|19#10e3|e8c4|654|19', '29', '2018-01-29 06:11:03');
INSERT INTO `hms_position` VALUES ('253', '20', '2018-01-29 06:16:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|25#10e3|55b|653|19#10e3|e8c4|654|18', '29', '2018-01-29 06:16:03');
INSERT INTO `hms_position` VALUES ('254', '20', '2018-01-29 06:21:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|25#10e3|e8c4|654|20#10e3|55b|653|18', '29', '2018-01-29 06:21:04');
INSERT INTO `hms_position` VALUES ('255', '20', '2018-01-29 06:26:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|25#10e3|e8c4|654|19#10e3|55b|653|18', '29', '2018-01-29 06:26:03');
INSERT INTO `hms_position` VALUES ('256', '20', '2018-01-29 06:31:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|45#10e3|55d|646|38#10e3|d622|639|27#10e3|d620|650|24#10e3|55b|653|19#10d5|2d07|122|18', '29', '2018-01-29 06:31:04');
INSERT INTO `hms_position` VALUES ('257', '20', '2018-01-29 06:36:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|37#10e3|d622|639|26#10e3|d620|650|25#10e3|55b|653|18#10e3|e8c4|654|18', '29', '2018-01-29 06:36:04');
INSERT INTO `hms_position` VALUES ('258', '20', '2018-01-29 06:41:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|24#10e3|e8c4|654|19#10d5|2d07|122|16', '29', '2018-01-29 06:41:05');
INSERT INTO `hms_position` VALUES ('259', '20', '2018-01-29 06:46:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|24#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 06:46:08');
INSERT INTO `hms_position` VALUES ('260', '20', '2018-01-29 06:51:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|24#10e3|e8c4|654|18#10d5|2d07|122|16', '29', '2018-01-29 06:51:21');
INSERT INTO `hms_position` VALUES ('261', '20', '2018-01-29 06:56:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$1#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|24#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 06:56:26');
INSERT INTO `hms_position` VALUES ('262', '20', '2018-01-29 07:01:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|38#10e3|d622|639|25#10e3|d620|650|23#10e3|55b|653|17#10e3|e8c4|654|17', '29', '2018-01-29 07:02:04');
INSERT INTO `hms_position` VALUES ('263', '20', '2018-01-29 07:06:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|23#10e3|e8d6|644|19#10e3|e8c4|654|18', '29', '2018-01-29 07:06:04');
INSERT INTO `hms_position` VALUES ('264', '20', '2018-01-29 07:11:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 07:11:03');
INSERT INTO `hms_position` VALUES ('265', '20', '2018-01-29 07:16:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10d5|2d07|122|16', '29', '2018-01-29 07:16:11');
INSERT INTO `hms_position` VALUES ('266', '20', '2018-01-29 07:21:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 07:21:05');
INSERT INTO `hms_position` VALUES ('267', '20', '2018-01-29 07:26:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 07:26:04');
INSERT INTO `hms_position` VALUES ('268', '20', '2018-01-29 07:31:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 07:31:04');
INSERT INTO `hms_position` VALUES ('269', '20', '2018-01-29 07:36:02', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10d5|2d07|122|16', '29', '2018-01-29 07:36:04');
INSERT INTO `hms_position` VALUES ('270', '20', '2018-01-29 07:41:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|18#10d5|2d07|122|16', '29', '2018-01-29 07:41:04');
INSERT INTO `hms_position` VALUES ('271', '20', '2018-01-29 07:46:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|19#10e3|55b|653|17', '29', '2018-01-29 07:46:04');
INSERT INTO `hms_position` VALUES ('272', '20', '2018-01-29 07:51:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|24#10e3|d620|650|22#10e3|e8c4|654|18#10e3|55b|653|16', '29', '2018-01-29 07:51:04');
INSERT INTO `hms_position` VALUES ('273', '20', '2018-01-29 07:56:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|44#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|22#10e3|55b|653|18#10e3|e8c4|654|17', '29', '2018-01-29 07:56:04');
INSERT INTO `hms_position` VALUES ('274', '20', '2018-01-29 08:01:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|36#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|17#10e3|55b|653|17', '29', '2018-01-29 08:01:05');
INSERT INTO `hms_position` VALUES ('275', '20', '2018-01-29 08:06:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|42#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|18#10d5|2d07|122|16', '29', '2018-01-29 08:06:05');
INSERT INTO `hms_position` VALUES ('276', '20', '2018-01-29 08:11:43', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|37#10e3|d622|639|25#10e3|d620|650|22#10e3|55b|653|17#10d5|2d07|122|16', '29', '2018-01-29 08:11:45');
INSERT INTO `hms_position` VALUES ('277', '20', '2018-01-29 08:16:04', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|43#10e3|55d|646|39#10e3|d622|639|25#10e3|d620|650|22#10e3|e8c4|654|18#10e3|55b|653|17', '29', '2018-01-29 08:16:05');
INSERT INTO `hms_position` VALUES ('278', '20', '2018-01-29 08:21:43', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|41#10e3|55d|646|39#10e3|d620|650|23#10e3|d622|639|23#10e3|55b|653|15#10e3|e8c4|654|15', '29', '2018-01-29 08:21:48');
INSERT INTO `hms_position` VALUES ('279', '20', '2018-01-29 08:26:03', '116.331528', '40.086571', '北京市昌平区龙禧三街', 'mcount$6$460$1$255#10e3|e8c3|648|39#10e3|55d|646|40#10e3|d622|639|24#10e3|d620|650|24#10e3|e8c4|654|19#10d5|2d07|122|16', '29', '2018-01-29 08:26:12');
INSERT INTO `hms_position` VALUES ('280', '20', '2018-01-29 08:31:03', '116.330757', '40.083015', '北京市昌平区回龙观西大街95号', 'mcount$6$460$1$255#10e3|55d|646|38#10e3|e8c3|648|28#10e3|e8d6|644|21#10e3|5a47|652|21#10e3|5a48|642|17#10e3|d622|639|17', '29', '2018-01-29 08:31:05');
INSERT INTO `hms_position` VALUES ('281', '20', '2018-01-29 08:36:04', '116.324921', '40.078388', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|d622|639|31#10e3|e976|649|31#10e3|e8d8|637|28#10e3|d621|653|26#10e3|55d|646|21#10e3|d620|650|20', '29', '2018-01-29 08:36:06');
INSERT INTO `hms_position` VALUES ('282', '20', '2018-01-29 08:41:04', '116.343102', '40.079201', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|6372|637|48#10d5|5c54|664|45#10e3|d80b|648|33#10e3|6370|653|26#10e3|2888|99|26#10e3|6371|640|26', '29', '2018-01-29 08:41:05');
INSERT INTO `hms_position` VALUES ('283', '20', '2018-01-29 08:46:04', '116.356522', '40.079624', '北京市昌平区文华东路27', 'mcount$6$460$1$255#10e3|d617|654|37#10e3|9e63|642|31#10e3|cdcf|121|30#10e3|6370|653|25#10e3|9e64|649|24#10e3|6371|640|23', '29', '2018-01-29 08:46:07');
INSERT INTO `hms_position` VALUES ('284', '20', '2018-01-29 08:51:04', '116.357636', '40.073349', '北京市昌平区黄平路5号', 'mcount$6$460$1$1#10d6|5855|644|28#10d6|9f03|657|17#10d6|9f48|649|17#10d5|5c55|639|16#10d6|5854|654|13#10d6|5853|666|8', '29', '2018-01-29 08:51:09');
INSERT INTO `hms_position` VALUES ('285', '20', '2018-01-29 08:56:04', '116.353737', '40.073185', '北京市昌平区文华路', 'mcount$6$460$1$255#10d6|9f03|657|44#10e3|6371|640|42#10e3|d7bb|642|38#10d6|9f04|646|30#10e3|d620|650|28#10e3|e8d8|637|28', '29', '2018-01-29 08:56:05');
INSERT INTO `hms_position` VALUES ('286', '20', '2018-01-29 09:01:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|53#10d5|5c55|639|47#10e3|d7bb|642|46#10e3|e8d8|637|46#10e3|2d1b|121|44#10d5|2d07|122|43', '29', '2018-01-29 09:01:05');
INSERT INTO `hms_position` VALUES ('287', '20', '2018-01-29 09:06:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|54#10e3|e8d8|637|47#10e3|2d1b|121|46#10e3|d7bb|642|45#10d5|5c55|639|45#10d6|9f04|646|45', '29', '2018-01-29 09:06:05');
INSERT INTO `hms_position` VALUES ('288', '20', '2018-01-29 09:11:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|54#10e3|e8d8|637|47#10e3|d7bb|642|45#10d5|5c55|639|42#10d6|9f04|646|41#10d5|5c54|664|40', '29', '2018-01-29 09:11:06');
INSERT INTO `hms_position` VALUES ('289', '20', '2018-01-29 09:16:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|53#10e3|2889|123|49#10e3|d7bb|642|46#10e3|e8d8|637|46#10d6|9f04|646|45#10e3|d620|650|43', '29', '2018-01-29 09:16:05');
INSERT INTO `hms_position` VALUES ('290', '20', '2018-01-29 09:21:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|54#10e3|2889|123|51#10d6|9f04|646|48#10e3|d7bb|642|48#10e3|e8d8|637|46#10d5|5c55|639|44', '29', '2018-01-29 09:21:05');
INSERT INTO `hms_position` VALUES ('291', '20', '2018-01-29 09:26:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|d7bb|642|34#10d6|9f04|646|30#10e3|9dcd|664|29#10e3|e8d8|637|28#10d5|5c55|639|26', '29', '2018-01-29 09:26:07');
INSERT INTO `hms_position` VALUES ('292', '20', '2018-01-29 09:31:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|d7bb|642|34#10d5|5c55|639|34#10d6|9f04|646|32#10e3|2d1b|121|32#10e3|e8d8|637|30', '29', '2018-01-29 09:31:07');
INSERT INTO `hms_position` VALUES ('293', '6', '2018-01-29 10:51:04', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|38#10e3|6371|640|44#10e3|e8d8|637|42#10d5|5c55|639|36#10d5|5c54|664|33#10e3|2d1b|121|33', '13', '2018-01-29 10:51:06');
INSERT INTO `hms_position` VALUES ('294', '6', '2018-01-29 10:56:04', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|41#10e3|6371|640|39#10d6|9f04|646|38#10e3|d7bb|642|38#10e3|2889|123|37#10d5|5c55|639|34', '13', '2018-01-29 10:56:07');
INSERT INTO `hms_position` VALUES ('295', '6', '2018-01-29 11:01:04', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|41#10e3|6371|640|46#10d6|9f04|646|39#10e3|d7bb|642|37#10e3|2d1b|121|37#10d5|5c55|639|34', '13', '2018-01-29 11:01:05');
INSERT INTO `hms_position` VALUES ('296', '6', '2018-01-29 11:06:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|e8d8|637|42#10d5|5c55|639|38#10d6|9f04|646|36#10e3|2d1b|121|34#10e3|d7bb|642|34', '13', '2018-01-29 11:06:05');
INSERT INTO `hms_position` VALUES ('297', '6', '2018-01-29 11:11:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|e8d8|637|40#10d5|5c55|639|39#10d6|9f04|646|38#10e3|2d1b|121|37#10e3|d7bb|642|35', '13', '2018-01-29 11:11:06');
INSERT INTO `hms_position` VALUES ('298', '6', '2018-01-29 11:16:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|e8d8|637|43#10e3|2d1b|121|38#10d5|5c55|639|37#10d5|2d08|124|33#10e3|9dcd|664|32', '13', '2018-01-29 11:16:06');
INSERT INTO `hms_position` VALUES ('299', '6', '2018-01-29 11:21:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|40#10e3|e8d8|637|42#10e3|d7bb|642|42#10d6|9f04|646|38#10d5|5c55|639|37#10e3|2d1b|121|36', '13', '2018-01-29 11:21:06');
INSERT INTO `hms_position` VALUES ('300', '6', '2018-01-29 11:26:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|e8d8|637|42#10e3|d7bb|642|40#10d6|9f04|646|39#10d5|5c55|639|38#10e3|2d1b|121|35', '13', '2018-01-29 11:26:06');
INSERT INTO `hms_position` VALUES ('301', '6', '2018-01-29 11:31:04', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10d6|9f04|646|40#10e3|2d1b|121|39#10e3|e8d8|637|38#10e3|d7bb|642|34#10e3|9dcd|664|31', '13', '2018-01-29 11:31:06');
INSERT INTO `hms_position` VALUES ('302', '6', '2018-01-29 11:36:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|e8d8|637|39#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|2d1b|121|37#10d5|5c55|639|35', '13', '2018-01-29 11:36:06');
INSERT INTO `hms_position` VALUES ('303', '6', '2018-01-29 11:41:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|52#10d6|9f04|646|40#10e3|d7bb|642|36#10e3|e8d8|637|36#10e3|2d1b|121|36#10e3|9dcd|664|34', '13', '2018-01-29 11:41:07');
INSERT INTO `hms_position` VALUES ('304', '6', '2018-01-29 11:46:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|38#10d6|9f04|646|36#10e3|e8d8|637|36#10e3|9dcd|664|34#10e3|d7bb|642|31', '13', '2018-01-29 11:46:07');
INSERT INTO `hms_position` VALUES ('305', '6', '2018-01-29 11:51:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|42#10d6|9f04|646|40#10e3|d7bb|642|37#10e3|e8d8|637|37#10d5|5c55|639|36', '13', '2018-01-29 11:51:06');
INSERT INTO `hms_position` VALUES ('306', '6', '2018-01-29 11:56:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|41#10e3|e8d8|637|37#10e3|9dcd|664|37#10d5|5c55|639|35#10d6|9f04|646|35', '13', '2018-01-29 11:56:06');
INSERT INTO `hms_position` VALUES ('307', '6', '2018-01-29 12:01:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|40#10e3|d7bb|642|40#10d6|9f04|646|37#10d5|5c55|639|36#10e3|9dcd|664|36', '13', '2018-01-29 12:01:06');
INSERT INTO `hms_position` VALUES ('308', '6', '2018-01-29 12:06:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|48#10e3|9dcd|664|41#10e3|2d1b|121|40#10e3|e8d8|637|35#10d5|5c55|639|34#10e3|d7bb|642|32', '13', '2018-01-29 12:06:06');
INSERT INTO `hms_position` VALUES ('309', '6', '2018-01-29 12:11:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|41#10e3|9dcd|664|40#10d5|5c55|639|34#10e3|e8d8|637|33#10d6|9f04|646|31', '13', '2018-01-29 12:11:06');
INSERT INTO `hms_position` VALUES ('310', '6', '2018-01-29 12:16:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|2d1b|121|37#10e3|e8d8|637|37#10e3|9dcd|664|36#10d5|5c55|639|34#10e3|d7bb|642|32', '13', '2018-01-29 12:16:06');
INSERT INTO `hms_position` VALUES ('311', '6', '2018-01-29 12:21:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|2d1b|121|41#10e3|e8d8|637|40#10d6|9f04|646|39#10e3|d7bb|642|38#10e3|9dcd|664|37', '13', '2018-01-29 12:21:06');
INSERT INTO `hms_position` VALUES ('312', '6', '2018-01-29 12:26:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|2d1b|121|41#10e3|e8d8|637|41#10d6|9f04|646|39#10e3|d7bb|642|37#10e3|9dcd|664|37', '13', '2018-01-29 12:26:06');
INSERT INTO `hms_position` VALUES ('313', '6', '2018-01-29 12:31:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|2d1b|121|41#10e3|e8d8|637|39#10e3|2889|123|39#10d6|9f04|646|38#10e3|d7bb|642|38', '13', '2018-01-29 12:31:07');
INSERT INTO `hms_position` VALUES ('314', '6', '2018-01-29 12:36:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|2d1b|121|41#10e3|2889|123|39#10e3|e8d8|637|39#10d6|9f04|646|39#10e3|d7bb|642|38', '13', '2018-01-29 12:36:06');
INSERT INTO `hms_position` VALUES ('315', '6', '2018-01-29 12:41:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|2d1b|121|41#10e3|e8d8|637|40#10d6|9f04|646|39#10e3|d7bb|642|36#10e3|9dcd|664|36', '13', '2018-01-29 12:41:07');
INSERT INTO `hms_position` VALUES ('316', '6', '2018-01-29 12:46:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|40#10e3|e8d8|637|40#10d6|9f04|646|39#10e3|d7bb|642|38#10e3|9dcd|664|36', '13', '2018-01-29 12:46:07');
INSERT INTO `hms_position` VALUES ('317', '6', '2018-01-29 12:51:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|40#10e3|e8d8|637|40#10d6|9f04|646|39#10e3|d7bb|642|39#10e3|9dcd|664|36', '13', '2018-01-29 12:51:06');
INSERT INTO `hms_position` VALUES ('318', '6', '2018-01-29 12:56:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|41#10e3|e8d8|637|40#10d6|9f04|646|40#10e3|d7bb|642|39#10e3|9dcd|664|36', '13', '2018-01-29 12:56:06');
INSERT INTO `hms_position` VALUES ('319', '6', '2018-01-29 13:01:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|48#10e3|2d1b|121|41#10e3|e8d8|637|40#10d6|9f04|646|40#10e3|d7bb|642|40#10e3|9dcd|664|36', '13', '2018-01-29 13:01:06');
INSERT INTO `hms_position` VALUES ('320', '6', '2018-01-29 13:06:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|48#10e3|2d1b|121|41#10e3|e8d8|637|39#10d6|9f04|646|39#10e3|d7bb|642|38#10d5|9e6c|650|34', '13', '2018-01-29 13:06:06');
INSERT INTO `hms_position` VALUES ('321', '6', '2018-01-29 13:11:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|e8d8|637|42#10e3|2d1b|121|41#10d6|9f04|646|39#10d5|9e6c|650|36#10e3|9dcd|664|35', '13', '2018-01-29 13:11:07');
INSERT INTO `hms_position` VALUES ('322', '6', '2018-01-29 13:16:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|e8d8|637|39#10e3|d7bb|642|38#10d6|9f04|646|36#10d5|9e6c|650|35#10e3|9dcd|664|35', '13', '2018-01-29 13:16:06');
INSERT INTO `hms_position` VALUES ('323', '6', '2018-01-29 13:21:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|53#10e3|d7bb|642|40#10e3|e8d8|637|39#10d6|9f04|646|38#10d5|5c55|639|38#10d5|9e6c|650|35', '13', '2018-01-29 13:21:06');
INSERT INTO `hms_position` VALUES ('324', '6', '2018-01-29 13:26:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|e8d8|637|41#10d5|5c55|639|36#10d6|9f04|646|34#10e3|6370|653|31#10e3|9dcd|664|30', '13', '2018-01-29 13:26:07');
INSERT INTO `hms_position` VALUES ('325', '6', '2018-01-29 13:31:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|2d1b|121|39#10e3|e8d8|637|38#10d6|9f04|646|36#10e3|9dcd|664|36#10d5|5c55|639|35', '13', '2018-01-29 13:31:06');
INSERT INTO `hms_position` VALUES ('326', '6', '2018-01-29 13:36:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|38#10e3|9dcd|664|36#10e3|e8d8|637|36#10e3|d7bb|642|35#10d5|5c55|639|34', '13', '2018-01-29 13:36:07');
INSERT INTO `hms_position` VALUES ('327', '6', '2018-01-29 13:41:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|9dcd|664|36#10e3|e8d8|637|36#10e3|2d1b|121|36#10e3|d620|650|36#10d5|5c55|639|36', '13', '2018-01-29 13:41:06');
INSERT INTO `hms_position` VALUES ('328', '6', '2018-01-29 13:46:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|38#10e3|e8d8|637|38#10d6|9f04|646|38#10e3|9dcd|664|37#10d5|5c55|639|35', '13', '2018-01-29 13:46:06');
INSERT INTO `hms_position` VALUES ('329', '6', '2018-01-29 13:51:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|e8d8|637|40#10e3|2d1b|121|39#10e3|9dcd|664|38#10d5|5c55|639|37#10d6|9f04|646|36', '13', '2018-01-29 13:51:06');
INSERT INTO `hms_position` VALUES ('330', '6', '2018-01-29 13:56:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|e8d8|637|40#10e3|2d1b|121|38#10e3|9dcd|664|37#10d5|5c55|639|37#10d6|9f04|646|35', '13', '2018-01-29 13:56:06');
INSERT INTO `hms_position` VALUES ('331', '6', '2018-01-29 14:01:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|51#10e3|2d1b|121|38#10d5|5c55|639|36#10e3|e8d8|637|36#10e3|d7bb|642|35#10e3|d620|650|35', '13', '2018-01-29 14:01:06');
INSERT INTO `hms_position` VALUES ('332', '6', '2018-01-29 14:06:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|48#10e3|2d1b|121|39#10d5|5c55|639|36#10e3|d7bb|642|36#10e3|9dcd|664|35#10e3|e8d8|637|34', '13', '2018-01-29 14:06:07');
INSERT INTO `hms_position` VALUES ('333', '6', '2018-01-29 14:11:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|2d1b|121|40#10e3|e8d8|637|37#10d5|5c55|639|36#10d6|9f04|646|35#10e3|d7bb|642|30', '13', '2018-01-29 14:11:06');
INSERT INTO `hms_position` VALUES ('334', '6', '2018-01-29 14:16:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|39#10e3|e8d8|637|37#10d5|5c55|639|36#10d6|9f04|646|34#10e3|9dcd|664|32', '13', '2018-01-29 14:16:07');
INSERT INTO `hms_position` VALUES ('335', '6', '2018-01-29 14:21:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|e8d8|637|38#10e3|2d1b|121|38#10d5|5c55|639|35#10d6|9f04|646|33#10e3|d618|651|30', '13', '2018-01-29 14:21:07');
INSERT INTO `hms_position` VALUES ('336', '6', '2018-01-29 14:26:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|50#10e3|2d1b|121|39#10e3|e8d8|637|36#10d5|5c55|639|36#10e3|d7bb|642|32#10d5|5c54|664|31', '13', '2018-01-29 14:26:07');
INSERT INTO `hms_position` VALUES ('337', '6', '2018-01-29 14:31:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|42#10e3|2d1b|121|38#10d6|9f04|646|38#10e3|e8d8|637|37#10d5|5c55|639|34', '13', '2018-01-29 14:31:08');
INSERT INTO `hms_position` VALUES ('338', '6', '2018-01-29 14:36:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|d7bb|642|42#10d6|9f04|646|38#10e3|2d1b|121|38#10e3|e8d8|637|37#10d5|5c55|639|37', '13', '2018-01-29 14:36:07');
INSERT INTO `hms_position` VALUES ('339', '6', '2018-01-29 14:41:05', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|d7bb|642|41#10d6|9f04|646|40#10e3|2d1b|121|38#10e3|e8d8|637|38#10d5|5c55|639|37', '13', '2018-01-29 14:41:08');
INSERT INTO `hms_position` VALUES ('340', '6', '2018-01-29 14:46:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10d6|9f04|646|39#10e3|e8d8|637|39#10e3|d7bb|642|38#10e3|2d1b|121|38#10d5|5c55|639|37', '13', '2018-01-29 14:46:08');
INSERT INTO `hms_position` VALUES ('341', '6', '2018-01-29 14:51:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|35#10e3|d7bb|642|43#10e3|2d1b|121|40#10d6|9f04|646|38#10e3|e8d8|637|37#10d5|5c55|639|37', '13', '2018-01-29 14:51:07');
INSERT INTO `hms_position` VALUES ('342', '6', '2018-01-29 14:56:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$4#10e3|d7bb|642|42#10e3|e8d8|637|38#10e3|2d1b|121|38#10e3|6371|640|37#10d5|5c55|639|37#10e3|9dcd|664|37', '13', '2018-01-29 14:56:08');
INSERT INTO `hms_position` VALUES ('343', '6', '2018-01-29 15:01:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|45#10e3|6371|640|42#10e3|e8d8|637|38#10d5|5c55|639|37#10e3|2d1b|121|37#10e3|2889|123|32', '13', '2018-01-29 15:01:17');
INSERT INTO `hms_position` VALUES ('344', '6', '2018-01-29 15:06:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|43#10e3|6371|640|47#10e3|2d1b|121|39#10d5|5c55|639|38#10e3|e8d8|637|37#10c2|1384|653|32', '13', '2018-01-29 15:06:14');
INSERT INTO `hms_position` VALUES ('345', '6', '2018-01-29 15:11:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|43#10e3|2d1b|121|39#10e3|e8d8|637|38#10e3|9dcd|664|38#10d5|5c55|639|38', '13', '2018-01-29 15:11:07');
INSERT INTO `hms_position` VALUES ('346', '6', '2018-01-29 15:16:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|d7bb|642|45#10d5|5c55|639|39#10e3|e8d8|637|39#10e3|9dcd|664|37#10d5|9e6c|650|36', '13', '2018-01-29 15:16:07');
INSERT INTO `hms_position` VALUES ('347', '6', '2018-01-29 15:21:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|47#10e3|d7bb|642|44#10d5|5c55|639|40#10e3|9dcd|664|38#10e3|e8d8|637|38#10d6|9f04|646|37', '13', '2018-01-29 15:21:07');
INSERT INTO `hms_position` VALUES ('348', '6', '2018-01-29 15:26:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|43#10e3|6371|640|44#10e3|e8d8|637|40#10e3|2d1b|121|34#10d5|5c55|639|34#10c2|1384|653|29', '13', '2018-01-29 15:26:10');
INSERT INTO `hms_position` VALUES ('349', '20', '2018-01-29 15:31:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|44#10e3|2d1b|121|39#10e3|e8d8|637|38#10d5|5c55|639|36#10e3|2889|123|36#10e3|6371|640|29', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_position` VALUES ('350', '20', '2018-01-29 15:36:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|41#10e3|9dcd|664|39#10d6|9f04|646|37#10d5|5c55|639|34#10d5|2d08|124|34', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_position` VALUES ('351', '20', '2018-01-29 15:41:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|d7bb|642|41#10e3|9dcd|664|39#10d6|9f04|646|38#10d5|2d08|124|34#10d6|9f02|659|33', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_position` VALUES ('352', '20', '2018-01-29 15:46:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|9dcd|664|38#10d6|9f04|646|35#10d5|5c55|639|35#10e3|e8d8|637|33#10d6|9f02|659|33', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_position` VALUES ('353', '20', '2018-01-29 15:51:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|33#10e3|d7bb|642|36#10e3|9dcd|664|35#10d6|9f04|646|33#10e3|2d1b|121|32#10e3|e8d8|637|30', '29', '2018-01-29 15:53:10');
INSERT INTO `hms_position` VALUES ('354', '20', '2018-01-29 15:56:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|36#10e3|e8d8|637|41#10e3|2d1b|121|34#10e3|9dcd|664|34#10d5|5c55|639|33#10d6|9f04|646|33', '29', '2018-01-29 15:56:08');
INSERT INTO `hms_position` VALUES ('355', '20', '2018-01-29 16:01:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|40#10e3|e8d8|637|36#10e3|9dcd|664|33#10e3|2d1b|121|33#10d6|9f02|659|30#10d6|9f04|646|29', '29', '2018-01-29 16:01:08');
INSERT INTO `hms_position` VALUES ('356', '20', '2018-01-29 16:06:06', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|40#10e3|d7bb|642|38#10e3|6371|640|38#10d6|9f04|646|37#10d5|5c55|639|33#10e3|d62b|651|30', '29', '2018-01-29 16:06:08');
INSERT INTO `hms_position` VALUES ('357', '20', '2018-01-29 16:11:06', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|39#10e3|e8d8|637|37#10e3|6371|640|37#10e3|2d1b|121|36#10d5|5c55|639|34#10e3|d62b|651|31', '29', '2018-01-29 16:11:15');
INSERT INTO `hms_position` VALUES ('358', '20', '2018-01-29 16:16:07', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|42#10e3|6371|640|39#10d6|9f04|646|36#10e3|2d1b|121|32#10e3|d7bb|642|32#10e3|2889|123|31', '29', '2018-01-29 16:16:09');
INSERT INTO `hms_position` VALUES ('359', '20', '2018-01-29 16:21:06', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|40#10d6|9f04|646|34#10d5|5c55|639|33#10e3|d620|650|33#10e3|2889|123|32#10e3|e8d8|637|31', '29', '2018-01-29 16:21:08');
INSERT INTO `hms_position` VALUES ('360', '20', '2018-01-29 16:26:07', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|40#10e3|6371|640|43#10e3|d7bb|642|37#10d5|5c55|639|32#10d6|9f04|646|32#10e3|2889|123|30', '29', '2018-01-29 16:26:08');
INSERT INTO `hms_position` VALUES ('361', '20', '2018-01-29 16:31:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|39#10e3|e8d8|637|38#10d5|5c55|639|37#10e3|2d1b|121|34#10d6|9f04|646|32#10e3|d62b|651|32', '29', '2018-01-29 16:31:09');
INSERT INTO `hms_position` VALUES ('362', '20', '2018-01-29 16:36:07', '116.328491', '40.078136', '北京市昌平区同成街', 'mcount$6$460$1$255#10e3|e8d8|637|37#10e3|6371|640|44#10d5|5c55|639|34#10e3|2d1b|121|32#10e3|d62b|651|31#10d6|9f04|646|29', '29', '2018-01-29 16:36:08');
INSERT INTO `hms_position` VALUES ('363', '20', '2018-01-29 16:41:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|38#10e3|e8d8|637|38#10e3|d7bb|642|32#10d5|5c55|639|32#10e3|9dcd|664|31#10d6|9f04|646|31', '29', '2018-01-29 16:41:09');
INSERT INTO `hms_position` VALUES ('364', '20', '2018-01-29 16:46:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10d6|9f04|646|38#10d5|5c54|664|36#10e3|d7bb|642|35#10d5|5c55|639|34#10e3|2d1b|121|34', '29', '2018-01-29 16:46:09');
INSERT INTO `hms_position` VALUES ('365', '20', '2018-01-29 16:51:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8d8|637|37#10d5|5c55|639|35#10e3|2d1b|121|35#10d5|5c54|664|34#10e3|d62b|651|31', '29', '2018-01-29 16:51:09');
INSERT INTO `hms_position` VALUES ('366', '20', '2018-01-29 16:56:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|e8d8|637|40#10e3|2d1b|121|39#10e3|d620|650|38#10d6|9f04|646|36#10d5|5c55|639|36', '29', '2018-01-29 16:56:09');
INSERT INTO `hms_position` VALUES ('367', '20', '2018-01-29 17:01:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|e8d8|637|38#10e3|9dcd|664|36#10d5|5c55|639|34#10e3|d7bb|642|34#10d6|9f04|646|31', '29', '2018-01-29 17:01:09');
INSERT INTO `hms_position` VALUES ('368', '20', '2018-01-29 17:06:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8d8|637|39#10e3|2d1b|121|37#10d6|9f04|646|34#10d5|5c55|639|34#10d5|5c54|664|34', '29', '2018-01-29 17:06:09');
INSERT INTO `hms_position` VALUES ('369', '20', '2018-01-29 17:11:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|49#10e3|e8d8|637|38#10e3|2d1b|121|36#10d5|5c54|664|36#10d5|5c55|639|35#10d6|9f02|659|32', '29', '2018-01-29 17:11:09');
INSERT INTO `hms_position` VALUES ('370', '20', '2018-01-29 17:16:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|39#10e3|d7bb|642|39#10d5|5c55|639|36#10e3|2d1b|121|36#10d5|5c54|664|34#10e3|e8d8|637|32', '29', '2018-01-29 17:16:09');
INSERT INTO `hms_position` VALUES ('371', '20', '2018-01-29 17:21:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|36#10d5|5c54|664|35#10d5|5c55|639|33#10d6|9f02|659|32#10e3|e8d8|637|31', '29', '2018-01-29 17:21:09');
INSERT INTO `hms_position` VALUES ('372', '20', '2018-01-29 17:26:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|d7bb|642|38#10d5|5c54|664|36#10d5|5c55|639|36#10d6|9f04|646|34#10d6|9f02|659|34', '29', '2018-01-29 17:26:09');
INSERT INTO `hms_position` VALUES ('373', '20', '2018-01-29 17:31:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|39#10e3|d7bb|642|38#10e3|2d1b|121|36#10e3|9dcd|664|35#10d6|9f04|646|33#10e3|e8d8|637|33', '29', '2018-01-29 17:31:09');
INSERT INTO `hms_position` VALUES ('374', '20', '2018-01-29 17:36:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|39#10e3|d7bb|642|39#10d5|5c55|639|36#10d6|9f04|646|36#10d5|5c54|664|33#10e3|6370|653|29', '29', '2018-01-29 17:36:09');
INSERT INTO `hms_position` VALUES ('375', '20', '2018-01-29 17:41:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|40#10d5|5c55|639|39#10e3|e8d8|637|38#10e3|d7bb|642|38#10d5|5c54|664|38#10d6|9f04|646|37', '29', '2018-01-29 17:41:40');
INSERT INTO `hms_position` VALUES ('376', '20', '2018-01-29 17:46:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10d5|5c55|639|38#10e3|d620|650|35#10e3|2d1b|121|35#10e3|d7bb|642|35#10d6|9f04|646|34', '29', '2018-01-29 17:46:09');
INSERT INTO `hms_position` VALUES ('377', '20', '2018-01-29 17:56:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10d5|5c55|639|38#10e3|d7bb|642|37#10e3|2d1b|121|36#10e3|d620|650|35#10d6|9f04|646|35', '29', '2018-01-29 17:56:09');
INSERT INTO `hms_position` VALUES ('378', '20', '2018-01-29 18:01:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|2d1b|121|38#10e3|d7bb|642|38#10d6|9f04|646|38#10d5|5c55|639|36#10e3|6370|653|29', '29', '2018-01-29 18:01:09');
INSERT INTO `hms_position` VALUES ('379', '20', '2018-01-29 18:06:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10e3|2d1b|121|37#10d5|5c55|639|36#10d6|9f04|646|34#10e3|9dcd|664|33', '29', '2018-01-29 18:06:09');
INSERT INTO `hms_position` VALUES ('380', '20', '2018-01-29 18:11:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|35#10e3|d7bb|642|39#10e3|e8d8|637|36#10e3|9dcd|664|35#10d5|5c55|639|35#10d6|9f04|646|32', '29', '2018-01-29 18:21:44');
INSERT INTO `hms_position` VALUES ('381', '20', '2018-01-29 18:16:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|d7bb|642|39#10d5|5c55|639|37#10e3|d620|650|36#10d5|5c54|664|34#10e3|e8d8|637|33', '29', '2018-01-29 18:21:44');
INSERT INTO `hms_position` VALUES ('382', '20', '2018-01-29 18:26:07', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|41#10e3|6371|640|41#10e3|2d1b|121|38#10d5|5c55|639|36#10e3|d620|650|35#10d5|5c54|664|34', '29', '2018-01-29 18:26:44');
INSERT INTO `hms_position` VALUES ('383', '20', '2018-01-29 18:31:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|39#10e3|2d1b|121|37#10e3|d620|650|36#10d5|5c55|639|36#10d5|5c54|664|33', '29', '2018-01-29 18:31:09');
INSERT INTO `hms_position` VALUES ('384', '20', '2018-01-29 18:36:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|2d1b|121|37#10e3|d7bb|642|36#10d5|5c55|639|34#10d5|5c54|664|34#10e3|e8d8|637|32', '29', '2018-01-29 18:36:09');
INSERT INTO `hms_position` VALUES ('385', '20', '2018-01-29 18:41:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|e8d8|637|37#10d6|9f04|646|37#10e3|2d1b|121|32#10e3|9dcd|664|29#10d5|5c55|639|28', '29', '2018-01-29 18:41:09');
INSERT INTO `hms_position` VALUES ('386', '20', '2018-01-29 18:46:07', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10d6|9f04|646|41#10e3|2d1b|121|37#10e3|d7bb|642|36#10e3|e8d8|637|33#10e3|9dcd|664|30', '29', '2018-01-29 18:46:09');
INSERT INTO `hms_position` VALUES ('387', '20', '2018-01-29 18:51:07', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|43#10e3|6371|640|44#10e3|2d1b|121|35#10e3|9dcd|664|34#10d5|5c55|639|34#10d5|9ea8|641|32', '29', '2018-01-29 18:51:10');
INSERT INTO `hms_position` VALUES ('388', '20', '2018-01-29 18:56:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|41#10e3|e8d8|637|37#10e3|2d1b|121|36#10d6|9f04|646|35#10e3|9dcd|664|34', '29', '2018-01-29 18:56:10');
INSERT INTO `hms_position` VALUES ('389', '20', '2018-01-29 19:01:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|d7bb|642|43#10e3|2d1b|121|38#10e3|e8d8|637|35#10d5|9ea8|641|32#10d6|9f04|646|31', '29', '2018-01-29 19:01:10');
INSERT INTO `hms_position` VALUES ('390', '20', '2018-01-29 19:06:08', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|40#10e3|6371|640|44#10e3|2d1b|121|40#10e3|9dcd|664|34#10d5|9ea8|641|32#10d5|2d07|122|31', '29', '2018-01-29 19:06:11');
INSERT INTO `hms_position` VALUES ('391', '20', '2018-01-29 19:11:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10d6|9f04|646|39#10e3|d7bb|642|39#10e3|2d1b|121|38#10e3|9dcd|664|37#10e3|6372|637|35', '29', '2018-01-29 19:11:10');
INSERT INTO `hms_position` VALUES ('392', '20', '2018-01-29 19:16:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|40#10e3|2d1b|121|38#10e3|9dcd|664|36#10e3|d62b|651|32', '29', '2018-01-29 19:16:10');
INSERT INTO `hms_position` VALUES ('393', '20', '2018-01-29 19:21:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|46#10e3|9dcd|664|39#10e3|e8d8|637|35#10e3|2d1b|121|35#10d6|9f04|646|35#10d5|9ea8|641|32', '29', '2018-01-29 19:21:10');
INSERT INTO `hms_position` VALUES ('394', '20', '2018-01-29 19:26:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|9dcd|664|37#10d6|9f04|646|36#10e3|d7bb|642|36#10d5|2d08|124|35#10e3|e8d8|637|35', '29', '2018-01-29 19:26:10');
INSERT INTO `hms_position` VALUES ('395', '20', '2018-01-29 19:31:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10d6|9f04|646|39#10e3|d7bb|642|38#10e3|9dcd|664|38#10e3|2d1b|121|36#10d5|5c55|639|31', '29', '2018-01-29 19:31:10');
INSERT INTO `hms_position` VALUES ('396', '20', '2018-01-29 19:36:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|41#10e3|9dcd|664|37#10d6|9f04|646|36#10e3|2d1b|121|35#10e3|e8d8|637|33', '29', '2018-01-29 19:36:10');
INSERT INTO `hms_position` VALUES ('397', '20', '2018-01-29 19:41:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|d7bb|642|38#10d6|9f04|646|37#10e3|9dcd|664|36#10e3|2d1b|121|36#10d5|5c55|639|31', '29', '2018-01-29 19:41:10');
INSERT INTO `hms_position` VALUES ('398', '20', '2018-01-29 19:46:08', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|37#10e3|2d1b|121|37#10e3|9dcd|664|36#10d6|9f04|646|36#10e3|e8d8|637|35', '29', '2018-01-29 19:46:10');
INSERT INTO `hms_position` VALUES ('399', '20', '2018-01-29 19:51:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|38#10e3|9dcd|664|37#10d6|9f04|646|36#10e3|2d1b|121|36#10d5|2d08|124|33', '29', '2018-01-29 19:51:11');
INSERT INTO `hms_position` VALUES ('400', '20', '2018-01-29 19:56:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|38#10e3|9dcd|664|37#10e3|2d1b|121|36#10d6|9f04|646|36#10e3|e8d8|637|35', '29', '2018-01-29 19:56:11');
INSERT INTO `hms_position` VALUES ('401', '20', '2018-01-29 20:01:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|45#10e3|d7bb|642|39#10e3|2d1b|121|38#10e3|9dcd|664|36#10d6|9f04|646|35#10e3|e8d8|637|34', '29', '2018-01-29 20:01:11');
INSERT INTO `hms_position` VALUES ('402', '20', '2018-01-29 20:06:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10e3|2d1b|121|38#10e3|9dcd|664|37#10d6|9f04|646|36', '29', '2018-01-29 20:06:11');
INSERT INTO `hms_position` VALUES ('403', '20', '2018-01-29 20:11:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|41#10e3|d7bb|642|39#10e3|9dcd|664|37#10e3|2d1b|121|36#10d6|9f04|646|36#10e3|e8d8|637|35', '29', '2018-01-29 20:11:11');
INSERT INTO `hms_position` VALUES ('404', '20', '2018-01-29 20:16:09', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|41#10e3|6371|640|39#10e3|9dcd|664|36#10e3|2d1b|121|35#10e3|e8d8|637|35#10d5|2d08|124|34', '29', '2018-01-29 20:16:11');
INSERT INTO `hms_position` VALUES ('405', '20', '2018-01-29 20:21:09', '116.341743', '40.084061', '北京市昌平区育知东路辅路', 'mcount$6$460$1$255#10e3|d7bb|642|40#10e3|6371|640|39#10e3|2d1b|121|36#10e3|e8d8|637|34#10d5|2d08|124|33#10d5|5c55|639|32', '29', '2018-01-29 20:21:11');
INSERT INTO `hms_position` VALUES ('406', '20', '2018-01-29 20:26:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|d7bb|642|38#10d6|9f04|646|37#10e3|9dcd|664|36#10e3|2d1b|121|36#10e3|e8d8|637|36', '29', '2018-01-29 20:26:11');
INSERT INTO `hms_position` VALUES ('407', '20', '2018-01-29 20:31:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|44#10e3|e8cd|650|40#10e3|d7bb|642|39#10e3|2d1b|121|37#10e3|9dcd|664|37#10e3|e8d8|637|35', '29', '2018-01-29 20:31:11');
INSERT INTO `hms_position` VALUES ('408', '20', '2018-01-29 20:36:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|39#10e3|2d1b|121|37#10e3|9dcd|664|37#10d6|9f04|646|36#10e3|e8d8|637|35', '29', '2018-01-29 20:36:11');
INSERT INTO `hms_position` VALUES ('409', '20', '2018-01-29 20:41:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|38#10e3|2d1b|121|37#10e3|9dcd|664|37#10d6|9f04|646|36#10e3|e8d8|637|36', '29', '2018-01-29 20:41:11');
INSERT INTO `hms_position` VALUES ('410', '20', '2018-01-29 20:46:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|2d1b|121|36#10d5|5c55|639|33', '29', '2018-01-29 20:46:11');
INSERT INTO `hms_position` VALUES ('411', '20', '2018-01-29 20:51:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|36#10e3|9dcd|664|36#10e3|2d1b|121|36', '29', '2018-01-29 20:51:11');
INSERT INTO `hms_position` VALUES ('412', '20', '2018-01-29 20:56:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36#10e3|2d1b|121|36', '29', '2018-01-29 20:56:11');
INSERT INTO `hms_position` VALUES ('413', '20', '2018-01-29 21:01:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10e3|e8cd|650|39#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 21:01:11');
INSERT INTO `hms_position` VALUES ('414', '20', '2018-01-29 21:06:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 21:06:11');
INSERT INTO `hms_position` VALUES ('415', '20', '2018-01-29 21:11:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 21:11:11');
INSERT INTO `hms_position` VALUES ('416', '20', '2018-01-29 21:16:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10e3|e8cd|650|39#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 21:16:12');
INSERT INTO `hms_position` VALUES ('417', '20', '2018-01-29 21:21:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10e3|e8cd|650|40#10d6|9f04|646|37#10e3|9dcd|664|36#10e3|e8d8|637|36', '29', '2018-01-29 21:21:11');
INSERT INTO `hms_position` VALUES ('418', '20', '2018-01-29 21:26:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10e3|e8cd|650|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 21:26:11');
INSERT INTO `hms_position` VALUES ('419', '20', '2018-01-29 21:31:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36#10e3|2d1b|121|35', '29', '2018-01-29 21:31:11');
INSERT INTO `hms_position` VALUES ('420', '20', '2018-01-29 21:36:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 21:36:11');
INSERT INTO `hms_position` VALUES ('421', '20', '2018-01-29 21:41:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 21:41:11');
INSERT INTO `hms_position` VALUES ('422', '20', '2018-01-29 21:46:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 21:46:11');
INSERT INTO `hms_position` VALUES ('423', '20', '2018-01-29 21:51:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 21:51:11');
INSERT INTO `hms_position` VALUES ('424', '20', '2018-01-29 21:56:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|37#10e3|2d1b|121|34', '29', '2018-01-29 21:56:11');
INSERT INTO `hms_position` VALUES ('425', '20', '2018-01-29 22:01:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 22:01:11');
INSERT INTO `hms_position` VALUES ('426', '20', '2018-01-29 22:06:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10e3|e8cd|650|39#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 22:06:11');
INSERT INTO `hms_position` VALUES ('427', '20', '2018-01-29 22:11:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36#10e3|2d1b|121|35', '29', '2018-01-29 22:11:11');
INSERT INTO `hms_position` VALUES ('428', '20', '2018-01-29 22:16:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|37#10e3|9dcd|664|36#10e3|2d1b|121|35#10d5|5c55|639|34', '29', '2018-01-29 22:16:11');
INSERT INTO `hms_position` VALUES ('429', '20', '2018-01-29 22:21:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|39#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 22:21:11');
INSERT INTO `hms_position` VALUES ('430', '20', '2018-01-29 22:26:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 22:26:11');
INSERT INTO `hms_position` VALUES ('431', '20', '2018-01-29 22:31:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 22:31:11');
INSERT INTO `hms_position` VALUES ('432', '20', '2018-01-29 22:36:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 22:36:11');
INSERT INTO `hms_position` VALUES ('433', '20', '2018-01-29 22:41:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 22:41:11');
INSERT INTO `hms_position` VALUES ('434', '20', '2018-01-29 22:46:09', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|43#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 22:46:11');
INSERT INTO `hms_position` VALUES ('435', '20', '2018-01-29 22:51:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|36#10e3|9dcd|664|36', '29', '2018-01-29 22:51:12');
INSERT INTO `hms_position` VALUES ('436', '20', '2018-01-29 22:56:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10e3|e8cd|650|40#10d6|9f04|646|37#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 22:56:12');
INSERT INTO `hms_position` VALUES ('437', '20', '2018-01-29 23:01:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$5$460$1$255#10e3|6371|640|42#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|9dcd|664|36#10e3|2d1b|121|36', '29', '2018-01-29 23:01:11');
INSERT INTO `hms_position` VALUES ('438', '20', '2018-01-29 23:06:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|37#10e3|9dcd|664|37#10e3|e8d8|637|36', '29', '2018-01-29 23:06:11');
INSERT INTO `hms_position` VALUES ('439', '20', '2018-01-29 23:11:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:11:12');
INSERT INTO `hms_position` VALUES ('440', '20', '2018-01-29 23:16:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$5$460$1$255#10e3|6371|640|42#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|9dcd|664|36#10e3|2d1b|121|35', '29', '2018-01-29 23:16:12');
INSERT INTO `hms_position` VALUES ('441', '20', '2018-01-29 23:21:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|37#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:21:12');
INSERT INTO `hms_position` VALUES ('442', '20', '2018-01-29 23:26:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|41#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:26:44');
INSERT INTO `hms_position` VALUES ('443', '20', '2018-01-29 23:31:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|39#10d6|9f04|646|37#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:31:12');
INSERT INTO `hms_position` VALUES ('444', '20', '2018-01-29 23:36:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36#10e3|2d1b|121|35', '29', '2018-01-29 23:36:12');
INSERT INTO `hms_position` VALUES ('445', '20', '2018-01-29 23:41:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:41:12');
INSERT INTO `hms_position` VALUES ('446', '20', '2018-01-29 23:46:10', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|d7bb|642|40#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36#10e3|2d1b|121|35', '29', '2018-01-29 23:46:12');
INSERT INTO `hms_position` VALUES ('447', '20', '2018-01-29 23:51:11', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|40#10e3|d7bb|642|40#10e3|e8d8|637|37#10e3|9dcd|664|37#10e3|2d1b|121|35', '29', '2018-01-29 23:51:13');
INSERT INTO `hms_position` VALUES ('448', '20', '2018-01-29 23:56:11', '116.352661', '40.077969', '北京市昌平区文华路', 'mcount$6$460$1$255#10e3|6371|640|42#10e3|e8cd|650|39#10e3|d7bb|642|39#10d6|9f04|646|38#10e3|e8d8|637|37#10e3|9dcd|664|36', '29', '2018-01-29 23:56:13');

-- ----------------------------
-- Table structure for uums_dict_check
-- ----------------------------
DROP TABLE IF EXISTS `uums_dict_check`;
CREATE TABLE `uums_dict_check` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键非空自增,字典表在总表的ID',
  `TAB_NAME` varchar(30) DEFAULT NULL,
  `TAB_ALIAS` varchar(30) DEFAULT NULL,
  `FLDS_NAME` varchar(100) DEFAULT NULL COMMENT '字段名用英文逗号分隔',
  `FLDS_ALIAS` varchar(100) DEFAULT NULL COMMENT '字段中文名，用英文逗号分隔',
  `FLDS_LENGTH` varchar(30) DEFAULT NULL COMMENT '字段长度，以英文逗号分隔',
  `IS_TREE` tinyint(4) DEFAULT NULL COMMENT '1-是，0-否',
  `SEQ_NO` tinyint(4) DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL COMMENT '字典表页面地址',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_dict_check
-- ----------------------------
INSERT INTO `uums_dict_check` VALUES ('4', 'dic_district', '行政区划', 'pid,districtName,flag', '父节点ID,区域名称,状态', '11,15,3', '1', null, 'dicDistrict');
INSERT INTO `uums_dict_check` VALUES ('5', 'dic_region', '区域数据', 'district,regionName,pinyin,flag', '行政区域编号,商圈名称/地名/地标,拼音首字母,状态', '11,15,15,3', '1', null, 'dicRegion');
INSERT INTO `uums_dict_check` VALUES ('6', 'dic_employe_class', '员工分类', 'class_Name', '员工类型', '15', '0', null, 'dicEmployeClass');
INSERT INTO `uums_dict_check` VALUES ('8', 'dic_product_category', '产品类别', 'categoryName,name', '产品类别,产品名称', '15,30', '0', null, 'dicProductCategory');
INSERT INTO `uums_dict_check` VALUES ('11', 'dic_log_type', '日志类型', 'logType', '日志类型', '15', '0', null, 'dicLogType');

-- ----------------------------
-- Table structure for uums_log
-- ----------------------------
DROP TABLE IF EXISTS `uums_log`;
CREATE TABLE `uums_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录标识，自增',
  `LOG_TYPE` tinyint(4) NOT NULL COMMENT '日志类型',
  `SOURCE` int(1) NOT NULL COMMENT '日志来源',
  `CONTENT` varchar(500) DEFAULT NULL COMMENT '日志内容',
  `LOGIN_IP` varchar(20) DEFAULT NULL COMMENT '登录用户IP',
  `CREATE_USER` int(11) DEFAULT NULL COMMENT '创建用户',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建类型',
  `REMARK` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`ID`),
  KEY `FK_LOG_USER` (`CREATE_USER`),
  KEY `FK_LOG_LOGTYPE` (`LOG_TYPE`),
  CONSTRAINT `FK_LOG_USER` FOREIGN KEY (`CREATE_USER`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_log
-- ----------------------------

-- ----------------------------
-- Table structure for uums_org
-- ----------------------------
DROP TABLE IF EXISTS `uums_org`;
CREATE TABLE `uums_org` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '机构唯一标识，自增',
  `ORG_CODE` varchar(32) NOT NULL DEFAULT '' COMMENT '机构编码',
  `ORG_NAME` varchar(100) NOT NULL DEFAULT '' COMMENT '机构名称',
  `PARENT_ID` int(11) DEFAULT '0' COMMENT '上一级单位ID',
  `IS_LEAF` tinyint(1) DEFAULT '0' COMMENT '是否叶子节点，1.是0.否',
  `FLAG` tinyint(1) DEFAULT '1' COMMENT '机构状态,0.停用1.正常',
  `CREATE_TIME` datetime NOT NULL,
  `SEQ_NO` int(11) DEFAULT NULL COMMENT '用于主动排序',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_org
-- ----------------------------
INSERT INTO `uums_org` VALUES ('1', '1', '云颐养', '0', '1', '1', '2017-08-22 14:23:21', '0');
INSERT INTO `uums_org` VALUES ('2', 'f990471c6f9844e09014d81c9ba07324', '堂姥姥', '1', '1', '1', '2017-11-16 10:47:27', '0');

-- ----------------------------
-- Table structure for uums_res
-- ----------------------------
DROP TABLE IF EXISTS `uums_res`;
CREATE TABLE `uums_res` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '资源唯一标识，自增',
  `IS_MENU` tinyint(4) DEFAULT '1' COMMENT '是否系统菜单，1-是，0-不是，默认1',
  `PARENT_ID` int(11) DEFAULT NULL COMMENT '父级资源标识',
  `RES_CODE` varchar(100) NOT NULL COMMENT '资源代码:资源全局唯一标识',
  `RES_NAME` varchar(50) NOT NULL DEFAULT '' COMMENT '资源名称',
  `RES_URL` varchar(100) DEFAULT NULL COMMENT '资源地址',
  `FLAG` int(1) NOT NULL DEFAULT '1' COMMENT '资源状态：资源当前状态：1-正常，0-停用，默认1',
  `SEQ_NO` int(11) DEFAULT NULL COMMENT '顺序号',
  `RES_ICON` varchar(100) DEFAULT NULL,
  `CREATE_TIME` datetime NOT NULL COMMENT '创建日期',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_res
-- ----------------------------
INSERT INTO `uums_res` VALUES ('1', '1', null, 'MAIN', '首页', '#', '1', '0', 'iconfont icon-shouye', '2017-10-31 18:12:37');
INSERT INTO `uums_res` VALUES ('2', '1', '1', '', '测试1', '#', '1', '0', '', '2017-11-16 11:34:39');

-- ----------------------------
-- Table structure for uums_role
-- ----------------------------
DROP TABLE IF EXISTS `uums_role`;
CREATE TABLE `uums_role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色唯一标识，自增',
  `ROLE_NAME` varchar(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `FLAG` int(1) NOT NULL DEFAULT '1' COMMENT '角色当前状态：1-正常，0-停用，默认1',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_role
-- ----------------------------
INSERT INTO `uums_role` VALUES ('1', '超级管理员', '1', '2017-11-22 10:41:43');
INSERT INTO `uums_role` VALUES ('2', '用户', '1', '2017-11-16 11:35:24');
INSERT INTO `uums_role` VALUES ('5', '1', '1', '2017-12-06 09:41:37');

-- ----------------------------
-- Table structure for uums_role_res
-- ----------------------------
DROP TABLE IF EXISTS `uums_role_res`;
CREATE TABLE `uums_role_res` (
  `role_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  PRIMARY KEY (`role_id`,`res_id`),
  KEY `FK_lwerq3awan9yi5j2a7sd1bcnj` (`res_id`),
  CONSTRAINT `FK_ew1epq7y5hub2509jo1bnsa5r` FOREIGN KEY (`role_id`) REFERENCES `uums_role` (`ID`),
  CONSTRAINT `FK_lwerq3awan9yi5j2a7sd1bcnj` FOREIGN KEY (`res_id`) REFERENCES `uums_res` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_role_res
-- ----------------------------
INSERT INTO `uums_role_res` VALUES ('1', '1');
INSERT INTO `uums_role_res` VALUES ('1', '2');

-- ----------------------------
-- Table structure for uums_user
-- ----------------------------
DROP TABLE IF EXISTS `uums_user`;
CREATE TABLE `uums_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户唯一标识，自增',
  `ORG_ID` int(11) NOT NULL DEFAULT '0' COMMENT '外键表：UUMS_ORG，外键字段：ID',
  `USER_TYPE` int(11) NOT NULL COMMENT '外键表：UUMS_USER_CODE，外键字段：ID',
  `USER_CODE` char(10) NOT NULL DEFAULT '' COMMENT '用户编码，按编码规则生成',
  `USER_NAME` varchar(15) DEFAULT NULL COMMENT '用户名',
  `USER_PWD` char(32) NOT NULL DEFAULT '000000' COMMENT '密码，加密值',
  `NICKNAME` varchar(10) DEFAULT NULL COMMENT '昵称',
  `AVATAR` varchar(5000) DEFAULT NULL COMMENT '头像，Base64',
  `NAME` varchar(10) DEFAULT NULL COMMENT '姓名',
  `SEX` tinyint(1) DEFAULT NULL COMMENT '性别',
  `BIRTHDAY` date DEFAULT NULL COMMENT '生日',
  `NATIVE_PLACE` varchar(50) DEFAULT NULL COMMENT '籍贯',
  `IDNO` char(18) DEFAULT NULL COMMENT '身份证号',
  `ADDRESS` varchar(50) DEFAULT NULL COMMENT '住址',
  `MOBILE` char(15) DEFAULT NULL COMMENT '手机号，唯一',
  `EMAIL` varchar(50) DEFAULT NULL COMMENT '邮箱，唯一',
  `WECHAT` varchar(30) DEFAULT NULL COMMENT '微信号，唯一，关联登录',
  `QQ` varchar(15) DEFAULT NULL COMMENT 'QQ号，唯一，关联登录',
  `SOURCE` tinyint(1) NOT NULL DEFAULT '0' COMMENT '来源，1-运营管理系统，2-门户，3-微信，4-APP，5-其他',
  `FLAG` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户状态，1-正常，0-停用',
  `IS_DEL` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，1-删除，0-不删除',
  `CREATE_TIME` datetime NOT NULL COMMENT '注册时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `TQ_UIN` int(11) DEFAULT NULL COMMENT '坐席关联用户需输入TQ呼叫中心系统中的TQ用户号（7位）',
  PRIMARY KEY (`ID`),
  KEY `FK_USER_ORG` (`ORG_ID`),
  KEY `FK_USER_CODE` (`USER_TYPE`),
  CONSTRAINT `FK_USER_CODE` FOREIGN KEY (`USER_TYPE`) REFERENCES `uums_user_code` (`ID`),
  CONSTRAINT `FK_USER_ORG` FOREIGN KEY (`ORG_ID`) REFERENCES `uums_org` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of uums_user
-- ----------------------------
INSERT INTO `uums_user` VALUES ('1', '1', '1', 'G000000001', 'admin', 'f3373b92adbaf255fc673520fbd18d9a', 'admin', '1', '测试', '1', '1899-12-30', '1', '111111111111111111', '北京市昌平区霍营1号楼', '18613561458', '132132132@qq.com', 'weixingdfadjkflej', '234342', '1', '1', '0', '2017-07-14 16:05:18', '2017-12-06 15:39:52', null);
INSERT INTO `uums_user` VALUES ('2', '2', '1', 'Y000000027', 'wpf', '5ab5f47af7414939ec2fa22fc198af45', 'wpf', null, 'wpf', '1', '2017-11-06', '', '', '', '18613456778', '', '', '', '1', '1', '0', '2017-11-16 11:33:56', null, null);
INSERT INTO `uums_user` VALUES ('3', '2', '1', 'Y000000028', '123', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, null, null, null, null, '1', '1', '1', '2017-11-20 18:09:07', '2017-11-20 18:09:07', null);
INSERT INTO `uums_user` VALUES ('4', '2', '1', 'Y000000035', 'cs35', '5ab5f47af7414939ec2fa22fc198af45', null, null, '测试w', '1', '2017-11-14', '', '', '', '13838383838', null, null, null, '1', '1', '0', '2017-11-24 10:17:33', '2017-11-24 10:23:33', null);
INSERT INTO `uums_user` VALUES ('5', '2', '1', 'Y000000036', '1', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13556786789', null, null, null, '1', '1', '1', '2017-11-24 11:13:10', '2017-11-24 11:13:10', null);
INSERT INTO `uums_user` VALUES ('6', '2', '1', 'Y000000037', 'qwe', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13556786788', null, null, null, '1', '1', '1', '2017-11-24 11:16:14', '2017-11-24 11:16:14', null);
INSERT INTO `uums_user` VALUES ('7', '2', '1', 'Y000000038', 'QAS', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13556789098', null, null, null, '1', '1', '1', '2017-11-24 11:40:38', '2017-11-24 11:40:38', null);
INSERT INTO `uums_user` VALUES ('8', '2', '1', 'Y000000039', 'zhujie', '5ab5f47af7414939ec2fa22fc198af45', '杰', '', '1232', '2', '1991-08-23', '河北衡水', '131122199108233223', '北京市昌平区霍营华龙苑中里2号楼1单元103', '186312231', '123123123@qq.com', 'weixin41', '123123123', '1', '1', '0', '2017-11-27 14:24:59', '2017-12-18 09:32:08', '1');
INSERT INTO `uums_user` VALUES ('9', '2', '1', 'Y000000040', 'hyy40', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员一', '1', '2017-11-27', '北京', '111111111111111111', '无', '13111111111', null, null, null, '1', '1', '1', '2017-11-27 14:46:02', '2017-11-27 14:46:52', null);
INSERT INTO `uums_user` VALUES ('10', '2', '1', 'Y000000041', 'YHY', '5ab5f47af7414939ec2fa22fc198af45', '一一啊', '', '用户一', '1', '2017-11-27', '北京市昌平区1号楼', '111111111111111111', '北京市昌平区霍营1号楼', '13211111111', '123123123@qq.com', 'weixin41', '123123123', '1', '1', '0', '2017-11-27 14:48:59', '2017-11-27 14:51:42', '2');
INSERT INTO `uums_user` VALUES ('11', '2', '1', 'Y000000042', 'A01', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13111111112', null, null, null, '1', '1', '1', '2017-11-27 15:09:31', '2017-11-27 15:09:31', null);
INSERT INTO `uums_user` VALUES ('12', '2', '1', 'Y000000043', 'hys', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员三', '2', '2017-11-28', '', '', '', '13111111113', null, null, null, '1', '1', '0', '2017-11-28 09:34:59', '2017-11-28 10:45:50', null);
INSERT INTO `uums_user` VALUES ('13', '2', '1', 'Y000000044', 'hys44', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员四', '1', '2017-11-28', '', '', '', '13111111114', null, null, null, '1', '1', '0', '2017-11-28 09:38:15', '2018-01-29 10:02:16', null);
INSERT INTO `uums_user` VALUES ('14', '2', '1', 'Y000000045', 'hyw45', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员五', '1', '2011-11-28', '', '', '', '13111111115', null, null, null, '1', '1', '0', '2017-11-28 09:41:04', '2017-11-28 09:53:10', null);
INSERT INTO `uums_user` VALUES ('15', '2', '1', 'Y000000046', 'hyl46', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员六', '1', '2010-11-23', '', '', '', '13111111116', null, null, null, '1', '1', '0', '2017-11-28 09:41:53', '2017-11-29 09:13:55', null);
INSERT INTO `uums_user` VALUES ('16', '2', '1', 'Y000000047', 'hyq', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13111111117', null, null, null, '1', '1', '1', '2017-11-29 09:12:37', '2017-11-29 09:12:37', null);
INSERT INTO `uums_user` VALUES ('17', '2', '1', 'Y000000048', 'yhb', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员八啊', '2', '2010-11-29', '北京市昌平区2号楼', '111111111111111118', '北京市昌平区霍营2号楼', '13111111118', null, null, null, '1', '1', '0', '2017-11-30 09:07:38', '2017-11-30 09:15:25', null);
INSERT INTO `uums_user` VALUES ('18', '2', '1', 'Y000000049', 'hyj', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员九', '1', '2017-11-30', '', '', '', '13111111119', null, null, null, '1', '1', '0', '2017-11-30 09:17:11', '2017-11-30 09:18:38', null);
INSERT INTO `uums_user` VALUES ('19', '2', '1', 'Y000000050', 'YHEY', '5ab5f47af7414939ec2fa22fc198af45', '用户二一', '', '二一', '1', '2017-11-23', '北京市昌平区1号楼', '111111111111111111', '北京市昌平区霍营1号楼', '13211111121', '123123124@qq.com', 'weixin42', '123123124', '1', '0', '0', '2017-11-30 10:05:11', '2017-11-30 10:06:26', '2');
INSERT INTO `uums_user` VALUES ('20', '2', '2', 'C000000001', 'HYES', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员二三啊', '1', '2010-12-01', '北京市昌平区2号楼', '111111111111111123', '北京市昌平区霍营2号楼', '0101111112', null, null, null, '1', '1', '0', '2017-12-01 10:29:10', '2018-01-29 10:01:50', null);
INSERT INTO `uums_user` VALUES ('21', '2', '2', 'C000000002', 'hyes2', '5ab5f47af7414939ec2fa22fc198af45', null, null, '会员二四', '1', '2017-12-01', '', '', '', '13111111124', null, null, null, '1', '1', '0', '2017-12-01 10:54:19', '2017-12-01 10:54:19', null);
INSERT INTO `uums_user` VALUES ('22', '2', '2', 'C000000003', 'qwe1', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '13545676789', null, null, null, '1', '1', '0', '2017-12-01 18:59:34', '2017-12-01 18:59:34', null);
INSERT INTO `uums_user` VALUES ('23', '2', '2', 'C000000004', 'TLL', '5ab5f47af7414939ec2fa22fc198af45', null, null, null, '0', null, null, null, null, '18911111111', null, null, null, '1', '1', '0', '2017-12-05 16:51:33', '2017-12-05 16:51:33', null);
INSERT INTO `uums_user` VALUES ('24', '2', '2', 'C000000005', 'TT', '5ab5f47af7414939ec2fa22fc198af45', null, null, '唐唐啊', '1', '2010-12-04', '北京市昌平区2号楼', '111111111111111112', '北京市昌平区霍营2号楼', '18911111122', null, null, null, '1', '1', '0', '2017-12-05 16:52:16', '2017-12-05 16:55:30', null);
INSERT INTO `uums_user` VALUES ('25', '1', '2', 'C000000006', 'hyes6', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '会员二五啊', '2', '2010-12-06', '北京市昌平区2号楼', '111111111111111125', '北京市昌平区霍营2号楼', '13111111125', null, null, null, '1', '0', '0', '2017-12-06 09:21:32', '2017-12-06 15:40:25', null);
INSERT INTO `uums_user` VALUES ('26', '2', '1', 'Y000000051', 'YHEE', '0bbc6708c5fc8a9c913bf6344254dfd5', '二二啊', '', '用户二二', '1', '2017-12-06', '北京市昌平区1号楼', '11111111111111111X', '北京市昌平区霍营1号楼', '13211111222', '123123124@qq.com', 'weixin42', '123123124', '1', '0', '0', '2017-12-06 09:42:25', '2017-12-06 09:43:17', '2');
INSERT INTO `uums_user` VALUES ('27', '2', '2', 'C000000007', 'HYEL', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, null, '0', null, null, null, null, '13111111126', null, null, null, '1', '1', '0', '2018-01-26 11:14:40', '2018-01-26 11:14:40', null);
INSERT INTO `uums_user` VALUES ('29', '2', '2', 'C000000008', 'HYEQ', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '会员二七', '1', '2018-01-26', '', '', '', '13111111127', null, null, null, '1', '1', '0', '2018-01-26 11:34:00', '2018-01-29 10:36:34', null);
INSERT INTO `uums_user` VALUES ('30', '1', '2', 'C000000009', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '030小怪兽', '1', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-26 12:37:11', '2018-01-26 12:37:11', null);
INSERT INTO `uums_user` VALUES ('31', '1', '2', 'C000000010', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, 'Mr.person', '1', null, null, null, '北京市昌平区文庙胡同1', '17600978869', null, null, null, '1', '1', '0', '2018-01-26 12:39:27', '2018-01-26 12:39:27', null);
INSERT INTO `uums_user` VALUES ('32', '1', '2', 'C000000011', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, 'Mrperson', '1', '2018-01-09', '', '', '北京市昌平区文庙胡同1', '17600978869', null, null, null, '1', '1', '0', '2018-01-26 12:39:54', '2018-01-29 09:38:07', null);
INSERT INTO `uums_user` VALUES ('33', '2', '2', 'C000000012', 'aaa', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '', '1', null, '', '', '', '18612345678', null, null, null, '1', '1', '0', '2018-01-29 09:35:16', '2018-01-29 09:36:46', null);
INSERT INTO `uums_user` VALUES ('34', '1', '2', 'C000000039', '18613565122', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '王鹏飞', '1', '1993-02-01', '', '', '一个地址', '18613565122', null, null, null, '1', '1', '0', '2018-02-05 17:57:21', '2018-02-05 17:57:21', null);
INSERT INTO `uums_user` VALUES ('35', '1', '2', 'C000000014', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, 'Mr.person', '1', null, null, null, '北京市昌平区文庙胡同1', '17600978869', null, null, null, '1', '1', '0', '2018-01-29 12:07:39', '2018-01-29 12:07:39', null);
INSERT INTO `uums_user` VALUES ('36', '1', '2', 'C000000015', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马睿', '1', null, null, null, '北京市昌平区文庙胡同', '17600978869', null, null, null, '1', '1', '0', '2018-01-29 16:50:35', '2018-01-29 16:50:35', null);
INSERT INTO `uums_user` VALUES ('37', '1', '2', 'C000000016', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马睿', '1', null, null, null, '北京市昌平区文庙胡同', '17600978869', null, null, null, '1', '1', '0', '2018-01-29 16:51:28', '2018-01-29 16:51:28', null);
INSERT INTO `uums_user` VALUES ('38', '1', '2', 'C000000017', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '', '1', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-29 16:52:11', '2018-01-29 16:52:11', null);
INSERT INTO `uums_user` VALUES ('39', '1', '2', 'C000000018', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '邢世莹', '2', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-29 16:57:05', '2018-01-29 16:57:05', null);
INSERT INTO `uums_user` VALUES ('40', '1', '2', 'C000000019', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '邢世莹', '2', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-29 17:32:52', '2018-01-29 17:32:52', null);
INSERT INTO `uums_user` VALUES ('41', '1', '2', 'C000000020', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '邢世莹', '2', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-29 17:56:30', '2018-01-29 17:56:30', null);
INSERT INTO `uums_user` VALUES ('43', '1', '2', 'C000000022', '112312312', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '1231', '2', '1969-01-30', '', '', '北京市昌平区回龙观东大街霍营地铁站国风美堂综合楼第二栋门牌号1115室欢迎来访', '212312317', null, null, null, '1', '1', '0', '2018-01-29 18:10:10', '2018-01-30 10:50:59', null);
INSERT INTO `uums_user` VALUES ('44', '1', '2', 'C000000023', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马睿', '1', null, null, null, '北京市昌平区文庙胡同', '17600978869', null, null, null, '1', '1', '0', '2018-01-30 10:44:22', '2018-01-30 10:44:22', null);
INSERT INTO `uums_user` VALUES ('45', '1', '2', 'C000000024', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马睿', '1', null, null, null, '北京市昌平区文庙胡同', '17600978869', null, null, null, '1', '1', '0', '2018-01-30 10:45:14', '2018-01-30 10:45:14', null);
INSERT INTO `uums_user` VALUES ('46', '1', '2', 'C000000025', '13121793032', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '邢世莹', '2', null, null, null, '北京市昌平区黄平路', '13121793032', null, null, null, '1', '1', '0', '2018-01-30 10:49:21', '2018-01-30 10:49:21', null);
INSERT INTO `uums_user` VALUES ('47', '1', '2', 'C000000026', '17600978869', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马睿', '1', null, null, null, '北京市昌平区文庙胡同', '17600978869', null, null, null, '1', '1', '0', '2018-01-30 10:52:34', '2018-01-30 10:52:34', null);
INSERT INTO `uums_user` VALUES ('50', '1', '2', 'C000000038', '18631892217', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '朱杰abc', '2', '1991-08-23', '', '', '北京市昌平区黄平路', '18631892217', null, null, null, '1', '1', '0', '2018-02-02 10:44:06', '2018-02-02 10:44:06', null);
INSERT INTO `uums_user` VALUES ('52', '1', '2', 'C000000036', '17600337542', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '刘欣未', '0', null, null, null, '北京市昌平区龙跃街', '17600337542', null, null, null, '1', '1', '0', '2018-02-01 15:26:02', '2018-02-01 15:26:02', null);
INSERT INTO `uums_user` VALUES ('53', '1', '2', 'C000000040', '13298323416', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '马壮壮', '0', null, null, null, '北京市昌平区黄平路', '13298323416', null, null, null, '1', '1', '0', '2018-02-05 19:08:00', '2018-02-05 19:08:00', null);
INSERT INTO `uums_user` VALUES ('54', '1', '2', 'C000000042', '15901170409', '0bbc6708c5fc8a9c913bf6344254dfd5', null, null, '代云瑞', '0', null, null, null, '北京市昌平区霍营1号楼', '15901170409', null, null, null, '1', '1', '0', '2018-02-06 10:21:23', '2018-02-06 10:21:23', null);

-- ----------------------------
-- Table structure for uums_user_code
-- ----------------------------
DROP TABLE IF EXISTS `uums_user_code`;
CREATE TABLE `uums_user_code` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '标识',
  `TYPE_NAME` varchar(20) NOT NULL COMMENT '单位类型名称',
  `USER_TYPE` char(1) NOT NULL COMMENT '单位类型代码',
  `USER_CODE` int(9) NOT NULL DEFAULT '0' COMMENT '当前用户编码数',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_user_code
-- ----------------------------
INSERT INTO `uums_user_code` VALUES ('1', '运营商', 'Y', '52');
INSERT INTO `uums_user_code` VALUES ('2', '客户', 'C', '43');
INSERT INTO `uums_user_code` VALUES ('3', '员工', 'E', '1');

-- ----------------------------
-- Table structure for uums_user_role
-- ----------------------------
DROP TABLE IF EXISTS `uums_user_role`;
CREATE TABLE `uums_user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FK_ju2nns9b2kdmm2c8gvsf1l50a` (`role_id`),
  CONSTRAINT `FK_ju2nns9b2kdmm2c8gvsf1l50a` FOREIGN KEY (`role_id`) REFERENCES `uums_role` (`ID`),
  CONSTRAINT `FK_s3smem1xmms3m388dg8qdm62p` FOREIGN KEY (`user_id`) REFERENCES `uums_user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uums_user_role
-- ----------------------------
INSERT INTO `uums_user_role` VALUES ('1', '1');
